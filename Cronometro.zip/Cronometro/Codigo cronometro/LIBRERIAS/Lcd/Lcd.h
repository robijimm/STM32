// C�digo Ejemplo 10 7 // 
// Archivo *.h //   
#ifndef _LCD_H
#define _LCD_H
#include "Bus.h"
#include "Delay.h"


class Lcd{// Clase Lcd
private:// Variables internas
 unsigned char Cur;
 unsigned short Inf;  
 bool bus;
 Bus * B;
 void SetPort(unsigned char d);
public:
	
 Lcd();// Construtor
 void SetBusPort(Bus *b);// Define bus de datos
 void Iniciar(void);// Inicia display
 void Clear(void);// M�todo para borrar Lcd
 void Home(void);// M�todo para posicionar en direcci�n 0
 void DireccionDD(unsigned char d);// M�todo para direccionar DD RAM 
 void DireccionCG(unsigned char d);// M�todo para direccionar CG RAM 
 void CursorOnOff(bool e);// M�todo para On/Off del Cursor
 void CursorBlink(bool e);// M�todo para On/Off del parpadeo en cursor
 void Dato(unsigned char d);// M�todo para enviar un dato 
 void Instruccion(unsigned char i);// M�todo para enviar una instrucci�n
 void Print(char c);// M�todo para imprimir un char
 void Print(char *t);// M�todo para imprimir un texto
 void Print1x16(char *t);// M�todo para imprimir un texto
 void Print(unsigned char l,char *t);// M�todo para imprimir l�nea
 char * operator = (char *t);// Operador para imprimir un texto
 int operator = (int v);// Operador para imprimir un entero
 double operator = (double v);// Operador para imprimir un decimal
};
#endif






