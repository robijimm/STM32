// C�digo Ejemplo 10 8 // 
// Archivo *.cpp //
#include "Lcd.h"
Lcd::Lcd(){Cur=0x0F;Inf=0;} // Constructor
void Lcd::SetBusPort(Bus *b){B=b;Iniciar();}
 // Inicia Lcd en Bus de 8 � 4 bits   
void Lcd::Iniciar(void){
 bus=0; 
 if(B->GetBits()>=10)bus=1;// Bus en 8 bits	
 IniciarDelay(); // Se inicia el servicio de los retardos
 B->SetBus(0);Inf=0;	
 Delay_ms(40); // Retardo de 40m Segundos
 if(bus){	 
  Instruccion(0x30); // Instrucci�n Set bus 8 bits 
  Delay_ms(5); // Retardo de 5m Segundos
  Instruccion(0x30); // Instrucci�n Set bus 8 bits 
  Delay_ms(5); // Retardo de 5m Segundos
  Instruccion(0x30); // Instrucci�n Set bus 8 bits 
  Delay_ms(5); // Retardo de 5m Segundos   
  Instruccion(0x38); // Set Bus 8 bits, doble l�nea y fuente 
 }
 else{ 
  SetPort(0x03); // Instrucci�n Set port 4 bits
  Delay_ms(5); // Retardo de 3m Segundos   
  SetPort(0x03); // Instrucci�n Set bus 4 bits
  Delay_ms(5); // Retardo de 3m Segundos       
  Instruccion(0x32); // Instrucci�n Set bus 4 bits
  Instruccion(0x28); // Set Bus 4 bits, doble l�nea y fuente 
 }
 Instruccion(0x06); // Set corrimiento de cursor 
 Instruccion(0x0F); // Set Display ON, cursor y parpadeo ON
 Instruccion(0x01); // Borra display y posiciona en 0
 Delay_ms(3); // Retardo de 3 Segundos
}
 
void Lcd::Clear(void){// M�todo para borrar Lcd
 Instruccion(0x01); // Instrucci�n Borra Lcd
 Delay_ms(2); // Retardo de 2m Segundos   
}
 
void Lcd::Home(void){// M�todo para posicionar en direcci�n 0
 Instruccion(0x02); // Instrucci�n posiciona en 0
 Delay_ms(2); // Retardo de 2m Segundos
}
 
void Lcd::SetPort(unsigned char d){// M�todo para Set en bus de datos
 if(bus){ 
  Inf&=0xFF00;
  Inf|=d;
  B->SetBus(Inf);
  Delay_us(2);
  Inf|=0x0100;
  B->SetBus(Inf);Delay_us(5);
  Inf&= ~0x0100;
  B->SetBus(Inf);Delay_us(46);
 }
 else{
  Inf&=0xF0;
  Inf|=(d&0x0F);
  B->SetBus(Inf);
  Delay_us(2);
  Inf|=0x10;
  B->SetBus(Inf);Delay_us(5);
  Inf&= ~0x10;
  B->SetBus(Inf);Delay_us(46);
 }
}

void Lcd::Instruccion(unsigned char i){// M�todo para enviar una instrucci�n
 if(bus){
  Inf&= ~0x0200;
  SetPort(i);
  Inf|=0x0200;
 }
 else{
  Inf&= ~0x20;
  SetPort(i>>4);
  SetPort(i);
  Inf|=0x20;
 }
}

void Lcd::Dato(unsigned char d){// M�todo para enviar un dato 
 if(bus)SetPort(d);
 else{
  SetPort(d>>4);
  SetPort(d);
 }
}

void Lcd::DireccionDD(unsigned char d){// M�todo para direccionar memoria de datos
 //Instrucci�n para Set Direcci�n
 Instruccion(0x80|(d&0x7F));
}

// M�todo para direccionar memoria generadora de caracteres
void Lcd::DireccionCG(unsigned char d){
 // Instrucci�n para Set Direcci�n
 Instruccion(0x40|(d&0x3F));
}

void Lcd::CursorOnOff(bool e){// M�todo para On/Off del Cursor
 // Enciende o apaga cursos  
 if(e)Cur|=2; else Cur&=0xFD;   
 Instruccion(Cur); // Aplica instrucci�n
}

 // M�todo para On/Off del parpadeo en cursor
void Lcd::CursorBlink(bool e){
 // Enciende o apaga parpadeo
 if(e)Cur|=1; else Cur&=0xFE;
 Instruccion(Cur); // Aplica instrucci�n
}

 // M�todo para imprimir un char
void Lcd::Print(char c){Dato(c);}
 
 // M�todo para imprimir un texto
void Lcd::Print(char *t){
 unsigned char n=0; // Contador n
 // Bucle para imprimir hasta encontrar el car�cter Nulo
 while(t[n]!=0)Dato(t[n++]);
}

 // M�todo para imprimir un texto en una l�nea
void Lcd::Print(unsigned char l,char *t){
 switch(l){// Indicador de l�nea
  case 1: DireccionDD(0x40); break; // L�nea 1
  case 2: DireccionDD(0x14); break; // L�nea 2
  case 3: DireccionDD(0x54); break; // L�nea 3
  default:DireccionDD(0x00); break; // L�nea 0 
 }
 Print(t); // Impresi�n del texto
}

// M�todo para imprimir un texto
void Lcd::Print1x16(char *t){
 if(strlen(t)<=8)Print(0,t);
 else{
  Print(0,t);
  Print(1,t+8);
 }
}

char * Lcd::operator = (char *t){// Operador para imprimir un texto
 Print(0,t);
 return t;
}

int Lcd::operator = (int v){// Operador para imprimir un entero
 char Text[30];
 sprintf(Text,"%d",v);
 Print(0,Text);
 return v;	
}

double Lcd::operator = (double v){// Operador para imprimir un decimal
 char Text[30];
 sprintf(Text,"%0.3f",v);
 Print(0,Text);
 return v; 
}


