// C�digo Ejemplo 9 1 //
// Archivo *.h //
#ifndef _PIN_H
#define _PIN_H
#include "Stm32f.h"
#include "Bit.h"
class Pin : public Bit {// Clase Pin, que hereda la clase Bit //
public:
 GPIO_TypeDef * port; // Apuntador a GPIO
 unsigned char pin,prt; // variable para guardar pin asociado
// // Variables para guardar las mascara de activaci�n 1 y 0
 unsigned int mask1,mask0; 
 void Gpio(int p); // M�todo para asignar pin a la clase
// // M�todo para usar funci�n alternativa
 void FuncionAlternativa(int p,unsigned char f);
 void DigitalOut(int p); // M�todo para hacer pin de salida
 void DigitalOut(void); // M�todo para hacer pin de salida
// // M�todo para hacer pin de salida con open drain
 void DigitalOutOpen(unsigned char p);
 void OpenDrain(void);
 void DigitalIn(int p); // M�todo para hacer pin de entrada
 void DigitalIn(void); // M�todo para hacer pin de entrada
// // M�todo para hacer pin de entrada con resistencia Pull-Up
 void DigitalInUp(unsigned char p);
 void PullUp(void);
// // M�todo para hacer pin de entrada con resistencia Pull-Down
 void DigitalInDown(unsigned char p);
 void PullDown(void);
 void Analogo(unsigned char p); // M�todo para funci�n an�logo
 void Analogo(void); // M�todo para funci�n an�logo
 void Interrupcion(FunInt fun,bool ft,bool rt); // M�todo para asignar interrupci�n
 void SetBit(bool e);
 bool GetBit(void);	
 bool operator = (bool e);
 bool operator = (Pin &p); // Operador para igualar el pin a otro pin
 bool operator = (Bit &b); // Operador para igualar el pin a otro bit
 void operator << (int p); // Operador para definir pin de entrada
 void operator >> (int p); // Operador para definir pin de salida
 void operator >> (FunInt fun); // Operador para asignar flanco subida
 void operator << (FunInt fun); // Operador para asignar flanco bajada
};
unsigned int HCLK(void); // Funci�n para identificar frecuencia del Core
unsigned int PCLK1(void); // Funci�n para identificar frecuencia APB1
unsigned int PCLK2(void); // Funci�n para identificar frecuencia APB2
#endif

