// C�digo Ejemplo 17 1 // 
// Archivo *.h //
#ifndef _FLASH_H
#define _FLASH_H
#include "Stm32f.h"
class Flash{// Clase Flash
private:
 // Variables y apuntadores  
 unsigned short *m,*d;
 unsigned int Size;
 unsigned char Sec;
public: 
 Flash(); // Constructor
 void SetMemoria(int s); // M�todo para asignar sector
 void Desbloquear(void); // M�todo para desbloquear memoria
 void Bloquear(void); // M�todo para Bloquear memoria
 void Borrar(void); // M�todo para borrar sector
 void Borrar(int s); // M�todo para borrar sector     
 void Leer(int bytes,void *dat); // M�todo para leer datos
 void Grabar(int bytes,void *dat); // M�todo para grabar datos
};
#endif


