// C�digo Ejemplo 17 2 // 
// Archivo *.cpp //
#include "Flash.h"
 // Constructor
Flash::Flash(){m=0;d=0;Size=0;Sec=0;}
 
 // M�todo para desbloquear memoria
void Flash::Desbloquear(void){
  // Espera a memoria desocupada
 while(FLASH->SR&FLASH_SR_BSY);
  // Verifica si la memoria esta desbloqueada
 if(!(FLASH->CR&FLASH_CR_LOCK))return;
 FLASH->KEYR=0x45670123; // Clave de desbloqueo KEY1
 FLASH->KEYR=0xCDEF89AB; // Clave de desbloqueo KEY2
  // Espera desbloqueo
 while(FLASH->CR&FLASH_CR_LOCK);
 FLASH->CR|=(1UL<<FLASH_CR_PSIZE_Pos); // Tama�o de un sector
}
 
 // M�todo para Bloquear memoria
void Flash::Bloquear(void){
  // Espera a memoria desocupada
 while(FLASH->SR&FLASH_SR_BSY);
 FLASH->CR|=FLASH_CR_LOCK; // Bloquea memoria
 while(!(FLASH->CR&FLASH_CR_LOCK)); // Espera bloqueo
}
 
 // M�todo para asignar sector
void Flash::SetMemoria(int s){
  // Asignaci�n de apuntadores y tama�os de sector seg�n micro
#if (defined(STM32F401xE))
 switch(s){
  case 0: Sec=0; m=(unsigned short *)0x8000000; Size=16384;  break;
  case 1: Sec=1; m=(unsigned short *)0x8004000; Size=16384;  break;
  case 2: Sec=2; m=(unsigned short *)0x8008000; Size=16384;  break;
  case 3: Sec=3; m=(unsigned short *)0x800C000; Size=16384;  break;
  case 4: Sec=4; m=(unsigned short *)0x8010000; Size=65536;  break;
  case 5: Sec=5; m=(unsigned short *)0x8020000; Size=131072; break;
  case 6: Sec=6; m=(unsigned short *)0x8040000; Size=131072; break;
  case 7: Sec=7; m=(unsigned short *)0x8060000; Size=131072; break;
  default: break; 
 }
#endif
 
#if( defined(STM32F746xx) )
 switch(s){
  case 0: Sec=0; m=(unsigned short *)0x8000000; Size=32768;  break;
  case 1: Sec=1; m=(unsigned short *)0x8008000; Size=32768;  break;
  case 2: Sec=2; m=(unsigned short *)0x8010000; Size=32768;  break;
  case 3: Sec=3; m=(unsigned short *)0x8018000; Size=32768;  break;
  case 4: Sec=4; m=(unsigned short *)0x8020000; Size=131072; break;
  case 5: Sec=5; m=(unsigned short *)0x8040000; Size=262144; break;
  case 6: Sec=6; m=(unsigned short *)0x8080000; Size=262144; break;
  case 7: Sec=7; m=(unsigned short *)0x80C0000; Size=262144; break;
  default: break; 
 }
#endif
}
 
 // M�todo para borrar sector
void Flash::Borrar(void){
 if(m==0)return; // Retorna con apuntador nulo
 Desbloquear(); // Desbloque memoria
 FLASH->CR &= ~FLASH_CR_PG; // Activa programaci�n
 FLASH->CR |= FLASH_CR_SER; // Borra sector
 FLASH->CR &= ~(0x1F<<FLASH_CR_SNB_Pos); // Asigna sector a borrar
 FLASH->CR |= ((Sec&0x1F)<<FLASH_CR_SNB_Pos);
 FLASH->CR |= FLASH_CR_STRT; // Inicia borrado
  // Espera a memoria desocupada
 while(FLASH->SR&FLASH_SR_BSY);
 Bloquear(); // Bloque la memoria
}
 
 // M�todo para borrar sector
void Flash::Borrar(int s){SetMemoria(s);Borrar();}
 
 // M�todo para leer datos
void Flash::Leer(int bytes,void *dat){
  // Se leen los datos en bloques de 16 bits
 for(int n=0;n<(bytes/2);n++)((unsigned short *)dat)[n]=m[n];
}
 
 // M�todo para grabar datos
void Flash::Grabar(int bytes,void *dat){
 if(m==0)return; // Retorna con apuntador nulo
 d=(unsigned short *)dat; // Iguala apuntador
 Borrar(); // Borra espacio a grabar
 Desbloquear(); // Desbloque memoria
  // Se graban los datos en bloques de 16 bits
 for(int n=0;n<(bytes/2);n++){
   // habilita grabaci�n
  FLASH->CR&= ~FLASH_CR_SER;
  FLASH->CR|=FLASH_CR_PG;
  m[n]=d[n]; // Se graba dato
   // Espera a memoria desocupada
  while(FLASH->SR&FLASH_SR_BSY);
 }
 Bloquear(); // Bloque la memoria
}

