// C�digo Ejemplo 16 11 // 
// Archivo *.h //
#ifndef _CAPTURA_H
#define _CAPTURA_H
#include "Timer.h"
class Captura : public Timer{// Clase Captura
private:
 double Fac; // Variable de factor de escala
 void PinCanal(unsigned char pin); // M�todo para configurar pin
public:
  // M�todo para iniciar Captura  
 void IniciarCaptura(unsigned char tmr,unsigned char pin,double per);
 double CapturaPeriodo(void); // M�todo leer periodo medido
 double CapturaCicloUtil(void); // M�todo leer ciclo �til medido
};
#endif


