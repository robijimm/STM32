// C�digo Ejemplo 16 12 // 
// Archivo *.h //
#include "Captura.h"

 // M�todo para iniciar Captura
void Captura::IniciarCaptura(unsigned char tmr,unsigned char pin,double per){
 SetTimer(tmr); // Asigna Timer
 SetPeriodo(per); // Asigna periodo
  // Calcula el factor de tiempo
 Fac=GetPeriodo()/((double)(t->ARR));
  // Activa entrada TI1 con CCR1 y CCR2
 t->CCMR1|=TIM_CCMR1_CC1S_0|TIM_CCMR1_CC2S_1;
  // Configura disparador TI1
 t->SMCR|=TIM_SMCR_TS_2|TIM_SMCR_TS_0|TIM_SMCR_SMS_2;
  // Activa m�dulo de captura y sus flancos
 t->CCER|=TIM_CCER_CC1E|TIM_CCER_CC2E|TIM_CCER_CC2P;
 t->CNT=0xFFFFFFFF; // Valor inicial del contador
 PinCanal(pin); // Configura pin de captura
}

 // M�todo para configurar pin
void Captura::PinCanal(unsigned char pin){
 Pin P;
  // Se inicia pin en funci�n alternativa 
  // seg�n el n�mero del Timer
 switch(tim){
  case 1:
  case 2:P.FuncionAlternativa(pin,0x01);break;
  case 3:
  case 4:
  case 5:P.FuncionAlternativa(pin,0x02);break;
  default:P.FuncionAlternativa(pin,0x03);break;
 }
}

 // M�todo leer periodo medido
double Captura::CapturaPeriodo(void){
  // Retorna el periodo en segundos
 return Fac*(double)t->CCR1;
}
 
 // M�todo leer ciclo �til medido
double Captura::CapturaCicloUtil(void){
  // Retorna el ciclo �til en segundos
 return Fac*(double)t->CCR2;
}


