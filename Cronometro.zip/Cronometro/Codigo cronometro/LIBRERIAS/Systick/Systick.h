// C�digo Ejemplo 7 6 //
// Archivo *.h //
#ifndef _SYST_H
#define _SYST_H
#include "Stm32f.h"
static FunInt sysfun;
class Systick{// Clase SysTick
private:
public:
 Systick();// Constructor
 void SetFun(FunInt f);// M�todo para definir rutina
 void Iniciar(double t);// M�todo para iniciar SysTick
 void operator = (FunInt f);// Operador para definir rutina
 double operator = (double t);// Operador para iniciar tiempo
};
#endif




