// C�digo Ejemplo 7 7 //
// Archivo *.cpp //
#include "Systick.h"
extern "C"{// Rutina Interrupci�n SystTick
 void SysTick_Handler(void){
  if(sysfun!=0)sysfun();
 }
}

Systick::Systick(){// Constructor
 sysfun=0;
}

void Systick::SetFun(FunInt f){// M�todo para definir rutina
 sysfun=f;
}

void Systick::Iniciar(double t){// M�todo para iniciar SysTick
 SystemCoreClockUpdate();
 SysTick_Config(SystemCoreClock*t);
}

void Systick::operator = (FunInt f){// Operador para definir rutina
 SetFun(f);
}

double Systick::operator = (double t){// Operador para iniciar tiempo
 Iniciar(t);
 return t;
}




 