

#include "SH1106.h"

SH1106::SH1106(){I=NULL;}

void SH1106::SetI2c(I2cBus *i){I=i;}

void SH1106::IniciarGLCD(void)
{
  WDis=127;
  HDis=64;
  clv=0;
  chv=0;
  delay(100);
  Comando(0xAE);// Apagar el display
	Comando(0xD5,0x80);// Configurar el display clock
  Comando(0xA8,0x3F);// Configurar el multiplex ratio
  Comando(0xD3,0x00);// Configurar el desplazamiento vertical
  Comando(0x40);// Establecer el nivel de inicio de la l�nea
  Comando(0x8D,0x14); // Configurar carga de la bomba externa
  Comando(0x20,0x00); // Modo de memoria de direcci�n horizontal
  Comando(0xA1);       // Segment remap
  Comando(0xC8);       // Com scan direction
  Comando(0xDA,0x12); // Configurar el hardware de la com
  Comando(0x81,0xFF); // Configurar el contraste
  Comando(0xD9,0xF1); // Configurar el precharge period
  Comando(0xDB,0x40); // Configurar VCOMH
  Comando(0xA4);      // Normal display
  Comando(0xA6);      // Normal output
	SetColumna(0);
	SetPagina(0);
  BorrarPantalla();
  Refrescar();
	Comando(0xAF);		
	SetColumna(0);
	SetPagina(0);
  SetColor(1);
}

void SH1106::Test(void)
{
  BorrarPantalla();
  SetColor(1);
  FuenteTexto(System14x14);
  RectanguloCurvo(0,0,127,63,5);
  RectanguloCurvo(2,2,125,61,3);
  PrintTexto(8,7,"Test Pantalla");
  PrintTexto(8,25,"OLED 128x64");
  PrintTexto(8,42,"SH1106");
  Refrescar();
}

void SH1106::Refrescar(void)
{
	for(unsigned char p=0;p<8;p++){
	 SetPagina(p);SetColumna(0);
   Dato( Pan+p*128, 128 );		
	}
}

void SH1106::BorrarPagina(unsigned char p)
{ 
  for(unsigned char n=0;n<128;n++)Pan[p*128+n]=0;
}

void SH1106::BorrarPantalla(void)
{
  for(int n=0;n<1024;n++)Pan[n]=0;
}

void SH1106::Imagen(unsigned char *img)
{
  for(int n=0;n<1024;n++)Pan[n]=img[n];
}

void SH1106::Comando(unsigned char c)
{
	unsigned char Dat[2]={0x00,0x00};
	Dat[1]=c;
	I->TxI2C(0x3C<<1,Dat,2);
}

void SH1106::Comando(unsigned char c,unsigned char p1)
{
	unsigned char Dat[3]={0x00,0x00,0x00};
	Dat[1]=c;
	Dat[2]=p1;
	I->TxI2C(0x3C<<1,Dat,3);
} 

void SH1106::Dato(unsigned char d)
{
	unsigned char Dat[2]={0x40,0x00};
	Dat[1]=d;
	I->TxI2C(0x3C<<1,Dat,2);
}

void SH1106::Dato(unsigned char *d,unsigned char n)
{
	unsigned char dd[129];
	dd[0]=0x40;
	for(unsigned char j=0;j<n;j++)dd[j+1]=d[j];
	I->TxI2C(0x3C<<1,dd,n+1);
}

void SH1106::SetColumna(unsigned char c)
{	
 Comando((c+2)&0x0F);
 Comando( 0x10|((c+2)>>4)&0x0F );
}

void SH1106::SetPagina(unsigned char p)
{
	Comando(0xB0|(p&0x0F));
}

void SH1106::Pixel(int x,int y)
{
  unsigned char p,pi;
  p=y/8;
  pi=y-p*8;
 if( clv==1 )
 {
    switch(pi)
    { 
      case 0: Pan[p*128+x] |= 0x01; break; 
      case 1: Pan[p*128+x] |= 0x02; break; 
      case 2: Pan[p*128+x] |= 0x04; break; 
      case 3: Pan[p*128+x] |= 0x08; break; 
      case 4: Pan[p*128+x] |= 0x10; break; 
      case 5: Pan[p*128+x] |= 0x20; break;    
      case 6: Pan[p*128+x] |= 0x40; break; 
      case 7: Pan[p*128+x] |= 0x80; break;
      default:break;
    }
 }
 else 
 {
   switch(pi)
    { 
      case 0: Pan[p*128+x] &= ~0x01; break; 
      case 1: Pan[p*128+x] &= ~0x02; break; 
      case 2: Pan[p*128+x] &= ~0x04; break; 
      case 3: Pan[p*128+x] &= ~0x08; break; 
      case 4: Pan[p*128+x] &= ~0x10; break; 
      case 5: Pan[p*128+x] &= ~0x20; break;    
      case 6: Pan[p*128+x] &= ~0x40; break; 
      case 7: Pan[p*128+x] &= ~0x80; break;
      default:break;
    }
 }
} 

void SH1106::LineaX(int x,int y0,int y1){for(int y=y0;y<=y1;y++)Pixel(x,y);}
void SH1106::LineaY(int x0,int x1,int y){for(int x=x0;x<=x1;x++)Pixel(x,y);}
void SH1106::operator = (I2cBus *i){I=i;}
