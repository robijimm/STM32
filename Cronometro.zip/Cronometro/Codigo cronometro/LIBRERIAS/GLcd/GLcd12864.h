// C�digo Ejemplo 10 10 // 
// Archivo *.h //

#ifndef _GLCD12864_H
#define _GLCD12864_H
#include "Bus.h" 
#include "Pin.h"
#include "FontTexto.h"// Consultar este archivo en el repositorio
#include "Delay.h"
#include "GLcd.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
class GLcd12864 : public GLcd{// Clase Glcd12864
protected:
// Campos de memoria y variables
unsigned short Dat;
unsigned char Pan[1024];
Bus * B;
void BusPort(unsigned char d);
void Pastilla(bool p1,bool p2);
void SetReset(bool r);
void SetRS(bool rs);
void SetE(bool e);
public:
GLcd12864(); // Constructor
// D0...D7,CS1,CS2,RST,RS,E //
// P.DigitalOut(DP7,DP6,DP5,DP4,DP3,DP2,DP10,DP11,AP0,DP12,AP1,DP9,DP8); //
void SetBusPort(Bus *b);
void IniciarGLCD(void); // Inicio por defecto de GLcd
// Inicio por detallado de GLcd
void BorrarPagina(unsigned char p); // Borrado de pagina
void Refrescar(void); // Refresco de la pantalla visible
void Test(void); // M�todo para grafica de prueba
void Imagen(unsigned char *img); // Grafica mapa de bits
void BorrarPantalla(void); // Borra pantalla 
void Comando(unsigned char c); // Env�a comando
void Dato(unsigned char d); // Env�a Dato
void SetColumna(unsigned char c); // Selecciona columna 
void SetPagina(unsigned char p); // Selecciona pagina
void Pixel(int x,int y); // Imprime pixel
void LineaX(int x,int y0,int y1); // Imprime l�nea X
void LineaY(int x0,int x1,int y); // Imprime l�nea Y
};
#endif

