// C�digo Ejemplo 10 16 // 
// Archivo *.h //
#ifndef _ILIGLCD_H
#define _ILIGLCD_H
#include "Port.h" 
#include "Pin.h"
#include "FontTexto.h"
#include "Delay.h"
#include "GLcd.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define RGB16_BLACK       0x0000
#define RGB16_NAVY        0x000F
#define RGB16_DARKGREEN   0x03E0
#define RGB16_DARKCYAN    0x03EF
#define RGB16_MAROON      0x7800
#define RGB16_PURPLE      0x780F
#define RGB16_OLIVE       0x7BE0
#define RGB16_LIGHTGREY   0xC618
#define RGB16_DARKGREY    0x7BEF
#define RGB16_BLUE        0x001F
#define RGB16_GREEN       0x07E0
#define RGB16_CYAN        0x07FF
#define RGB16_RED         0xF800
#define RGB16_MAGENTA     0xF81F
#define RGB16_YELLOW      0xFFE0
#define RGB16_WHITE       0xFFFF
#define RGB16_ORANGE      0xFD20
#define RGB16_GREENYELLOW 0xAFE5
#define RGB16_PINK        0xF81F
#define ILI_DELAY_1     0xFFF1
#define ILI_DELAY_2     0xFFF2
#define ILI_DELAY_3     0xFFF3
#define ILI_DELAY_4     0xFFF4
#define ILI_DELAY_5     0xFFF5
#define ILI_DELAY_6     0xFFF6
#define ILI_DELAY_7     0xFFF7
#define ILI_DELAY_8     0xFFF8
#define ILI_REPEAT      0xFFF9
#define ILI_RESET       0xFFFA
#define ILI_TITULO      0xFFFB
#define ILI_END         0xFFFF
const unsigned short ILI9341_Ini [] ={
 320,240,
 ILI_RESET,
 0x01,00,ILI_DELAY_8,//software reset
 0xC0,01,0x23, //Power Control 1
 0xC1,01,0x10, //Power Control 1
 0xC5,02,0x3E,0x28, //VCOM Control 1
 0xC7,01,0x86, //VCOM Control 2
 0x36,01,0x28, //Memory Access control
 0x3A,01,0x55, //Pixel Format Set
 0xB1,02,0x00,0x18, // Frame Control
 0xB6,02,0x08,0x82, //Display Function Control 
 0x11,00, //Sleep Out
 ILI_DELAY_8,
 0x29,00, //Display On
 ILI_DELAY_8,
 ILI_END
};
const unsigned short ILI9486_Ini [] ={
 480,320,
 ILI_RESET,
 0x01,00,ILI_DELAY_8,//software reset
 0xE0,15,0x00,0x07,0x0F,0x0D,0x1B,0x0A,0x3C,0x78,0x4A,0x07,0x0E,0x09,0x1B,0x1E,0x0F,
 0xE1,15,0x00,0x22,0x24,0x06,0x12,0x07,0x36,0x47,0x47,0x06,0x0A,0x07,0x30,0x37,0x0F,
 0xC0,02,0x10,0x10,//Power Control 1
 0xC1,01,0x41,//Power Control 2
 0xC5,03,0x00,0x2c,0x80,// VCOM Control
 0x36,01,0x28,//Memory Access Control OJO!
 0x3A,01,0x55,//Interface Pixel Format
 0xB0,01,0x00,//Interface Mode Control
 0xB1,01,0xB0,//Frame rate 70HZ
 0xB4,01,0x02,//Display Inversion Control
 0xB6,02,0x08,0x82,//Display Function Control (B6h) 
 0xE9,01,0x00,//Set Image Function 
 0xF7,04,0xA9,0x51,0x2C,0x82,//Adjust Control 3
 0x11,00,ILI_DELAY_8,//Sleep Out
 0x29,00,ILI_DELAY_8,//Display On
 ILI_END
};
#define Rst1  Prst->BSRR|=Mk1Rst  
#define Rst0  Prst->BSRR|=Mk0Rst
#define Cs1   Pcs->BSRR|=Mk1Cs  
#define Cs0   Pcs->BSRR|=Mk0Cs
#define Dc1   Pdc->BSRR|=Mk1Dc  
#define Dc0   Pdc->BSRR|=Mk0Dc
#define Wr1   Pwr->BSRR|=Mk1Wr  
#define Wr0   Pwr->BSRR|=Mk0Wr
#define Rd1   Prd->BSRR|=Mk1Rd  
#define Rd0   Prd->BSRR|=Mk0Rd
#define PulWr Pwr->BSRR|=Mk0Wr;Pwr->BSRR|=Mk1Wr
#define DA0 Dp0->BSRR|=Mk0D0
#define DA1 Dp0->BSRR|=Mk1D0
#define DB0 Dp1->BSRR|=Mk0D1
#define DB1 Dp1->BSRR|=Mk1D1
#define DC0 Dp2->BSRR|=Mk0D2
#define DC1 Dp2->BSRR|=Mk1D2
#define DD0 Dp3->BSRR|=Mk0D3
#define DD1 Dp3->BSRR|=Mk1D3
#define DE0 Dp4->BSRR|=Mk0D4
#define DE1 Dp4->BSRR|=Mk1D4
#define DF0 Dp5->BSRR|=Mk0D5
#define DF1 Dp5->BSRR|=Mk1D5
#define DG0 Dp6->BSRR|=Mk0D6
#define DG1 Dp6->BSRR|=Mk1D6
#define DH0 Dp7->BSRR|=Mk0D7
#define DH1 Dp7->BSRR|=Mk1D7
class ILIGLcd : public GLcd{
private:
 Port *B,*C;
 GPIO_TypeDef *Prst,*Pcs,*Pdc,*Pwr,*Prd;
 unsigned int Mk1Rst,Mk0Rst; 
 unsigned int Mk1Cs,Mk0Cs; 
 unsigned int Mk1Dc,Mk0Dc; 
 unsigned int Mk1Wr,Mk0Wr;
 unsigned int Mk1Rd,Mk0Rd; 
 GPIO_TypeDef *Dp0,*Dp1,*Dp2,*Dp3,*Dp4,*Dp5,*Dp6,*Dp7;
 unsigned int Mk1D0,Mk0D0; 
 unsigned int Mk1D1,Mk0D1;
 unsigned int Mk1D2,Mk0D2;
 unsigned int Mk1D3,Mk0D3;
 unsigned int Mk1D4,Mk0D4;
 unsigned int Mk1D5,Mk0D5;
 unsigned int Mk1D6,Mk0D6;
 unsigned int Mk1D7,Mk0D7; 
 int ddcc,wwrr,dd6,dd7;
 bool InvTou,Invi,InvXY;
 int xx0,yy0,xx1,yy1;
 unsigned char udb,orx,Com0x36,Com0xB6;
 void SetBus(unsigned char d);
 unsigned char GetBus(void);
 void BusIn(void);
 void BusOut(void);
 void SetRst(bool rst);
 void SetCS(bool cs);
 void SetDC(bool dc);
 void SetWR(bool wr);
 void SetRD(bool rd); 		
 void Comando(unsigned char c);
 void DatoOut(unsigned char d);	
 unsigned char DatoIn(void);
 void Comandos(const unsigned short *COM);
 void InvertirScanCol(void);
 void InvertirScanFil(void);
 void InvertirMemoriaCol(void);
 void InvertirMemoriaFil(void);
 void InvertirMemoriaFilCol(void);
 void Ventana(unsigned int x0,unsigned int y0,unsigned int x1,unsigned int y1);
 void Punto(int x0,int y0);
 void Color(void); 
 void Color(unsigned int col);
 void PulosWR(unsigned int n);
public:
 ILIGLcd();
 void SetBusPort(Port *b,Port *c);
 void Activo(bool e);
 void IniciarGLCD(const unsigned short *ili);
 void IniciarGLCD(void);
 void Test(void);
 void Imagen(int x,int y,unsigned int *i);
 void Pixel(int x0,int y0);
 void LineaX(int x,int y0,int y1);
 void LineaY(int x0,int x1,int y);
};
double _Fx(double x,double x0,double y0,double x1,double y1);
unsigned int Rgb(unsigned char r,unsigned char g,unsigned char b);
#endif
