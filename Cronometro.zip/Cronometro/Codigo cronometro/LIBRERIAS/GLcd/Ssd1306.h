// C�digo Ejemplo 14 11 // 
// Archivo *.h //
#ifndef _SSD1306_H
#define _SSD1306_H
#include "Pin.h"
#include "Delay.h"
#include "FontTexto.h"
#include "GLcd.h"
#include "I2cBus.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

class SSD1306 : public GLcd{
private:
 unsigned char Pan[1024];
 I2cBus *I;
public:
 SSD1306();
 void SetI2c(I2cBus *i);
 void IniciarGLCD(void);
 void BorrarPagina(unsigned char p);
 void Refrescar(void);
 void Test(void);
 void Imagen(unsigned char *img);
 void BorrarPantalla(void); 
 void Comando(unsigned char c);
 void Comando(unsigned char c,unsigned char p1); 
 void Dato(unsigned char d);
 void SetColumna(unsigned char c); 
 void SetPagina(unsigned char p);
 void Pixel(int x,int y);
 void LineaX(int x,int y0,int y1);
 void LineaY(int x0,int x1,int y);
 void operator = (I2cBus *i);
};
#endif
