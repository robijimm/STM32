// C�digo Ejemplo 10 17 // 
// Archivo *.cpp //
#include "ILIGLcd.h"
double _Fx(double x,double x0,double y0,double x1,double y1)
{
  double m;
  m=(y1-y0)/(x1-x0);
  return (m*(x-x0)+y0);
}

ILIGLcd::ILIGLcd()
{
	B=NULL;
	InvTou=false;
	Invi=false;
  InvXY=false;
	Com0xB6=0x82;
	Com0x36=0x08;
	udb=0;
	WDis=0;
	HDis=0;
  SetColor(0);
}

void ILIGLcd::SetBusPort(Port *b,Port *c)
{
	B=b;
	C=c;
	udb=255;
	B->SetBus(udb);
	C->SetBus(0x1F);
	
	
	Prst=C->P[0].port; Mk0Rst=C->P[0].mask0; Mk1Rst=C->P[0].mask1;
	Pcs=C->P[1].port; Mk0Cs=C->P[1].mask0; Mk1Cs=C->P[1].mask1;
	Pdc=C->P[2].port; Mk0Dc=C->P[2].mask0; Mk1Dc=C->P[2].mask1;
	Pwr=C->P[3].port; Mk0Wr=C->P[3].mask0; Mk1Wr=C->P[3].mask1;
	Prd=C->P[4].port; Mk0Rd=C->P[4].mask0; Mk1Rd=C->P[4].mask1;
  
  Dp0=B->P[0].port; Mk0D0=B->P[0].mask0; Mk1D0=B->P[0].mask1; 
  Dp1=B->P[1].port; Mk0D1=B->P[1].mask0; Mk1D1=B->P[1].mask1;
  Dp2=B->P[2].port; Mk0D2=B->P[2].mask0; Mk1D2=B->P[2].mask1;
  Dp3=B->P[3].port; Mk0D3=B->P[3].mask0; Mk1D3=B->P[3].mask1;
  Dp4=B->P[4].port; Mk0D4=B->P[4].mask0; Mk1D4=B->P[4].mask1;
  Dp5=B->P[5].port; Mk0D5=B->P[5].mask0; Mk1D5=B->P[5].mask1;
  Dp6=B->P[6].port; Mk0D6=B->P[6].mask0; Mk1D6=B->P[6].mask1;
  Dp7=B->P[7].port; Mk0D7=B->P[7].mask0; Mk1D7=B->P[7].mask1;	
	
}

void ILIGLcd::Activo(bool e){SetCS(e);}

void ILIGLcd::SetRst(bool rst){C->SetBit(0,rst);}
void ILIGLcd::SetCS(bool cs){C->SetBit(1,cs);}
void ILIGLcd::SetDC(bool dc){C->SetBit(2,dc);}
void ILIGLcd::SetWR(bool wr){C->SetBit(3,wr);}
void ILIGLcd::SetRD(bool rd){C->SetBit(4,rd);}

void ILIGLcd::SetBus(unsigned char d)
{
  if(udb==d)return;
	if(d&1)DA1; else DA0;
	if(d&2)DB1; else DB0;
	if(d&4)DC1; else DC0;
	if(d&8)DD1; else DD0;
	if(d&16)DE1; else DE0;
	if(d&32)DF1; else DF0;
	if(d&64)DG1; else DG0;
	if(d&128)DH1; else DH0;
	udb=d;  
}

unsigned char ILIGLcd::GetBus(void)
{
  return (unsigned char)B->GetBus(); 
}

void ILIGLcd::BusIn(void)
{
 B->DigitalIn();        
}
void ILIGLcd::BusOut(void)
{
	B->DigitalOut();
  SetBus(udb); 
}

void ILIGLcd::Test(void)
{
   BorrarPantalla(RGB16_WHITE);
   SetColor(Rgb(0,0,0));
	
   RectanguloCurvo(3,3,WDis-3,HDis-3,10);
   RectanguloCurvo(4,4,WDis-4,HDis-4,9);
  
   SetColor(Rgb(0,100,255));
	 RectanguloCurvo(6,6,WDis-7,HDis-7,10);
   RectanguloCurvo(7,7,WDis-8,HDis-8,9);
	
   SetColor(Rgb(0,0,255));
   FuenteTexto(Cambria23x23);
   PrintTexto(15,15,"Test Pantalla");
   SetColor(Rgb(255,0,0));
   PrintTexto(15,40,"GLcd TFT");
   SetColor(Rgb(25,25,25));
   PrintTexto(15,65,"ILI9341 / ILI9486");
}

void ILIGLcd::Comando(unsigned char c){
 Dc0;
 SetBus(c);
 PulWr;	
 Dc1; 
}

void ILIGLcd::DatoOut(unsigned char d){
 SetBus(d); 
 PulWr;	
}

void ILIGLcd::Comandos(const unsigned short *COM)
{
		int cmd=0,lon;
		unsigned char coma,data;
	  WDis=COM[cmd++]; 
	  HDis=COM[cmd++];
	  Cs0;
		while(true)
		{
				switch(COM[cmd])
				{
					case ILI_RESET  : delay(100);  
														Rst0;delay(15);
														Rst1;delay(15);
														cmd++;
														break;
					
					case ILI_DELAY_1: delay(1);cmd++;break;
					case ILI_DELAY_2: delay(2);cmd++;break;
					case ILI_DELAY_3: delay(3);cmd++;break;
					case ILI_DELAY_4: delay(4);cmd++;break;
					case ILI_DELAY_5: delay(5);cmd++;break;
					case ILI_DELAY_6:	delay(6);cmd++;break;
					case ILI_DELAY_7:	delay(7);cmd++;break;
					case ILI_DELAY_8: delay(8);cmd++;break;
					case ILI_END:return;
					
					default:  coma=(unsigned char)(COM[cmd]&0xFF);cmd++;
										lon=(int)COM[cmd];cmd++;
										Comando(coma);
										for(int j=0;j<lon;j++){data=(unsigned char)(COM[cmd]&0xFF);cmd++;DatoOut(data);}												
				}
		}		
}

void ILIGLcd::Ventana(unsigned int x0,unsigned int y0,unsigned int x1,unsigned int y1)
{
	
		Comando(0x2A);// Columnas
		DatoOut( (x0>>8)&0xFF );
		DatoOut( x0&0xFF );
		DatoOut((x1>>8)&0xFF);
		DatoOut(x1&0xFF);
	  Comando(0x2B);// Filas
		DatoOut((y0>>8)&0xFF);
		DatoOut(y0&255);
		DatoOut((y1>>8)&0xFF);
    DatoOut(y1&0xFF);
		Comando(0x2C);// RAM WR 
	
}

void ILIGLcd::IniciarGLCD(const unsigned short *ili)
{
	IniciarDelay();
	delay(20);
	Comandos(ili);
	FuenteTexto(Terminal6x8);
	BorrarPantalla(0);
  SetColor(0xFFFF);
}

void ILIGLcd::IniciarGLCD(void)
{
	IniciarGLCD((unsigned short *)ILI9341_Ini);
}

void ILIGLcd::Punto(int x0,int y0){Ventana(x0,y0,x0,y0);}



unsigned char ILIGLcd::DatoIn(void){return GetBus();}
void ILIGLcd::InvertirScanCol(void){Com0xB6^=0x20;Comando(0xB6);DatoOut(0x08);DatoOut(Com0xB6);}
void ILIGLcd::InvertirScanFil(void){Com0xB6^=0x40;Comando(0xB6);DatoOut(0x08);DatoOut(Com0xB6);}
void ILIGLcd::InvertirMemoriaCol(void){Comando(0x36);Com0x36^=64;DatoOut(Com0x36);}
void ILIGLcd::InvertirMemoriaFil(void){Comando(0x36);Com0x36^=128;DatoOut(Com0x36);}
void ILIGLcd::InvertirMemoriaFilCol(void){int dat=WDis;WDis=HDis;HDis=dat;Comando(0x36);Com0x36^=32;DatoOut(Com0x36);}
void ILIGLcd::Color(void)
{
  SetBus(chv);
	PulWr;
  if(clv==chv){
	 PulWr;
	 return;
	}
  SetBus(clv);
  PulWr; 
}

void ILIGLcd::Color(unsigned int col)
{
 SetColor(col);	
 Color();
}

void ILIGLcd::Imagen(int x,int y,unsigned int *i)
{
		int w,h,n=0, l;
		w=i[n++];h=i[n++];l=w*h;
	  Ventana(x,y,x+w-1,y+h-1);
		for(int j=0;j<l;j++)Color(i[n++]);	  
}

void ILIGLcd::PulosWR(unsigned int n){
 for(unsigned int j=0;j<n;j++){
  PulWr;	 
 }
}

void ILIGLcd::Pixel(int x0,int y0){Punto(x0,y0);Color();}
void ILIGLcd::LineaX(int x,int y0,int y1)
{
  int xg,xp,yg,yp,l;
			if(x<0||x>=WDis)return;
			if(y0<0&&y1<0)return;
	    if(y0>=HDis&&y1>=HDis)return;
	    if(y1>y0){yg=y1;yp=y0;} else {yg=y0;yp=y1;}
			if(yp<0)yp=0;
			if(yp>=HDis)yp=HDis-1;
			if(yg<0)yg=0;
			if(yg>=HDis)yg=HDis-1;
	    l=yg-yp;	
			Ventana(x,yp,x,yg);
      if(clv==chv)
			{
       SetBus(clv); 
			 for(int n=0;n<=l;n++){
	       PulWr;
				 PulWr;
			 }
			}
			else
			{
				for(int n=0;n<=l;n++)
				{
          SetBus(chv);
				   PulWr;
			    SetBus(clv);
   	       PulWr; 					
				}
			}
}

void ILIGLcd::LineaY(int x0,int x1,int y)
{
    int xg,xp,yg,yp,l;
			if(y<0||y>=HDis)return;
			if(x0<0&&x1<0)return;
	    if(x0>=WDis&&x1>=WDis)return;
	    if(x1>x0){xg=x1;xp=x0;} else {xg=x0;xp=x1;}
			if(xp<0)xp=0;
			if(xp>=WDis)xp=WDis-1;
			if(xg<0)xg=0;
			if(xg>=WDis)xg=WDis-1;
			l=xg-xp;	
			Ventana(xp,y,xg,y);
			if(clv==chv)
			{
			 SetBus(clv);
			 for(int n=0;n<=l;n++){
				 	PulWr;PulWr;
			  }
			}
			else
			{
				for(int n=0;n<=l;n++)
				{
          SetBus(chv); 	
					PulWr;
			    SetBus(clv); 	
					PulWr;
				}
			}
}

//bool ILIGLcd::GetEjeXY(int &x, int &y)
//{
//  bool ret=false;
//  int INV;
//  x=-1;y=-1;
//  CS=true;
//  WR=false;
//  DC<<ddcc;
//  Da7=false;
//  Da6<<dd6;
//  DC.DigitalInUp(ddcc);
//  delay(1); 
//  if(DC==false)ret=true;
//  if(ret)
//  {
//    WR<<wwrr;
//    Da7<<dd7;
//    DC>>ddcc;DC=false;
//    Da6>>dd6;Da6=true;
//    y=analogRead(wwrr);
//    delay(1);
//    DC<<ddcc;
//    Da6<<dd6;
//    WR>>wwrr;WR=false;
//    Da7>>dd7;Da7=true; 
//    x=analogRead(ddcc);
//    delay(1); 
//  }
//  WR>>wwrr;WR=true;
//  Da7>>dd7;if(udb&128)Da7=true; else Da7=false;
//  DC>>ddcc;DC=true;
//  Da6>>dd6;if(udb&64)Da6=true; else Da6=false;  
//  CS=false;
//  return ret;
//}

//bool ILIGLcd::GetPosXY(int &x,int &y)
//{
//  int xx,yy,k=0;
//  x=-1;y=-1;
//  if(!GetEjeXY(xx,yy))return false;
//  x=0; y=0;
//  for(int n=0;n<4;n++)
//  { 
//   if(GetEjeXY(xx,yy))
//   {  
//    x+=_Fx((double)xx,xx0,10.0,xx1,(double)WDis-11.0);
//    y+=_Fx((double)yy,yy0,10.0,yy1,(double)HDis-11.0);
//    k++;
//   }    
//  }
//  x/=k;y/=k;
//  return true;
//}

//bool ILIGLcd::GetPosTactil(int &x,int &y)
//{
//  int xa,ya,xb,yb,n=0;
//  x=-1;y=-1;
//  if(!GetPosXY(xa,ya))return false;
//  if(!GetPosXY(xb,yb))return false;
//  if(abs(xb-xa)<=8 && abs(yb-ya)<=8)
//  {x=xa;y=ya;return true;}
//  return false;
//}

//void ILIGLcd::SetCalibrarTactil(int x0,int y0,int x1,int y1)
//{
//  xx0=x0;yy0=y0;xx1=x1;yy1=y1;
//}

//void ILIGLcd::GetCalibrarTactil(int &x0,int &y0,int &x1,int &y1)
//{
//  int x,y,k;
//  BorrarPantalla(0);
//  SetColor(Rgb(255,0,0));
//  CirculoRelleno(10,10,6); 
//  while( !GetEjeXY(x,y) );
//  x0=0;y0=0;k=0;
//  for(int n=0;n<10;n++)if(GetEjeXY(x,y)){x0+=x;y0+=y;k++;delay(5);} 
//  x0/=k;y0/=k;
//  xx0=x0;yy0=y0;
//  SetColor(0);
//  RectanguloRelleno(0,0,20,20); while( GetEjeXY(x,y) );
//  SetColor(Rgb(255,0,0));
//  CirculoRelleno(WDis-11,HDis-11,6); while( !GetEjeXY(x,y) );
//  x1=0;y1=0;k=0;
//  for(int n=0;n<10;n++)if(GetEjeXY(x,y)){x1+=x;y1+=y;k++;delay(5);} 
//  x1/=k;y1/=k;
//  xx1=x1;yy1=y1;
//  SetColor(0);
//  RectanguloRelleno(WDis-20,HDis-20,WDis,HDis); while( GetEjeXY(x,y) );
//}

unsigned int Rgb(unsigned char r,unsigned char g,unsigned char b)
{
  unsigned int c;
  unsigned char R,G,B;
  R=(r>>3);
  G=(g>>2);
  B=(b>>3);
  c = (unsigned int)((R<<11)|(G<<5)|B);
  return c;
}





	