// C�digo Ejemplo 14 12 // 
// Archivo *.cpp //

#include "Ssd1306.h"

SSD1306::SSD1306(){I=NULL;}

void SSD1306::SetI2c(I2cBus *i){I=i;}

void SSD1306::IniciarGLCD(void)
{
  WDis=128;
  HDis=64;
  clv=0;
  chv=0;
  delay(100);
  Comando(0xAE);
  Comando(0xD4);
  Comando(0x80);
  Comando(0xA8,0x3F);
  Comando(0xD3,0);
  Comando(0x40);
  Comando(0x8D,0x14);
  Comando(0xA1);
  Comando(0xC8);
  Comando(0xDA,0x12);
  Comando(0x81,0xFF);
  Comando(0xD9,0xF1);
  Comando(0xDB,0x40);
  Comando(0x20,0);
  delay(100);
  BorrarPantalla();
  Comando(0xAF); 
  Refrescar();
  SetColor(1);
}

void SSD1306::Test(void)
{
  BorrarPantalla();
  SetColor(1);
  FuenteTexto(System14x14);
  RectanguloCurvo(0,0,127,63,5);
  RectanguloCurvo(2,2,125,61,3);
  PrintTexto(6,6,"Test Pantalla");
  PrintTexto(6,20,"OLED 128x64");
  PrintTexto(6,34,"SSD1306");
  Refrescar();
}

void SSD1306::Refrescar(void)
{
	SetPagina(0);SetColumna(0);
	for(int n=0;n<1024;n++)Dato(Pan[n]);
}

void SSD1306::BorrarPagina(unsigned char p)
{ 
  for(unsigned char n=0;n<128;n++)Pan[p*128+n]=0;
}

void SSD1306::BorrarPantalla(void)
{
  for(int n=0;n<1024;n++)Pan[n]=0;
}

void SSD1306::Imagen(unsigned char *img)
{
  for(int n=0;n<1024;n++)Pan[n]=img[n];
}

void SSD1306::Comando(unsigned char c)
{
	unsigned char Dat[2]={0x00,0x00};
	Dat[1]=c;
	I->TxI2C(0x3C<<1,Dat,2);
}

void SSD1306::Comando(unsigned char c,unsigned char p1)
{
	unsigned char Dat[3]={0x00,0x00,0x00};
	Dat[1]=c;
	Dat[2]=p1;
	I->TxI2C(0x3C<<1,Dat,3);
} 

void SSD1306::Dato(unsigned char d)
{
	unsigned char Dat[2]={0x40,0x00};
	Dat[1]=d;
	I->TxI2C(0x3C<<1,Dat,2);
}

void SSD1306::SetColumna(unsigned char c)
{
	unsigned char Dat[4]={0x00,0x21,0x00,127};
	Dat[2]=c;
	I->TxI2C(0x3C<<1,Dat,4);
}

void SSD1306::SetPagina(unsigned char p)
{
	unsigned char Dat[4]={0x00,0x22,0x00,7};
  Dat[2]=p;
	I->TxI2C(0x3C<<1,Dat,4);
}

void SSD1306::Pixel(int x,int y)
{
  unsigned char p,pi;
  p=y/8;
  pi=y-p*8;
 if( clv==1 )
 {
    switch(pi)
    { 
      case 0: Pan[p*128+x] |= 0x01; break; 
      case 1: Pan[p*128+x] |= 0x02; break; 
      case 2: Pan[p*128+x] |= 0x04; break; 
      case 3: Pan[p*128+x] |= 0x08; break; 
      case 4: Pan[p*128+x] |= 0x10; break; 
      case 5: Pan[p*128+x] |= 0x20; break;    
      case 6: Pan[p*128+x] |= 0x40; break; 
      case 7: Pan[p*128+x] |= 0x80; break;
      default:break;
    }
 }
 else 
 {
   switch(pi)
    { 
      case 0: Pan[p*128+x] &= ~0x01; break; 
      case 1: Pan[p*128+x] &= ~0x02; break; 
      case 2: Pan[p*128+x] &= ~0x04; break; 
      case 3: Pan[p*128+x] &= ~0x08; break; 
      case 4: Pan[p*128+x] &= ~0x10; break; 
      case 5: Pan[p*128+x] &= ~0x20; break;    
      case 6: Pan[p*128+x] &= ~0x40; break; 
      case 7: Pan[p*128+x] &= ~0x80; break;
      default:break;
    }
 }
} 

void SSD1306::LineaX(int x,int y0,int y1){for(int y=y0;y<=y1;y++)Pixel(x,y);}
void SSD1306::LineaY(int x0,int x1,int y){for(int x=x0;x<=x1;x++)Pixel(x,y);}
void SSD1306::operator = (I2cBus *i){I=i;}


