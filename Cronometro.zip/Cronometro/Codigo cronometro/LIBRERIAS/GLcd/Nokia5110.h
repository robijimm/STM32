#ifndef _NOKIA5110_H
#define _NOKIA5110_H

#include "Delay.h"
#include "SpiBus.h"
#include "Pin.h"
#include "FontTexto.h"
#include "GLcd.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

class Nokia5110 : public GLcd
{
private:
 SpiBus *S;	
 Pin RST,CE,DC;
 unsigned char Pan[504];
public:
 Nokia5110();
 void SetSpi(SpiBus *s);
 //G.IniciarGLCD(AP1,AP0,DP8);
 void IniciarGLCD(int rst,int ce,int dc);
 void IniciarGLCD(void);
 void Pixel(int x,int y);
 void Test(void);
 void BorrarPantalla(void); 
 void Imagen(unsigned char *img);
 void Contraste(unsigned char c);
 void SetPos(int x,int p);
 void Dato(unsigned char d);
 void Refrescar(void);
 void LineaX(int x,int y0,int y1);
 void LineaY(int x0,int x1,int y);
 void operator = (SpiBus *s);
};

#endif