
#include "Nokia5110.h"

Nokia5110::Nokia5110(){S=NULL;}

void Nokia5110::SetSpi(SpiBus *s){S=s;}

void Nokia5110::IniciarGLCD(void)
{
  IniciarGLCD(AP1,AP0,DP8);
}

void Nokia5110::Test(void)
{
  BorrarPantalla();
  SetColor(1);
  RectanguloCurvo(0,0,83,47,5);
  RectanguloCurvo(2,2,81,45,3);
  PrintTexto(5,5,"Test");
  PrintTexto(5,15,"Pantalla");
  PrintTexto(5,25,"Nokia 5110");
  PrintTexto(5,35,"PCD8544");
  Refrescar();
}

void Nokia5110::Contraste(unsigned char c)
{
  DC=0;
  CE=0;delay(1);
	S->TxRxDato(0x21);// Set Fun H=1 //
	S->TxRxDato(0x10|2);// Bis=2 //
	S->TxRxDato(0x80|c);// contras  0 @ 127 //
	S->TxRxDato(0x04);// Temp Coef
	S->TxRxDato(0x20);// Set Fun H=0 //
	delay(1);
  DC=1;
  CE=1;
}

void Nokia5110::IniciarGLCD(int rst,int ce,int dc)
{
	IniciarDelay();
  RST>>rst;RST=1;
  CE>>ce;CE=1;
  DC>>dc;DC=1;
  delay(10);RST=0;
  delay(10);RST=1;
  DC=0;
  CE=0;delay(10);
	S->TxRxDato(0x21);// Set Fun H=1 //
	S->TxRxDato(0x10|2);// Bias.. 0 @ 7//
	S->TxRxDato(0x80|50);// contras  0 @ 127 //
	S->TxRxDato(0x04);// Temp Coef
	S->TxRxDato(0x20);// Set Fun H=0 //
	S->TxRxDato(0x0C);// Display Normal
	S->TxRxDato(0x40);// Set Y=0
	S->TxRxDato(0x80);// Set X=0
	delay(10);
  CE=1;
  BorrarPantalla();
  SetColor(1);
  Refrescar();
}

void Nokia5110::BorrarPantalla(void)
{
  for(int n=0;n<504;n++)Pan[n]=0;
}

void Nokia5110::Imagen(unsigned char *img)
 {
   for(int n=0;n<504;n++)Pan[n]=img[n];
 }

void Nokia5110::Refrescar(void)
{
    DC=0;
    CE=0;
	  S->TxRxDato(0x40);// Set Y=0
	  S->TxRxDato(0x80);// Set X=0
    CE=1;
    DC=1;
    delay(10);
    CE=0;
    for(int n=0;n<504;n++){S->TxRxDato(Pan[n]);}
    DC=0;
    S->TxRxDato(0);
    CE=1;
}

void Nokia5110::Dato(unsigned char d)
{
 DC=1; 
 CE=0;
 S->TxRxDato(d);
 CE=1;
}

void Nokia5110::SetPos(int x,int p)
{
  DC=0;
  CE=0;
	S->TxRxDato(0x40|p&7);
	S->TxRxDato(0x80|x);
  CE=1;
}

void Nokia5110::Pixel(int x,int y)
{
  unsigned char p,pi;
  p=y/8;
  pi=y-p*8;
 if( clv==1 )
  Pan[p*84+x] |= BitsValue[pi];
 else 
   Pan[p*84+x] &= ~BitsValue[pi];
}

void Nokia5110::LineaX(int x,int y0,int y1){for(int y=y0;y<=y1;y++)Pixel(x,y);}
void Nokia5110::LineaY(int x0,int x1,int y){for(int x=x0;x<=x1;x++)Pixel(x,y);}

void Nokia5110::operator = (SpiBus *s){S=s;}