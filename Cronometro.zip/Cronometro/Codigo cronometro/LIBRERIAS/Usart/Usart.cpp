// C�digo Ejemplo 13 3 //
// Archivo *.cpp //
#include "Usart.h"
 
// Definici�n de funciones apuntadoras a interrupci�n USART RX  // 
FunInt2 FunUsart1=0, FunUsart2=0, FunUsart3=0, FunUsart4=0,
FunUsart5=0, FunUsart6=0, FunUsart7=0, FunUsart8=0;
 
extern "C"{ // Rutinas externas
#if CortexM4
  // Vector interrupci�n USART1
 void USART1_IRQHandler(void){
  unsigned int dummy;
  if(!(USART1->SR&USART_SR_RXNE))return;
   // Se ejecuta interrupci�n
  if(FunUsart1!=0)FunUsart1((unsigned char)USART1->DR);
  dummy=USART1->SR; // Se limpian banderas
  dummy=USART1->DR;
 }
 
  // Vector interrupci�n USART2
 void USART2_IRQHandler(void){
  unsigned int dummy;
  if(!(USART2->SR&USART_SR_RXNE))return;
   // Se ejecuta interrupci�n
  if(FunUsart2!=0)FunUsart2((unsigned char)USART2->DR);
  dummy=USART2->SR; // Se limpian banderas
  dummy=USART2->DR;
 }
 
  // Vector interrupci�n USART3
 void USART6_IRQHandler(void){
  unsigned int dummy;
  if(!(USART6->SR&USART_SR_RXNE))return;
     // Se ejecuta interrupci�n   
  if(FunUsart6!=0)FunUsart6((unsigned char)USART6->DR);
  dummy=USART6->SR; // Se limpian banderas
  dummy=USART6->DR;
 }
#endif
#if CortexM7
  // Vector interrupci�n USART3
 void USART3_IRQHandler(void){
  unsigned int dummy;
  if(!(USART3->ISR&USART_ISR_RXNE))return;
   // Se ejecuta interrupci�n
  if(FunUsart3!=0)FunUsart3((unsigned char)USART3->RDR);
  dummy=USART3->ISR; // Se limpian banderas
  dummy=USART3->RDR;
 }
 
 
 // Vector interrupci�n USART4
 void UART4_IRQHandler(void){
  unsigned int dummy;
  if(!(UART4->ISR&USART_ISR_RXNE))return;
   // Se ejecuta interrupci�n
  if(FunUsart4!=0)FunUsart4((unsigned char)UART4->RDR);
  dummy=UART4->ISR; // Se limpian banderas
  dummy=UART4->RDR;
 } 
 
  // Vector interrupci�n UART5
 void UART5_IRQHandler(void){
  unsigned int dummy;
  if(!(UART5->ISR&USART_ISR_RXNE))return;
   // Se ejecuta interrupci�n
  if(FunUsart5!=0)FunUsart5((unsigned char)UART5->RDR);
  dummy=UART5->ISR; // Se limpian banderas
  dummy=UART5->RDR;
 }
 
  // Vector interrupci�n UART7
 void UART7_IRQHandler(void){
  unsigned int dummy;
  if(!(UART7->ISR&USART_ISR_RXNE))return;
   // Se ejecuta interrupci�n
  if(FunUsart7!=0)FunUsart7((unsigned char)UART7->RDR);
  dummy=UART7->ISR; // Se limpian banderas
  dummy=UART7->RDR;
 }
 
  // Vector interrupci�n UART8
 void UART8_IRQHandler(void){
  unsigned int dummy;
  if(!(UART8->ISR&USART_ISR_RXNE))return;
   // Se ejecuta interrupci�n
  if(FunUsart8!=0)FunUsart8((unsigned char)UART8->RDR);
  dummy=UART8->ISR; // Se limpian banderas
  dummy=UART8->RDR;
 }
#endif 
}

Usart::Usart(){// Consteructor
 I[0]=0;
 F[0]=0;	
}

void Usart::Iniciar(unsigned int bps){// M�todo para iniciar puerto serial
 Iniciar(USART_RX,USART_TX,bps); 	
}
 
 // M�todo para iniciar puerto serial
void Usart::Iniciar(unsigned char rx,unsigned char tx,unsigned int bps){
unsigned long PC;
#if CortexM4
 switch(rx){ // Se eval�a el pin Rx para definir la USART
  case PA10:port=USART1; // PA10 para asignar USART1
   RX.FuncionAlternativa(rx,7); // Pin Rx y funci�n alternativa 7
   TX.FuncionAlternativa(tx,7); // Pin Tx y funci�n alternativa 7 
   RCC->APB2ENR|=RCC_APB2ENR_USART1EN; // Activa reloj USART1
   PC=PCLK2(); // Leer valor del reloj APB2
   prt=1; // Guarda n�mero del puerto
   break;
  case PA3:port=USART2; // PA3 para asignar USART2
   RX.FuncionAlternativa(rx,7); // Pin Rx y funci�n alternativa 7
   TX.FuncionAlternativa(tx,7); // Pin Tx y funci�n alternativa 7
   RCC->APB1ENR|=RCC_APB1ENR_USART2EN; // Activa reloj USART2
   PC=PCLK1(); // Leer valor del reloj APB1
   prt=2; // Guarda n�mero del puerto
   break;
  case PA12:port=USART6; // PA12 para asignar USART6
   RX.FuncionAlternativa(rx,8); // Pin Rx y funci�n alternativa 8
   TX.FuncionAlternativa(tx,8); // Pin Tx y funci�n alternativa 8
   RCC->APB2ENR|=RCC_APB2ENR_USART6EN; // Activa reloj USART6
   PC=PCLK2(); // Leer valor del reloj APB2
   prt=6; // Guarda n�mero del puerto
   break;
  default: return;
}
#endif
 
#if CortexM7 
 switch(rx){ // Se eval�a el pin Rx para definir la USART
  case PA10:
  case PB7:port=USART1; // PA10,PB7 para asignar USART1
   RX.FuncionAlternativa(rx,7); // Pin Rx y funci�n alternativa 7
   TX.FuncionAlternativa(tx,7); // Pin Tx y funci�n alternativa 7  
   RCC->APB2ENR|=RCC_APB2ENR_USART1EN; // Activa reloj USART1
   PC=PCLK2(); // Leer valor del reloj APB2
   prt=1; // Guarda n�mero del puerto
   break;
  case PA3:
  case PD6:port=USART2; // PA3, PD6 para asignar USART2
   RX.FuncionAlternativa(rx,7); // Pin Rx y funci�n alternativa 7
   TX.FuncionAlternativa(tx,7); // Pin Tx y funci�n alternativa 7  
   RCC->APB1ENR|=RCC_APB1ENR_USART2EN; // Activa reloj USART2
   PC=PCLK1(); // Leer valor del reloj APB1
   prt=2; // Guarda n�mero del puerto
   break;
  case PD9:port=USART3; // PD9 para asignar USART3
   RX.FuncionAlternativa(rx,7); // Pin Rx y funci�n alternativa 7
   TX.FuncionAlternativa(tx,7); // Pin Tx y funci�n alternativa 7  
   RCC->APB1ENR|=RCC_APB1ENR_USART3EN; // Activa reloj USART3
   PC=PCLK1(); // Leer valor del reloj APB1
   prt=3; // Guarda n�mero del puerto
   break;
  case PA1:
  case PC11:port=UART4; // PA1, PC11 para asignar UART4
   RX.FuncionAlternativa(rx,8); // Pin Rx y funci�n alternativa 8
   TX.FuncionAlternativa(tx,8); // Pin Tx y funci�n alternativa 8 
   RCC->APB1ENR|=RCC_APB1ENR_UART4EN; // Activa reloj UART4
   PC=PCLK1(); // Leer valor del reloj APB1
   prt=4; // Guarda n�mero del puerto
   break;   
  case PD2:port=UART5; // PD2 para asignar UART5
   RX.FuncionAlternativa(rx,8); // Pin Rx y funci�n alternativa 8
   TX.FuncionAlternativa(tx,8); // Pin Tx y funci�n alternativa 8  
   RCC->APB1ENR|=RCC_APB1ENR_UART5EN; // Activa reloj UART5
   PC=PCLK1(); // Leer valor del reloj APB1
   prt=5; // Guarda n�mero del puerto
   break;
  case PC7:
  case PG9:port=USART6; // PC7, PG9 para asignar USART6
   RX.FuncionAlternativa(rx,8); // Pin Rx y funci�n alternativa 8
   TX.FuncionAlternativa(tx,8); // Pin Tx y funci�n alternativa 8  
   RCC->APB2ENR|=RCC_APB2ENR_USART6EN; // Activa reloj USART6
   PC=PCLK2(); // Leer valor del reloj APB2
   prt=6; // Guarda n�mero del puerto
   break;
  case PE7:
  case PF6:port=UART7; // PE7, PF6 para asignar UART7
   RX.FuncionAlternativa(rx,8); // Pin Rx y funci�n alternativa 8
   TX.FuncionAlternativa(tx,8); // Pin Tx y funci�n alternativa 8 
   RCC->APB1ENR|=RCC_APB1ENR_UART7EN; // Activa reloj UART7
   PC=PCLK1(); // Leer valor del reloj APB1
   prt=7; // Guarda n�mero del puerto
   break;
  case PE0:port=UART8; // PE0 para asignar UART8
   RX.FuncionAlternativa(rx,8); // Pin Rx y funci�n alternativa 8
   TX.FuncionAlternativa(tx,8); // Pin Tx y funci�n alternativa 8  
   RCC->APB1ENR|=RCC_APB1ENR_UART8EN; // Activa reloj UART8
   PC=PCLK1(); // Leer valor del reloj APB1
   prt=8; // Guarda n�mero del puerto
   break;
  default: return;
}
#endif
 port->BRR=PC/bps; // Se define la velocidad en BPS
 port->CR1|=(USART_CR1_RE|USART_CR1_TE); // Se habilita Rx y Tx
 port->CR1|=USART_CR1_UE; // Se activa la USART o UART
}

void Usart::SetInicioFin(char *i,char *f){// Define inicio y fin de cadena
 sprintf(I,"%s",i);	
 sprintf(F,"%s",f);
}

void Usart::TxDato(unsigned char d){// M�todo para transmitir un dato
#if CortexM4
 while(!(port->SR&USART_SR_TXE)); // Se espera buffer disponible
 port->DR=d; // Se transmite dato 
#endif
#if CortexM7
 while(!(port->ISR&USART_ISR_TXE)); // Se espera buffer disponible
 port->TDR=d; // Se transmite dato
#endif
}
 
bool Usart::RxListo(void){ // M�todo para verificar si llego un dato
// Se verifica si hay dato disponible
#if CortexM4
 if( port->SR&USART_SR_RXNE )return true;
#endif
#if CortexM7
 if( port->ISR&USART_ISR_RXNE )return true;
#endif
 return false;
}
 
unsigned char Usart::RxDato(void){ // M�todo para leer un dato
// Se retorna dato le�do
#if CortexM4
 return port->DR;
#endif
#if CortexM7
 return port->TDR;
#endif
}
 
void Usart::Interrupcion(FunInt2 fun){// M�todo para asignar interrupci�n de Rx
 switch(prt){ // Eval�a puerto
  case 1:FunUsart1=fun; // Asigna vector de interrupci�n
   NVIC_EnableIRQ(USART1_IRQn); // Activa interrupci�n
  break;
  case 2:FunUsart2=fun; // Asigna vector de interrupci�n
   NVIC_EnableIRQ(USART2_IRQn); // Activa interrupci�n
  break;
  case 6:FunUsart6=fun; // Asigna vector de interrupci�n
   NVIC_EnableIRQ(USART6_IRQn); // Activa interrupci�n
  break;
#if CortexM7     
  case 3:FunUsart3=fun; // Asigna vector de interrupci�n
   NVIC_EnableIRQ(USART3_IRQn); // Activa interrupci�n
  break;
  case 4:FunUsart4=fun; // Asigna vector de interrupci�n
   NVIC_EnableIRQ(UART4_IRQn); // Activa interrupci�n
  break;
  case 5:FunUsart5=fun; // Asigna vector de interrupci�n
   NVIC_EnableIRQ(UART5_IRQn); // Activa interrupci�n
  break;
  case 7:FunUsart7=fun; // Asigna vector de interrupci�n
   NVIC_EnableIRQ(UART7_IRQn); // Activa interrupci�n
  break;
  case 8:FunUsart8=fun; // Asigna vector de interrupci�n
   NVIC_EnableIRQ(UART8_IRQn); // Activa interrupci�n
  break;
#endif
 }
 // Activa interrupci�n en puerto
 port->CR1|=USART_CR1_RXNEIE;
}

void Usart::DmaTx(bool d){// Activaci�n modo DMA recepci�n
 if(d)port->CR3 |= USART_CR3_DMAT;
 else port->CR3 &= ~USART_CR3_DMAT; 	
}

void Usart::DmaRx(bool d){// Activaci�n modo DMA transmisi�n
 if(d)port->CR3 |= USART_CR3_DMAR;
 else port->CR3 &= ~USART_CR3_DMAR;	
}

unsigned char Usart::operator = (unsigned char d){// Operador para enviar dato
 TxDato(d); // Transmite dato
 return d; // Retorna dato    
}

void Usart::Enviar(char *t){
 int n;
 // Transmite datos hasta car�cter nulo  
 n=0;while(I[n]!=0)TxDato(I[n++]);
 n=0;while(t[n]!=0)TxDato(t[n++]); 
 n=0;while(F[n]!=0)TxDato(F[n++]);
}

void Usart::operator = (char *t){// Operador para enviar cadena de texto
	Enviar(t);
}

Usart::operator unsigned char(){// Operador para esperar un dato
 while(!RxListo()); // Espera un dato de entrada
 return RxDato(); // Retorna dato le�do
}

void Usart::operator = (FunInt2 fun){// Operador para asignar interrupci�n de Rx
 Interrupcion(fun);
}



