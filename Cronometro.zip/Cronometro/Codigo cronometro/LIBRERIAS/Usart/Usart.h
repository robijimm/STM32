// C�digo Ejemplo 13 2 //
// Archivo *.h //
#ifndef _USART_H
#define _USART_H
#include "Pin.h"
class Usart{// Clase Usart
private:
 char I[10],F[10];	
 Pin TX,RX;
 USART_TypeDef *port; // Estructura de USART
 unsigned char prt;
public:
 Usart();	
 // M�todo para iniciar puerto serial
 void Iniciar(unsigned char rx,unsigned char tx,unsigned int bps=9600);
 void Iniciar(unsigned int bps=9600);
 void Interrupcion(FunInt2 fun);// M�todo para asignar interrupci�n de Rx
 void TxDato(unsigned char d);// M�todo para transmitir un dato
 bool RxListo(void);// M�todo para verificar si llego un dato
 void SetInicioFin(char *i,char *f);// Define inicio y fin de cadena 
 void DmaTx(bool d);// Activaci�n modo DMA recepci�n
 void DmaRx(bool d);// activaci�n modo DMA transmisi�n
 void Enviar(char *t);// Envia cadena de texto
 unsigned char RxDato(void);// M�todo para leer un dato
 unsigned char operator = (unsigned char d); // Operador para enviar dato
 void operator = (char *t);// Operador para enviar cadena de texto
 operator unsigned char();// Operador para esperar un dato
 void operator = (FunInt2 fun);// Operador para asignar interrupci�n de Rx
};
#endif




