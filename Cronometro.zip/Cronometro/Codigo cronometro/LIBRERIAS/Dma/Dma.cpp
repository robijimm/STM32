// C�digo Ejemplo 18 3 // 
// Archivo *.cpp //
#include "Dma.h"

Dma::Dma(){dma=1;}// Constructor

void Dma::SetDma(int d){// M�todo selector DMA
 switch(d){	 
  case 2:RCC->AHB1ENR|=RCC_AHB1ENR_DMA2EN;dma=2;break;
  default:RCC->AHB1ENR|=RCC_AHB1ENR_DMA1EN;dma=1;break;
 }
}

void Dma::SetStream(int s){// M�todo selector de flujo
 switch(dma){
  case 2:
  switch(s){
   case 1:S=DMA2_Stream1;break;
   case 2:S=DMA2_Stream2;break;
   case 3:S=DMA2_Stream3;break;
   case 4:S=DMA2_Stream4;break;
   case 5:S=DMA2_Stream5;break;
   case 6:S=DMA2_Stream6;break;
   case 7:S=DMA2_Stream7;break;
   default:S=DMA2_Stream0;break;
  } break;
  default:
  switch(s){
   case 1:S=DMA1_Stream1;break;
   case 2:S=DMA1_Stream2;break;
   case 3:S=DMA1_Stream3;break;
   case 4:S=DMA1_Stream4;break;
   case 5:S=DMA1_Stream5;break;
   case 6:S=DMA1_Stream6;break;
   case 7:S=DMA1_Stream7;break;
   default:S=DMA1_Stream0;break;
  } break;
 } 
}

void Dma::Enabled(bool e){// M�todo activador
 if(e)S->CR|=DMA_SxCR_EN;
 else S->CR&= ~DMA_SxCR_EN;
}

void Dma::TransDirection(unsigned char d){// M�todo de direcci�n de flujo
 S->CR&= ~DMA_SxCR_DIR;
 S->CR|=((d&3)<<DMA_SxCR_DIR_Pos);
}

void Dma::Circular(bool c){// Activador circular
 if(c)S->CR|=DMA_SxCR_CIRC;
 else S->CR&= ~DMA_SxCR_CIRC;
}

void Dma::PerInc(bool i){// Activador incremento perif�rico
 if(i)S->CR|=DMA_SxCR_PINC;
 else S->CR&= ~DMA_SxCR_PINC;
}

void Dma::MemInc(bool i){// Activador incremento memoria
 if(i)S->CR|=DMA_SxCR_MINC;
 else S->CR&= ~DMA_SxCR_MINC;
}

void Dma::PerCont(bool c){// Activador control de flujo
 if(c)S->CR|=DMA_SxCR_PFCTRL;
 else S->CR&= ~DMA_SxCR_PFCTRL;
}

void Dma::PerSize(int s){// Tama�o palabra perif�rico
 S->CR&= ~DMA_SxCR_PSIZE;
 switch(s){
  case 16:S->CR|=(1<<DMA_SxCR_PSIZE_Pos);break;
  case 32:S->CR|=(2<<DMA_SxCR_PSIZE_Pos);break;
  default:break;
 }
}

void Dma::MemSize(int s){// Tama�o palabra memoria
 S->CR&= ~(DMA_SxCR_MSIZE);
 switch(s){
  case 16:S->CR|=(1<<DMA_SxCR_MSIZE_Pos);break;
  case 32:S->CR|=(2<<DMA_SxCR_MSIZE_Pos);break;
  default:break;
 }
}

void Dma::SetCanal(int c){// Canal de trabajo
 S->CR&= ~DMA_SxCR_CHSEL;
 switch(c){
  case 1:S->CR|=(1<<DMA_SxCR_CHSEL_Pos);break;
  case 2:S->CR|=(2<<DMA_SxCR_CHSEL_Pos);break;
  case 3:S->CR|=(3<<DMA_SxCR_CHSEL_Pos);break;
  case 4:S->CR|=(4<<DMA_SxCR_CHSEL_Pos);break;
  case 5:S->CR|=(5<<DMA_SxCR_CHSEL_Pos);break;
  case 6:S->CR|=(6<<DMA_SxCR_CHSEL_Pos);break;
  case 7:S->CR|=(7<<DMA_SxCR_CHSEL_Pos);break;
  default:break;
 }
}

void Dma::SetLon(unsigned short l){// Longitud de informaci�n
 S->NDTR=l;
}

void Dma::SetPerDir(unsigned int dir){// Direcci�n del perif�rico
 S->PAR=dir;
}

void Dma::SetMemDir(unsigned int dir){// Direcci�n de la memoria
 S->M0AR=dir;
 S->CR&= ~DMA_SxCR_DBM;
}

void Dma::SetMemDir(unsigned int dir0,unsigned int dir1){// Direcciones de memoria
 S->M0AR=dir0;
 S->M1AR=dir1;
 S->CR|=DMA_SxCR_DBM;
}
