// C�digo Ejemplo 18 2 // 
// Archivo *.h //
#ifndef _DMA_H
#define _DMA_H
#include "Pin.h"
//Definiciones
#define PerToMem 0x00
#define MemToPer 0x01
#define MemToMem 0x02
class Dma{// Clase DMA
private:
 unsigned char dma;	
 DMA_Stream_TypeDef *S;
public:
 Dma();
 void SetDma(int d=1);// M�todo selector DMA 
 void SetStream(int s=0);// M�todo selector de flujo
 void Enabled(bool e=true);// M�todo activador
 void TransDirection(unsigned char d=MemToMem);// M�todo de direcci�n de flujo
 void Circular(bool c=false);// Activador circular
 void PerInc(bool i=false);// Activador incremento perif�rico
 void MemInc(bool i=false);// Activador incremento memoria
 void PerCont(bool c=false);// Activador control de flujo
 void PerSize(int s=8);// Tama�o palabra perif�rico
 void MemSize(int s=8);// Tama�o palabra memoria
 void SetCanal(int c=0);// Canal de trabajo
 void SetLon(unsigned short l);// Longitud de informaci�n
 void SetPerDir(unsigned int dir);// Direccion del periferico
 void SetMemDir(unsigned int dir);// Direccion de la memoria
 void SetMemDir(unsigned int dir0,unsigned int dir1);// Direcciones de memoria
};
#endif




