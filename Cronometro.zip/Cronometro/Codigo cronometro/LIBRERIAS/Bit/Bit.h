// C�digo Ejemplo 5 42//
// Archivo *.h //
#ifndef _BIT_H
#define _BIT_H
class Bit{// Clase Bit
protected:
 bool E;	
public:
 Bit();// Constructor
 virtual void SetBit(bool e);// Escritor de estado l�gico
 virtual bool GetBit(void);// Lector de estado l�gico	
 bool operator = (bool e);// Operador igual
 bool operator = (Bit &b);// Operador igual
 operator bool();// Forzador a bool 
 bool operator ! (void);// Operaci�n negaci�n
 bool operator & (bool e);// Operador and
 bool operator | (bool e);// Operador or
 bool operator ^ (bool e);// Operador xor
 void operator &= (bool e);// Operador and igual
 void operator |= (bool e);// Operador or igual
 void operator ^= (bool e);// Operador xor igual
};
#endif


