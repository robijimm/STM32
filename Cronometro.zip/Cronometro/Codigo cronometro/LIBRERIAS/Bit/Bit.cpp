// C�digo Ejemplo 5 43//
// Archivo *.cpp //
#include "Bit.h"
Bit::Bit(){E=false;}
void Bit::SetBit(bool e){E=e;}
bool Bit::GetBit(void){return E;}
bool Bit::operator = (bool e){SetBit(e);return E;}
bool Bit::operator = (Bit &b){SetBit((bool)b);return E;}
Bit::operator bool(){return GetBit();}
bool Bit::operator ! (void){return !GetBit();}
bool Bit::operator & (bool e){return GetBit()&e;}
bool Bit::operator | (bool e){return GetBit()|e;}
bool Bit::operator ^ (bool e){return GetBit()^e;}
void Bit::operator &= (bool e){SetBit(GetBit()&e);}
void Bit::operator |= (bool e){SetBit(GetBit()|e);}
void Bit::operator ^= (bool e){SetBit(GetBit()^e);}


