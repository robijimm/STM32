// C�digo Ejemplo 16 19 // 
// Archivo *.cpp //
#include "Contador.h"
void Contador::IniciarContador(unsigned char tmr,
                               unsigned char can,unsigned char pin,bool fl){
 Pin P; // Objeto Pin para configurar pin de entrada
 SetTimer(tmr); // Asigna Timer
 switch(tmr){
   // Activa funci�n alternativa Timer 1 y 2
  case 1:case 2:P.FuncionAlternativa(pin,1);break;
   // Activa funci�n alternativa Timer 3, 4 y 5
  case 3:case 4:case 5:P.FuncionAlternativa(pin,2);break;
   // Activa funci�n alternativa para el resto de Timers
  default:P.FuncionAlternativa(pin,3);break;
 }

  // Activa pull-up o down seg�n flanco
 if(fl)P.PullUp(); else P.PullDown();
 switch(can){
  case 1:t->CCMR1|=1UL; // Fuente de conteo canal 1
   t->SMCR|=7UL; // Fuente de conteo externa
    // Define flanco en canal 1
   if(fl)t->CCER|=TIM_CCER_CC1P;
   else t->CCER&= ~TIM_CCER_CC1P;
   t->SMCR|=5UL<<TIM_SMCR_TS_Pos; // Activa entrada externa 1
   t->CNT=0; // Inicia contador en 0
  break;
  case 2:t->CCMR1|=2UL; // Fuente de conteo canal 2
   t->SMCR|=7UL; // Fuente de conteo externa
    // Define flanco en canal 2
   if(fl)t->CCER|=TIM_CCER_CC2P;
   else t->CCER&= ~TIM_CCER_CC2P; 
   t->SMCR|=6UL<<TIM_SMCR_TS_Pos; // Activa entrada externa 2
   t->CNT=0; // Inicia contador en 0
  break;
 }
}
 
 // M�todo para iniciar el conteo 
void Contador::SetConteo(unsigned int n){t->CNT=n;}
 
 // M�todo para leer el conteo
unsigned int Contador::GetConteo(void){return t->CNT;}


