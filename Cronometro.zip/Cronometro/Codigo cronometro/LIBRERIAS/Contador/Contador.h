// C�digo Ejemplo 16 18 // 
// Archivo *.h //
#ifndef _CONTADOR_H
#define _CONTADOR_H
#include "Timer.h"
class Contador : public Timer{// Clase Contador
public:
  // M�todo para iniciar Contador  
 void IniciarContador(unsigned char tmr,unsigned char can,
                      unsigned char pin,bool fl);
 void SetConteo(unsigned int n); // M�todo para iniciar el conteo
 unsigned int GetConteo(void); // M�todo para leer el conteo
};
#endif



