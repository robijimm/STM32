// C�digo Ejemplo 12 3 // 
// Archivo *.cpp //
#include "Dac.h"
#if defined(STM32F746xx) // C�digo solo para F746 
 // M�todo para iniciar canales
void Dac::Iniciar(bool dac1,bool dac2){   
 RCC->APB1ENR|=RCC_APB1ENR_DACEN; // Activa reloj del DAC 
 if(dac1){ // Activa pin y m�dulo canal 1
  C1.Analogo(PA4); 
  DAC->CR|=DAC_CR_EN1;   
 }   
 if(dac2){ // Activa pin y m�dulo canal 2
  C2.Analogo(PA5); 
  DAC->CR|=DAC_CR_EN2;
 }  
}   

 // Set dato en canal 1 a 12 bits
void Dac::Can1Bit12(unsigned int v){
 DAC->DHR12R1=v; // Set valor 
}
 
 // Set dato en canal 2 a 12 bits
void Dac::Can2Bit12(unsigned int v){
 DAC->DHR12R2=v; // Set valor 
}
 
 // Set dato en canal 1 y 2 a 12 bits
void Dac::CanBit12(unsigned int v1,unsigned int v2){
 DAC->DHR12RD=(v1&0xFFF)|((v2&0xFFF)<<16); // Set valores 
}
 
 // Set dato en canal 1 a 8 bits
void Dac::Can1Bit8(unsigned char v){
 DAC->DHR8R1=v; // Set valor  
}
 
 // Set dato en canal 2 a 8 bits
void Dac::Can2Bit8(unsigned char v){
 DAC->DHR8R2=v; // Set valor  
}
 
 // Set dato en canal 1 y 2 a 8 bits
void Dac::CanBit8(unsigned char v1,unsigned char v2){
 DAC->DHR8RD=v1|(v2<<8); // Set valores   
}
#endif

