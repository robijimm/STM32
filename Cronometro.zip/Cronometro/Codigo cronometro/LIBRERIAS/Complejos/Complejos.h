// C�digo Ejemplo 9 4 // 
// Archivo *.h //
#ifndef _COMPLEJOS_H
#define _COMPLEJOS_H
#include <math.h>
// Definici�n del valor constante PI
const double V_PI =4.0*atan(1.0);
const double V_2PI=8.0*atan(1.0);

// Definici�n de la clase Complejo
class Complejo{
// Declaraci�n de items p�blicos
public:
 double R,I; // Parte real e imaginaria
 Complejo(); // Constructor
 void SetCar(double r,double i); // Set valor cartesiano
 void SetPol(double m,double a); // Set valor polar
 double GetMag(void); // Leer magnitud del complejo
 double GetAng(void); // Leer �ngulo del complejo
 int operator = (int s); // Operador igualdad con esteros
 Complejo operator = (Complejo s); // Operador igualdad con complejos
 double operator = (double s); // Operador igualdad con doubles
 Complejo operator + (Complejo s); // Operador suma con complejos
 Complejo operator - (Complejo s); // Operador resta con complejos
 Complejo operator + (double s); // Operador suma con doubles
 Complejo operator - (double s); // Operador resta con doubles
 Complejo operator * (Complejo s); // Operador producto con complejos
 Complejo operator * (double s); // Operador producto con doubles
 Complejo operator / (Complejo s); // Operador divisi�n con complejos
 Complejo operator / (double s); // Operador divisi�n con doubles
 Complejo operator ! (void); // Operador negaci�n, para hacer complemento
 bool operator == (Complejo s); // Operador comparaci�n igualdad con complejos
 bool operator != (Complejo s); // Operador diferencia con complejos
 bool operator == (double s); // Operador igualdad con doubles
 bool operator != (double s); // Operador diferencia con doubles
 bool operator < (Complejo s); // Operador menor que complejo
 bool operator > (Complejo s); // Operador mayor que complejo
 bool operator <= (Complejo s); // Operador menor o igual que complejo
 bool operator >= (Complejo s); // Operador mayor o igual que complejo
 void operator ++ (void); // Operador incremento
 void operator -- (void); // Operador decremento
 Complejo operator - (void); // Operador negativo
 void operator += (Complejo s); // Operador m�s igual con complejo
 void operator -= (Complejo s); // Operador menos igual con complejo
 void operator += (double s); // Operador m�s igual con double
 void operator -= (double s); // Operador menos igual con double
 void operator *= (Complejo s); // Operador por igual con complejo
 void operator /= (Complejo s); // Operador dividido igual con complejo
};

// Operadores externos a la clase 
Complejo operator + (double d,Complejo c); // Operador Suma
Complejo operator - (double d,Complejo c); // Operador resta
Complejo operator * (double d,Complejo c); // Operador producto
Complejo operator / (double d,Complejo c); // Operador divisi�n
#endif
