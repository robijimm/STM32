// C�digo Ejemplo 9 5 // 
// Archivo *.cpp //
#include "Complejos.h"

Complejo::Complejo(){ // Constructor
  // Inicia el complejo en 0  
 R=0;
 I=0;   
}

void Complejo::SetCar(double r,double i){ // Set valor cartesiano
  // Asigna valor cartesiano  
 R=r;
 I=i;   
}
 
void Complejo::SetPol(double m,double a){ // Set valor polar
  // Asigna valor polar       
 R=m*cos(a);
 I=m*sin(a);    
}
 
double Complejo::GetMag(void){ // Leer magnitud del complejo
 return sqrt(R*R+I*I); // Retorna magnitud del complejo
}

double Complejo::GetAng(void){ // Leer �ngulo del complejo
  // Se eval�an las diferentes posibilidades
  // verificando los cuadrantes y magnitudes  
  // para calcular el �ngulo del complejo     
 if(R==0.0&&I==0.0)return 0.0;
 if(R==0.0){if(I>0.0)return V_PI/2.0; return -V_PI/2.0;}
 if(I==0.0){if(R>0.0)return 0.0; return V_PI;}
 if(R>0.0&&I>0.0)return atan(I/R);
 if(R<0.0&&I>0.0)return  V_PI+atan(I/R);
 if(R<0.0&&I<0.0)return -V_PI+atan(I/R);
 if(R>0.0&&I<0.0)return atan(I/R);
 return 0.0;     
}
 
int Complejo::operator = (int s){ // Operador igualdad con enteros
  // Se iguala la parte real  
 R=s;
 I=0.0;
 return s;
}   
 
Complejo Complejo::operator = (Complejo s){ // Operador igualdad con complejos
  // Se iguala todo el complejo   
 R=s.R;
 I=s.I; 
 return s;
}

double Complejo::operator = (double s){ // Operador igualdad con doubles
  // Se iguala la parte real  
 R=s;
 I=0.0;
 return s;
}

Complejo Complejo::operator + (Complejo s){ // Operador suma con complejos
  // Se realiza la suma compleja  
 Complejo r;
 r.R=R+s.R;
 r.I=I+s.I;
  // se retorna el resultado  
 return r;  
}   

Complejo Complejo::operator - (Complejo s){ // Operador resta con complejos
  // Se realiza la resta compleja 
 Complejo r;
 r.R=R-s.R;
 r.I=I-s.I;
  // se retorna el resultado  
 return r;  
}

Complejo Complejo::operator + (double s){ // Operador suma con doubles
  // Se realiza la suma compleja  
 Complejo r;
 r.R=R+s;
 r.I=I;
  // se retorna el resultado  
 return r;  
}
 
Complejo Complejo::operator - (double s){ // Operador resta con doubles
  // Se realiza la suma compleja  
 Complejo r;
 r.R=R-s;
 r.I=I;
  // se retorna el resultado  
 return r;  
}
 
Complejo Complejo::operator * (Complejo s){ // Operador producto con complejos
  // C�lculo del producto complejo    
 Complejo r;
 r.R=R*s.R-I*s.I;
 r.I=R*s.I+s.R*I;
  // se retorna el resultado      
 return r;
}

Complejo Complejo::operator * (double s){ // Operador producto con doubles
  // C�lculo del producto     
 Complejo r;
 r.R=R*s;
 r.I=I*s;
  // se retorna el resultado      
 return r;  
}

Complejo Complejo::operator / (Complejo s){ // Operador divisi�n con complejos
 Complejo r;
 double div;
  // C�lculo de la divisi�n compleja  
 div=s.R*s.R+s.I*s.I;
 r.R=(R*s.R+I*s.I)/div;
 r.I=(s.R*I-R*s.I)/div;
  // se retorna el resultado  
 return r;
}

Complejo Complejo::operator / (double s){ // Operador divisi�n con doubles
 Complejo r;
  // C�lculo de la divisi�n   
 r.R=R/s;
 r.I=I/s;
  // se retorna el resultado  
 return r;  
}

Complejo Complejo::operator ! (void){ // Operador negaci�n, para hacer complemento
 Complejo r;
 r.R=R; 
 r.I=-I;
 return r;  
}

 // Operador comparaci�n igualdad con complejos
bool Complejo::operator == (Complejo s){
  // Eval�a si la parte real e imaginaria son iguales 
 if(R==s.R&&I==s.I)return true;
 return false;  
}
 
bool Complejo::operator != (Complejo s){ // Operador diferencia con complejos
  // Eval�a si la parte real e imaginaria son diferentes  
 if(R==s.R&&I==s.I)return false;
 return true;   
}
 
bool Complejo::operator == (double s){ // Operador igualdad con doubles
  // Eval�a si las partes reales son iguales  
 if(R==s&&I==0.0)return true;
 return false;
}
 
bool Complejo::operator != (double s){ // Operador diferencia con doubles
  // Eval�a si las partes reales son diferentes
 if(R==s&&I==0.0)return false;
 return true;
}

bool Complejo::operator < (Complejo s){ // Operador menor que complejo
  // Se eval�an las magnitudes menores que    
 if(R==s.R){
  if(I<s.I)return true;
  return false;
 }
 if(R<s.R)return true;
 return false;  
}

bool Complejo::operator > (Complejo s){ // Operador mayor que complejo
  // Se eval�an las magnitudes mayores que    
 if(R==s.R){
  if(I>s.I)return true;
  return false;
 }
 if(R>s.R)return true;
 return false;  
}

bool Complejo::operator <= (Complejo s){ // Operador menor o igual que complejo
  // Se eval�an las magnitudes menor o igual que
 if(R==s.R&&I==s.I)return true;
 if(R==s.R){ 
  if(I<s.I)return true;
  return false;
 }
 if(R<s.R)return true;
 return false;  
}

bool Complejo::operator >= (Complejo s){ // Operador mayor o igual que complejo
  // Se eval�an las magnitudes mayor o igual que
 if(R==s.R&&I==s.I)return true;
 if(R==s.R){
  if(I>s.I)return true;
  return false;
 }
 if(R>s.R)return true;
 return false;  
}

void Complejo::operator ++ (void){ // Operador incremento
 R+=1.0; // Incremento real
}

void Complejo::operator -- (void){ // Operador decremento
 R-=1.0; // Decremento real   
}

Complejo Complejo::operator - (void){ // Operador negativo
  // Se retorna el negativo del complejo  
 Complejo r;
 r.R=-R;
 r.I=-I;    
 return r;
}

void Complejo::operator += (Complejo s){ // Operador m�s igual con complejo
  // Suma y guarda el complejo    
 R+=s.R;
 I+=s.I;
}

void Complejo::operator -= (Complejo s){ // Operador menos igual con complejo
  // Resta y guarda el complejo   
 R-=s.R;
 I-=s.I;    
}
 
void Complejo::operator += (double s){ // Operador m�s igual con double
  // Suma y guarda la parte real  
 R+=s;
}

void Complejo::operator -= (double s){ // Operador menos igual con double
  // Resta y guarda la parte real 
 R-=s;
}

void Complejo::operator *= (Complejo s){ // Operador por igual con complejo
  // Multiplica el complejo por s, y se guarda    
 Complejo a,r;
 a.R=R;
 a.I=I;
 r=a*s;
 R=r.R;
 I=r.I; 
}
 
void Complejo::operator /= (Complejo s){ // Operador dividido igual con complejo
  // Divide el complejo por s, y se guarda    
 Complejo a,r;
 a.R=R;
 a.I=I;
 r=a/s;
 R=r.R;
 I=r.I; 
}
 
 // Operador suma doble y complejo  
Complejo operator + (double d,Complejo c){
  // Se realiza la operaci�n, conmutando la suma  
 Complejo r=c;
 r+=d;
 return r;
}
 
Complejo operator - (double d,Complejo c){
  // Se realiza la operaci�n, conmutando la resta 
 Complejo r=-c;
 r+=d;
 return r;
}
 
Complejo operator * (double d,Complejo c){
  // Se realiza la operaci�n, conmutando el producto  
 Complejo r;
 r=c*d;
 return r;
}

Complejo operator / (double d,Complejo c){
  // Se realiza la operaci�n de divisi�n  
 Complejo r;
 r=d;
 return r/c;
}
