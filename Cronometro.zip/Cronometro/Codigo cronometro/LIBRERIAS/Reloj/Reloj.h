// C�digo Ejemplo 6 9//
// Archivo *.h //
#ifndef _RELOJ_H
#define _RELOJ_H
#include "Stm32f.h"
// Definici�n de constantes // 
const double HPREFac[] = {1,2,4,8,16,64,128,256,512}; 
const double PLLPFac[] = {2,4,6,8}; 
const double PPREFac[] = {1,2,4,8,16}; 
// Clase Reloj //
class Reloj{
private:
 unsigned int SetReloj(bool ie,int f);//M�todo para configurar reloj     
public:
 void SetHSION(bool e); // M�todo para activar HSI    
 void SetHSEON(bool e); // M�todo para activar HSE
 void SetPLLON(bool e); // M�todo para activar PLL
 unsigned int GetHCLK(void); // M�todo para leer HCLK
 unsigned int GetPCLK1(void); // M�todo para leer PCLK1
 unsigned int GetPCLK2(void); // M�todo para leer PCLK2
 void SetPLLSRC(unsigned char src); // M�todo para activar fuente del PLL
 void SetPLLM(unsigned char m); // M�todo para configurar PLLM 
 void SetPLLN(unsigned short n); // M�todo para configurar PLLN 
 void SetPLLP(unsigned char p); // M�todo para configurar PLLP
 void SetSW(unsigned char sw); // M�todo para configurar fuente de reloj 
 void SetHPRE(unsigned short h); // M�todo para configurar HPRE
 void SetPPRE1(unsigned char p); // M�todo para configurar PPRE1
 void SetPPRE2(unsigned char p); // M�todo para configurar PPRE2
 unsigned int SetRelojHSI(int f); // M�todo para configurar reloj HSI 
 unsigned int SetRelojHSE(int f); // M�todo para configurar reloj HSE
};
#endif

