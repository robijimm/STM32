// C�digo Ejemplo 16 6 // 
// Archivo *.h //
#ifndef _PWM_H
#define _PWM_H
#include "Timer.h" 
class Pwm : public Timer{// Clase Pwm
private:
 unsigned char Can; 
public:
 Pwm(); // Constructor    
 void IniciarPwm(unsigned char tmr,double fre); // M�todo para iniciar PWM
 void PinCanal(unsigned char pin); // M�todo para configurar pin
 void ActivarCanal(unsigned char can); // M�todo para activar canal
 void InvertirPolaridad(void); // M�todo para invertir la polaridad del canal
 void SetDuty(unsigned char can,double duty); // M�todo para ajustar ciclo �til
 void SetPwm(unsigned char can,unsigned int duty); // M�todo para ajustar ciclo �til
 unsigned int GetApuntador(unsigned char can);
};
#endif



