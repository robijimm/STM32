// C�digo Ejemplo 14 3 // 
// Archivo *.h //
#ifndef _I2CBUS_H
#define _I2CBUS_H
class I2cBus{// Clase I2cBus
protected:
public:
 I2cBus();  
 // M�todos para iniciar el puerto    
 virtual void Iniciar(unsigned char sda,unsigned char scl,unsigned int vel);
 virtual void Iniciar(unsigned int vel);
 virtual void Iniciar(void);
 virtual bool TestId(unsigned char id);
 // M�todo para transmitir una cadena de datos 
 virtual void TxI2C(unsigned char adr,const unsigned char *dat,int n);
 // M�todo para transmitir un dato repetido 
 virtual void TxI2C(unsigned char adr,unsigned char dat,int n);
 // M�todo para transmitir un dato
 virtual void TxI2C(unsigned char adr,unsigned char dat);
 // M�todo para recibir un dato
 virtual unsigned char RxI2C(unsigned char adr);
 // M�todo para recibir una cadena de datos
 virtual void RxI2C(unsigned char adr,unsigned char *dat,int n);   
};
#endif

