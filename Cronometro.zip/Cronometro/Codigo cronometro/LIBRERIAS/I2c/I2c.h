// C�digo Ejemplo 14 5 // 
// Archivo *.h //
#ifndef _I2C_H
#define _I2C_H
 
#include "I2cBus.h"
#include "Pin.h"
#include "Delay.h"
#include <math.h>
 
class I2c : public I2cBus{// Clase I2c
protected:
 unsigned int Dummy; // Variables de trabajo  
 Pin SDA,SCL; // Pines Datos y Reloj     
 I2C_TypeDef *port; // Estructura I2C
public:
 // M�todos para iniciar el puerto    
 void Iniciar(unsigned char sda,unsigned char scl,unsigned int v);
 void Iniciar(unsigned int v);
 void Iniciar(void);
 bool TestId(unsigned char id);// Tester de direcci�n esclavo
 void DmaTx(bool d);// Activador DMA Tx
 void DmaRx(bool d);// Activador DMA Rx
 // M�todo para transmitir una cadena de datos 
 void TxI2C(unsigned char adr,const unsigned char *dat,int n);
 // M�todo para transmitir un dato repetido 
 void TxI2C(unsigned char adr,unsigned char dat,int n);
 // M�todo para transmitir un dato
 void TxI2C(unsigned char adr,unsigned char dat);
 // M�todo para recibir un dato
 unsigned char RxI2C(unsigned char adr);
 // M�todo para recibir una cadena de datos
 void RxI2C(unsigned char adr,unsigned char *dat,int n);   
};
#endif




