// C�digo Ejemplo 15 5 // 
// Archivo *.h //
#ifndef _SPI_H
#define _SPI_H
#include "SpiBus.h"
#include "Pin.h"
#include <math.h>
class Spi : public SpiBus{// Clase SPI
private:    
 SPI_TypeDef * port; // Estructura SPI
 Pin Miso,Mosi,Clk; // Pines SPI
public:
 Spi();
  // M�todo de inicio puerto SPI
 void Iniciar(void);
 void Iniciar(unsigned int vel);
 void Iniciar(unsigned char mosi,unsigned char miso,
              unsigned char clk,unsigned int vel);
 void Modo(unsigned char m);// Modo SPI
 void Msb(void);// MSB Modo
 void Lsb(void);// LSB Modo
 void DmaTx(bool d);// Activador DMA Tx
 void DmaRx(bool d);// Activador DMA Rx
  // M�todo de transmisi�n y recepci�n serial
 unsigned char TxRxDato(unsigned char tx);
  // Operador igualdad para transmitir
 unsigned char operator = (unsigned char tx);
  // Operador get unsigned char para recibir
 operator unsigned char();
};
#endif



