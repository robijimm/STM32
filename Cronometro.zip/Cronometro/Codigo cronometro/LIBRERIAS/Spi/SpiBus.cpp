// C�digo Ejemplo 15 4 // 
// Archivo *.cpp //
#include "SpiBus.h"

SpiBus::SpiBus(){}
 // M�todo de inicio puerto SPI
void SpiBus::Iniciar(void){}
void SpiBus::Iniciar(unsigned int vel){}
void SpiBus::Iniciar(unsigned char mosi,unsigned char miso,
                     unsigned char clk,unsigned int vel){}
void SpiBus::Iniciar(unsigned char mosi,unsigned char miso,
                     unsigned char clk,unsigned int vel,bool cp,bool cf){}
void SpiBus::Modo(unsigned char m){}			
void SpiBus::Msb(void){}
void SpiBus::Lsb(void){}	
 // M�todo de transmisi�n y recepci�n serial
unsigned char SpiBus::TxRxDato(unsigned char tx){}
 // Operador igualdad para transmitir
unsigned char SpiBus::operator = (unsigned char tx){}
 // Operador get unsigned char para recibir
SpiBus::operator unsigned char(){}


