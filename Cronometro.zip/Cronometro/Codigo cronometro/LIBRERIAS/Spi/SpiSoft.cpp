// C�digo Ejemplo 15 8 // 
// Archivo *.cpp //
#include "SpiSoft.h"

SpiSoft::SpiSoft(){ClkPol=false;MLsb=false;modo=0;}
//M�todo de inicio puerto SPI
void SpiSoft::Iniciar(void){Iniciar(500000);}
void SpiSoft::Iniciar(unsigned int vel){Iniciar(SPI_MOSI,SPI_MISO,SPI_CLK,vel);}
void SpiSoft::Iniciar(unsigned char mosi,unsigned char miso,
                      unsigned char clk,unsigned int vel){
 ClkPol=0;
 IniciarDelay();
 v=250000/vel;
 Mosi>>mosi;Mosi=0;
 Miso<<miso;
 Clk>>clk;
 Clk=ClkPol;
}

void SpiSoft::Modo(unsigned char m){// Modo SPI
 modo=m;
 ClkPol=0;
 if(m&2)ClkPol=1;
 Clk=ClkPol;
}

void SpiSoft::Msb(void){MLsb=false;}// Modo MSB

void SpiSoft::Lsb(void){MLsb=true;}// Modo LSB

unsigned char SpiSoft::TxRxDato(unsigned char tx){
 dat=0;
 switch(modo){
  case 0:
  //Modo 0//
  for(int n=0;n<8;n++){
   Mosi=tx&Peso[MLsb][n];Delay_us(v);
   Clk= !ClkPol;Delay_us(v);
   if(Miso==true)dat+=Peso[MLsb][n];Delay_us(v);
   Clk=ClkPol;Delay_us(v);
  }
  break;
  case 1:
  //Modo 1//
  for(int n=0;n<8;n++){
   Clk= !ClkPol;Delay_us(v);
   Mosi=tx&Peso[MLsb][n];Delay_us(v);
   Clk=ClkPol;Delay_us(v);
   if(Miso==true)dat+=Peso[MLsb][n];Delay_us(v);
  }	
  break;
  case 2:
  //Modo 2//
  for(int n=0;n<8;n++){
   Mosi=tx&Peso[MLsb][n];Delay_us(v);
   Clk= !ClkPol;Delay_us(v);
   if(Miso==true)dat+=Peso[MLsb][n];Delay_us(v);
   Clk=ClkPol;Delay_us(v);
  }
  break;
  case 3:
  //Modo 3//
  for(int n=0;n<8;n++){
   Clk= !ClkPol;Delay_us(v);
   Mosi=tx&Peso[MLsb][n];Delay_us(v);
   Clk=ClkPol;Delay_us(v);
   if(Miso==true)dat+=Peso[MLsb][n];Delay_us(v);
  }
  break;
 }
 return dat;
}

unsigned char SpiSoft::operator = (unsigned char tx){TxRxDato(tx);return tx;}
SpiSoft::operator unsigned char(){return TxRxDato(0);}

