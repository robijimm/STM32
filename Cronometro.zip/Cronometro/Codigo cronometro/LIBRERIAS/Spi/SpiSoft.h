// C�digo Ejemplo 15 7 // 
// Archivo *.h //
#ifndef _SPISOF_H
#define _SPISOF_H

#include "SpiBus.h"
#include "Pin.h"
#include "Delay.h"

const unsigned char Peso[2][8] ={ 
 {128,64,32,16,8,4,2,1},
 {1,2,4,8,16,32,64,128}
};	

class SpiSoft : public SpiBus// Clase SPISoft
{
private:    
 Pin Miso,Mosi,Clk;
 bool ClkPol,MLsb;
 unsigned int v;
 unsigned char dat,modo;
public:
 SpiSoft();	
 //M�todo de inicio puerto SPI
 void Iniciar(void);
 void Iniciar(unsigned int vel);
 void Iniciar(unsigned char mosi,unsigned char miso,unsigned char clk,unsigned int vel);
 void Modo(unsigned char m);// Modo SPI
 void Msb(void);// Modo MSB
 void Lsb(void);// Modo LSB
 //M�todo de transmisi�n y recepci�n serial
 unsigned char TxRxDato(unsigned char tx);
 //Operador igualdad para transmitir
 unsigned char operator = (unsigned char tx);
 //Operador get unsigned char para recibir
 operator unsigned char();
};  
#endif





