#include "Dis7Seg.h"

Dis7Seg::Dis7Seg(){// Constructor
 n=0;
 B=0;	
 pos=0;
 Dat=0;
 Activar(0,0);
}

Dis7Seg::~Dis7Seg(){// Destructor
 delete [] Text;
}

void Dis7Seg::Activar(bool s,bool c){// Activador
 SegAct=s;ComAct=c;	
}

void Dis7Seg::SetBusPort(Bus * b){// Asignaci�n de puerto
 n=0;
 B=b;
 n=B->GetBits()-8;
 Text = new char [n+2];	
 for(int x=0;x<n+1;x++)Text[x]=CodeDis[22];
}

void Dis7Seg::SetSeg(unsigned char d){// Escritura de segmentos
 Dat&=0xFF00;
 if( ((bool)(d&1))^(!SegAct) )Dat+=1;
 if( ((bool)(d&2))^(!SegAct) )Dat+=2;
 if( ((bool)(d&4))^(!SegAct) )Dat+=4;
 if( ((bool)(d&8))^(!SegAct) )Dat+=8;
 if( ((bool)(d&16))^(!SegAct) )Dat+=16;
 if( ((bool)(d&32))^(!SegAct) )Dat+=32;
 if( ((bool)(d&64))^(!SegAct) )Dat+=64;
 if( ((bool)(d&128))^(!SegAct) )Dat+=128;
 B->SetBus(Dat);
}

void Dis7Seg::SetCom(unsigned char c){// Escritura de comunes 
 if(ComAct){
  Dat &= 0x000000FF;
  if(c!=255)Dat |= (1<<(8+c));	
 }
 else {
  Dat |= 0xFFFFFF00;
  if(c!=255)Dat &= ~(1<<(8+c));
 }
 B->SetBus(Dat);	
}

void Dis7Seg::VerDinamico(void){// Vista din�mica 
 SetCom(255);
 SetSeg(Text[pos]);
 SetCom(pos);
 pos++;
 if(pos==n)pos=0;
}

void Dis7Seg::VerText(char *t){// Escritura de texto
 unsigned char j=0,k=0;
 for(int x=0;x<n;x++)Text[x]=CodeDis[22];
 Text[n]=0;
 while(1){
  if(k==n)return;
  switch(t[j]){
   case 'O':
   case '0':Text[k++]=CodeDis[0];j++;break;
   case '1':Text[k++]=CodeDis[1];j++;break;
   case '2':Text[k++]=CodeDis[2];j++;break;
   case '3':Text[k++]=CodeDis[3];j++;break;	
   case '4':Text[k++]=CodeDis[4];j++;break;
   case 's':
   case 'S':	
   case '5':Text[k++]=CodeDis[5];j++;break;
   case '6':Text[k++]=CodeDis[6];j++;break;
   case '7':Text[k++]=CodeDis[7];j++;break;
   case '8':Text[k++]=CodeDis[8];j++;break;
   case 'g':
   case 'G':
   case '9':Text[k++]=CodeDis[9];j++;break;
   case 'a':
   case 'A':Text[k++]=CodeDis[10];j++;break;
   case 'b':Text[k++]=CodeDis[11];j++;break;
   case 'B':Text[k++]=CodeDis[8];j++;break;
   case '[':
   case 'C':Text[k++]=CodeDis[12];j++;break;
   case 'd':
   case 'D':Text[k++]=CodeDis[13];j++;break;
   case 'e':
   case 'E':Text[k++]=CodeDis[14];j++;break;
   case 'F':
   case 'f':Text[k++]=CodeDis[15];j++;break;
   case 'c':Text[k++]=CodeDis[16];j++;break;
   case 'o':Text[k++]=CodeDis[17];j++;break;
   case '�':Text[k++]=CodeDis[18];j++;break;
   case '-':Text[k++]=CodeDis[19];j++;break;
   case '=':Text[k++]=CodeDis[20];j++;break;
   case '"':Text[k++]=CodeDis[21];j++;break;
   case 'n':
   case 'N':Text[k++]=CodeDis[23];j++;break;
   case '�':
   case '�':Text[k++]=CodeDis[24];j++;break;
   case 'j':Text[k++]=CodeDis[25];j++;break;
   case 'J':Text[k++]=CodeDis[26];j++;break;
   case 'u':Text[k++]=CodeDis[27];j++;break;
   case 'U':Text[k++]=CodeDis[28];j++;break;
   case 'H':Text[k++]=CodeDis[29];j++;break;
   case 'h':Text[k++]=CodeDis[30];j++;break;
	 case 'y':
   case 'Y':Text[k++]=CodeDis[31];j++;break;
   case 'L':Text[k++]=CodeDis[32];j++;break;
   case 'i':Text[k++]=CodeDis[33];j++;break;
   case 'l':
   case 'I':Text[k++]=CodeDis[34];j++;break;
   case 'p': 
   case 'P':Text[k++]=CodeDis[35];j++;break;
   case 'q': 
   case 'Q':Text[k++]=CodeDis[36];j++;break;
   case 'r': 
   case 'R':Text[k++]=CodeDis[37];j++;break;
   case 't': 
   case 'T':Text[k++]=CodeDis[38];j++;break;
   case ']':Text[k++]=CodeDis[39];j++;break;
   case ',':
   case '.':Text[k-1]|=128;j++; break;
   case  0: return;
   default: Text[k++]=CodeDis[22];j++;break;
  }
 }
}

int Dis7Seg::operator = (int v){// Escritura de numero entero 
  char T[20];
  sprintf(T,"%d",v);
  VerText(T);
  return v;
}

double Dis7Seg::operator = (double v){// Escritura de numero decimal
 char T[20];
 sprintf(T,"%f",v);
 VerText(T);
 return v;
}

char *Dis7Seg::operator = (char *t){// Escritura de texto
 VerText(t);	
 return t;
}








