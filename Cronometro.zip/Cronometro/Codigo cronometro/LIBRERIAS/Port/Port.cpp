// C�digo Ejemplo 9 7 // 
// Archivo *.cpp //
#include "Port.h"
Port::Port(){Dat=0;Mask=0xFFFF;}// Constructor
// M�todo para iniciar puerto
void Port::Iniciar(int io0,int io1,int io2,int io3,int io4,int io5,int io6,int io7,
           int io8,int io9,int io10,int io11,int io12,int io13,int io14,int io15){
 unsigned char n=1;
 if(io1!= -1)n++; 		
 if(io2!= -1)n++;
 if(io3!= -1)n++;
 if(io4!= -1)n++;
 if(io5!= -1)n++;
 if(io6!= -1)n++;
 if(io7!= -1)n++;
 if(io8!= -1)n++;
 if(io9!= -1)n++;
 if(io10!= -1)n++;
 if(io11!= -1)n++;
 if(io12!= -1)n++;
 if(io13!= -1)n++;
 if(io14!= -1)n++;
 if(io15!= -1)n++;
 SetBits(n);
 P = new Pin [n];
 P[0].Gpio(io0);
 if(io1!= -1)P[1].Gpio(io1);	
 if(io2!= -1)P[2].Gpio(io2);
 if(io3!= -1)P[3].Gpio(io3);
 if(io4!= -1)P[4].Gpio(io4);
 if(io5!= -1)P[5].Gpio(io5);
 if(io6!= -1)P[6].Gpio(io6);
 if(io7!= -1)P[7].Gpio(io7);
 if(io8!= -1)P[8].Gpio(io8);
 if(io9!= -1)P[9].Gpio(io9);
 if(io10!= -1)P[10].Gpio(io10);
 if(io11!= -1)P[11].Gpio(io11);
 if(io12!= -1)P[12].Gpio(io12);
 if(io13!= -1)P[13].Gpio(io13);
 if(io14!= -1)P[14].Gpio(io14);
 if(io15!= -1)P[15].Gpio(io15);
 for(n=0;n<Bits;n++)B[n]= &P[n]; 
 Dat=0;
}
							
// M�todo para iniciar como salida
void Port::DigitalOut(int io0,int io1,int io2,int io3,int io4,int io5,int io6,int io7,
              int io8,int io9,int io10,int io11,int io12,int io13,int io14,int io15){
 Iniciar(io0,io1,io2,io3,io4,io5,io6,io7,io8,io9,io10,io11,io12,io13,io14,io15);
 DigitalOut();								
}
							
// M�todo para iniciar como entrada
void Port::DigitalIn(int io0,int io1,int io2,int io3,int io4,int io5,int io6,int io7,
             int io8,int io9,int io10,int io11,int io12,int io13,int io14,int io15){
 Iniciar(io0,io1,io2,io3,io4,io5,io6,io7,io8,io9,io10,io11,io12,io13,io14,io15);
 DigitalIn();								
}
							
// M�todo para iniciar como salida 
void Port::DigitalOut(void){
 for(unsigned char n=0;n<Bits;n++)
  P[n].DigitalOut();
 Dat=0; 	
 Mask=0;	
}

// M�todo para iniciar como entrada
void Port::DigitalIn(void){
 for(unsigned char n=0;n<Bits;n++)
  P[n].DigitalIn(); 
 Mask=0xFFFF;	
}

// M�todo para iniciar como PullUp
void Port::PullUp(void){
 for(unsigned char n=0;n<Bits;n++)
  if(Mask&(1<<n))P[n].PullUp(); 
}

// M�todo para iniciar como mascara entrada salida
void Port::DigitalInOut(unsigned short mask){
  for(unsigned char n=0;n<Bits;n++)
   if((mask>>n)&1)P[n].DigitalIn();
   else P[n].DigitalOut();
  Dat=0;	
  Mask=mask;
}

// M�todo para escribir el bus
void Port::SetBus(unsigned short p)
{
 for(unsigned char n=0;n<Bits;n++)
  if( (Dat&(1<<n)) != (p&(1<<n)) )
 P[n].SetBit((bool)(p&(1<<n)));
 Dat=p; 
}

// M�todo para leer el bus
unsigned short Port::GetBus(void)
{
 Dat=0;
 for(unsigned char n=0;n<Bits;n++)
  if(P[n].GetBit())Dat|=(unsigned short)(1<<n);
 return Dat;
}

// Operador para escribir el bus
unsigned short Port::operator = (unsigned short e){SetBus(e);return e;}
unsigned char Port::operator = (unsigned char e){SetBus((unsigned short)e);return e;}

// Operador para leer el bus
Port::operator unsigned short(){return GetBus();}
Port::operator unsigned char(){return (unsigned char)(GetBus()&255);}

// Operador para acceder a bits
Pin Port::operator [] (int b) const {return P[b];}


