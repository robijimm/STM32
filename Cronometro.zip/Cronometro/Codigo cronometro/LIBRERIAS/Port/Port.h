// C�digo Ejemplo 9 6 // 
// Archivo *.h //
#ifndef _PORT_H
#define _PORT_H
#include "Bus.h"
#include "Pin.h"
class Port : public Bus{// Clase heredada Port
private: 
 unsigned short Dat;
 unsigned short Mask;
public:
 Pin *P;// Arreglo de pines
 Port();// Constructor
 // M�todo para iniciar los pines 
 void Iniciar(int io0,int io1= -1,int io2= -1,int io3= -1,int io4= -1,int io5= -1,
              int io6= -1,int io7= -1,int io8= -1,int io9= -1,int io10= -1,int io11= -1,
              int io12= -1,int io13= -1,int io14= -1,int io15= -1);
 // M�todo para iniciar los pines de salida 
 void DigitalOut(int io0,int io1= -1,int io2= -1,int io3= -1,int io4= -1,int io5= -1,
                 int io6= -1,int io7= -1,int io8= -1,int io9= -1,int io10= -1,
                 int io11= -1,int io12= -1,int io13= -1,int io14= -1,int io15= -1);
 // M�todo para iniciar los pines de entrada
 void DigitalIn(int io0,int io1= -1,int io2= -1,int io3= -1,int io4= -1,int io5= -1,
                int io6= -1,int io7= -1,int io8= -1,int io9= -1,int io10= -1,
                int io11= -1,int io12= -1,int io13= -1,int io14= -1,int io15= -1);
 void DigitalOut(void);// M�todo para iniciar los pines de salida
 void DigitalIn(void);// M�todo para iniciar los pines de entrada
 void PullUp(void);// M�todo para iniciar los pines PullUp
 void DigitalInOut(unsigned short mask);// M�todo para definir masca entrada y salida
 void SetBus(unsigned short p);// M�todo para escribir el bus
 unsigned short GetBus(void);// M�todo para leer el bus
 unsigned short operator = (unsigned short e);// Operador para escribir el bus
 unsigned char operator = (unsigned char e);			
 operator unsigned short();// Operador para leer el bus
 operator unsigned char();
 Pin operator [] (int b) const;// Operador para acceder a un bit							
};
#endif



