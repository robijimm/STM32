// C�digo Ejemplo 11 3 // 
// Archivo *.cpp //
#include "Adc.h"
Adc::Adc(){RI=false;}// Constructor
void Adc::SetAdc(unsigned char adc){// Inicio ADC
 switch(adc){
  case 1:a=ADC1;
         RCC->APB2ENR|=RCC_APB2ENR_ADC1EN;
         a->CR1=0;a->CR2=0; 
         a->CR2=ADC_CR2_ADON;
         break;
#if defined(ADC2)
  case 2:a=ADC2;
         RCC->APB2ENR|=RCC_APB2ENR_ADC2EN;
         a->CR1=0;a->CR2=0;
         a->CR2=ADC_CR2_ADON;
         break;
#endif	 
#if defined(ADC3)
  case 3:a=ADC3;
         RCC->APB2ENR|=RCC_APB2ENR_ADC3EN;
         a->CR1=0;a->CR2=0; 
         a->CR2=ADC_CR2_ADON; 
         break;
#endif	 
  default:return; 
 }
 
 ADC->CCR=0;
 if((double)PCLK2()/2.0 > 32000000){
  if((double)PCLK2()/4.0 > 32000000){
   if((double)PCLK2()/6.0 > 32000000)ADC->CCR|=3;
   else ADC->CCR|=2; 
  }else ADC->CCR|=1; 
 }
 
 switch(ADC->CCR&3)
 {
  case 0:ADCCLK=(double)PCLK2()/2.0;break;
  case 1:ADCCLK=(double)PCLK2()/4.0;break;
  case 2:ADCCLK=(double)PCLK2()/6.0;break;
  case 3:ADCCLK=(double)PCLK2()/8.0;break;
 }
 unsigned int Smp=0;
 double Ts,T;
 Ts=1.0/ADCCLK;
 if(Ts*3.0 > 0.00000021)Smp=0;
 else{if(Ts*15.0 > 0.00000021)Smp=1;
  else{if(Ts*28.0 > 0.00000021)Smp=2;
   else{ if(Ts*56.0 > 0.00000021)Smp=3;
    else{if(Ts*84.0 > 0.00000021)Smp=4;
     else{if(Ts*112.0 > 0.00000021)Smp=5;
      else{if(Ts*144.0 > 0.00000021)Smp=6;
       else Smp=7;
       }
      }
     }
    }
   }
  }
 
 a->SMPR1=0;
 a->SMPR2=0;
 for(int n=0;n<=24;n+=3)a->SMPR1|=(Smp<<n);
 for(int n=0;n<=27;n+=3)a->SMPR2|=(Smp<<n);
}

 // Inicio modo Regular
 void Adc::RegularGroup(int r1,int r2,int r3,int r4,
                        int r5,int r6,int r7,int r8,int r9,
                        int r10,int r11,int r12,int r13,
                        int r14,int r15,int r16){
 unsigned char n=0;
 a->SQR1=0;
 a->SQR2=0;
 a->SQR3=0;
 a->SQR3|=((((unsigned char)r1)&0x1F)<<0);
 if(r2!= -1){n++;a->SQR3|=((((unsigned char)r2)&0x1F)<<5);}
 if(r3!= -1){n++;a->SQR3|=((((unsigned char)r3)&0x1F)<<10);}
 if(r4!= -1){n++;a->SQR3|=((((unsigned char)r4)&0x1F)<<15);}
 if(r5!= -1){n++;a->SQR3|=((((unsigned char)r5)&0x1F)<<20);}
 if(r6!= -1){n++;a->SQR3|=((((unsigned char)r6)&0x1F)<<25);}
 if(r7!= -1){n++;a->SQR2|=((((unsigned char)r7)&0x1F)<<0);}
 if(r8!= -1){n++;a->SQR2|=((((unsigned char)r8)&0x1F)<<5);}
 if(r9!= -1){n++;a->SQR2|=((((unsigned char)r9)&0x1F)<<10);}
 if(r10!= -1){n++;a->SQR2|=((((unsigned char)r10)&0x1F)<<15);}
 if(r11!= -1){n++;a->SQR2|=((((unsigned char)r11)&0x1F)<<20);}
 if(r12!= -1){n++;a->SQR2|=((((unsigned char)r12)&0x1F)<<25);}
 if(r13!= -1){n++;a->SQR1|=((((unsigned char)r13)&0x1F)<<0);}
 if(r14!= -1){n++;a->SQR1|=((((unsigned char)r14)&0x1F)<<5);}
 if(r15!= -1){n++;a->SQR1|=((((unsigned char)r15)&0x1F)<<10);}
 if(r16!= -1){n++;a->SQR1|=((((unsigned char)r16)&0x1F)<<15);}
 a->SQR1|=((n&0x0F)<<20);
 a->CR2 |= ADC_CR2_CONT;
 if(n)a->CR1 |= ADC_CR1_SCAN;
 a->CR2 |= ADC_CR2_SWSTART;
}

 // Inicio modo Inyectado
void Adc::InjectedGroup(int r1,int r2,int r3,int r4){
 unsigned char n=0;
 a->JSQR=0;
 a->JSQR|=((((unsigned char)r1)&0x1F)<<0);
 if(r2!= -1){n++;a->JSQR|=((((unsigned char)r2)&0x1F)<<5);}	
 if(r3!= -1){n++;a->JSQR|=((((unsigned char)r3)&0x1F)<<10);}
 if(r4!= -1){n++;a->JSQR|=((((unsigned char)r4)&0x1F)<<15);}
 a->JSQR|=((n&3)<<20);
 a->CR2 &= ~ADC_CR2_CONT;
 if(n)a->CR1 |= ADC_CR1_SCAN;
 a->CR2 |= ADC_CR2_JSWSTART;
}

 // Inicio de pines an�logos
 void Adc::AnalogoPin(int r0,int r1,int r2,int r3,int r4,
                      int r5,int r6,int r7,int r8,int r9,
                      int r10,int r11,int r12,int r13,
                      int r14,int r15){
A.Analogo(r0);
if(r1!= -1)A.Analogo(r1);
if(r2!= -1)A.Analogo(r2);
if(r3!= -1)A.Analogo(r3);
if(r4!= -1)A.Analogo(r4);
if(r5!= -1)A.Analogo(r5);
if(r6!= -1)A.Analogo(r6);
if(r7!= -1)A.Analogo(r7);
if(r8!= -1)A.Analogo(r8);
if(r9!= -1)A.Analogo(r9);
if(r10!= -1)A.Analogo(r10);
if(r11!= -1)A.Analogo(r11);
if(r12!= -1)A.Analogo(r12);
if(r13!= -1)A.Analogo(r13);
if(r14!= -1)A.Analogo(r14);
if(r15!= -1)A.Analogo(r15);
}

// Lectura de un canal regular
unsigned short Adc::GetRegularData(void){
 a->SR &= ~ADC_SR_EOC;
 a->CR2 |= ADC_CR2_SWSTART;
 while( !(a->SR & ADC_SR_EOC) );
 return a->DR;
}

// Lectura de un canal regular
void Adc::GetRegularData(unsigned short &c){c=GetRegularData();}

 // Lectura de 4 canales inyectados
void Adc::GetInjectedData(unsigned short &c1,unsigned short &c2,
                          unsigned short &c3,unsigned short &c4){
 a->SR &= ~ADC_SR_JEOC;
 a->CR2 |= ADC_CR2_JSWSTART;
 while( !(a->SR & ADC_SR_JEOC) );
 c1=a->JDR1;
 c2=a->JDR2;
 c3=a->JDR3;
 c4=a->JDR4;	
}

 // Lectura de 3 canales inyectados
void Adc::GetInjectedData(unsigned short &c1,unsigned short &c2,unsigned short &c3){
 a->SR &= ~ADC_SR_JEOC;
 a->CR2 |= ADC_CR2_JSWSTART;
 while( !(a->SR & ADC_SR_JEOC) );
 c1=a->JDR1;
 c2=a->JDR2;
 c3=a->JDR3;
}

 // Lectura de 2 canales inyectados
void Adc::GetInjectedData(unsigned short &c1,unsigned short &c2){
 a->SR &= ~ADC_SR_JEOC;
 a->CR2 |= ADC_CR2_JSWSTART;
 while( !(a->SR & ADC_SR_JEOC) );
 c1=a->JDR1;
 c2=a->JDR2;
}

 // Lectura de un canal inyectado
void Adc::GetInjectedData(unsigned short &c1){
 a->SR &= ~ADC_SR_JEOC;
 a->CR2 |= ADC_CR2_JSWSTART;
 while( !(a->SR & ADC_SR_JEOC) );
 c1=a->JDR1;
}

// Lectura de un canal inyectado
unsigned short Adc::GetInjectedData(void){
 a->SR &= ~ADC_SR_JEOC;
 a->CR2 |= ADC_CR2_JSWSTART;
 while( !(a->SR & ADC_SR_JEOC) );
 return a->JDR1;
}

// Lectura del apuntador dato regular
unsigned int Adc::GetRegularApuntador(void){return (unsigned int)(&a->DR);}

// Lectura del apuntador dato inyectado
unsigned int Adc::GetInjectedApuntador(int n){
 switch(n){
  case 1:return (unsigned int)(&a->JDR1);
  case 2:return (unsigned int)(&a->JDR2);
  case 3:return (unsigned int)(&a->JDR3);
  case 4:return (unsigned int)(&a->JDR4);
 }
 return 0;
}

void Adc::Dma(bool e){// activaci�n de modo DMA 
 if(e)a->CR2|=(ADC_CR2_DDS|ADC_CR2_DMA);
 else a->CR2&= ~(ADC_CR2_DDS|ADC_CR2_DMA);
}
