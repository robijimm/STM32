// C�digo Ejemplo 11 2 // 
// Archivo *.h //
#ifndef _ADC_H
#define _ADC_H
#include "Pin.h"
class Adc{// Clase ADC
private:
 ADC_TypeDef * a;
 Pin A;
 unsigned char Canal;
 double ADCCLK;
 bool RI;
public:
 Adc();// Constructor
 void SetAdc(unsigned char a);// Inicio ADC
 // Inicio modo Regular
 void RegularGroup(int r1,int r2= -1,int r3= -1,int r4= -1,
                   int r5= -1,int r6= -1,int r7= -1,int r8= -1,int r9= -1,
                   int r10= -1,int r11= -1,int r12= -1,int r13= -1,
                   int r14= -1,int r15= -1,int r16= -1);
 // Inicio modo Inyectado
 void InjectedGroup(int r1,int r2= -1,int r3= -1,int r4= -1);
 // Inicio de pines an�logos
 void AnalogoPin(int r0,int r1= -1,int r2= -1,int r3= -1,int r4= -1,
                 int r5= -1,int r6= -1,int r7= -1,int r8= -1,int r9= -1,
                 int r10= -1,int r11= -1,int r12= -1,int r13= -1,
                 int r14= -1,int r15= -1);
 unsigned short GetRegularData(void);// Lectura de un canal regular
 void GetRegularData(unsigned short &c);// Lectura de un canal regular
 // Lectura de 4 canales inyectados
 void GetInjectedData(unsigned short &c1,unsigned short &c2,
                      unsigned short &c3,unsigned short &c4);
 // Lectura de 3 canales inyectados
 void GetInjectedData(unsigned short &c1,unsigned short &c2,unsigned short &c3);
 // Lectura de 2 canales inyectados
 void GetInjectedData(unsigned short &c1,unsigned short &c2);
 // Lectura de un canal inyectado
 void GetInjectedData(unsigned short &c1);
 // Lectura de un canal inyectado
 unsigned short GetInjectedData(void); 
 void Dma(bool e);// activaci�n de modo DMA 
 unsigned int GetRegularApuntador(void);// Lectura del apuntador dato regular
 unsigned int GetInjectedApuntador(int n);// Lectura del apuntador dato inyectado
};
#endif





