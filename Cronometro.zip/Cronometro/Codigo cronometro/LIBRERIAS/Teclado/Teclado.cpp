#include "Teclado.h"
Teclado::Teclado(){} // Constructor

void Teclado::SetBusPort(Bus *f,Bus *c){
 F=f;
 C=c;
 C->SetBus(0xFFFF);
 F->SetBus(0xFFFF);
 IniciarDelay();
}
 
char Teclado::Salir(char tx){// Salida del escaneo del teclado
 C->SetBus(0xFFFF);
 F->SetBus(0xFFFF);	
 Delay_ms(5);// Retardo anti rebote
 return tx;
}
 
unsigned char Teclado::GetTecla(void){// M�todo para leer teclado
 for(int c=0;c<C->GetBits();c++){
  C->SetBus(0xFFFF-(1<<c));
  Delay_ms(5);//Retardo anti rebote
  for(int f=0;f<F->GetBits();f++)
   if(!F->GetBit(f))return Salir(f+c*F->GetBits()+1);
 }
 return Salir(0);
}

Teclado::operator unsigned char(){return GetTecla();}