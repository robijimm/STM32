
#ifndef _TECLADO_H
#define _TECLADO_H
#include "Pin.h"
#include "Delay.h"
#include "Bus.h"
class Teclado{// Clase Teclado
private:
 Bus *F,*C;
 char Salir(char tx);// Salida del escaneo del teclado
public:
 Teclado();// Constructor
 void SetBusPort(Bus *f,Bus *c);// M�todo para configurar puertos         
 unsigned char GetTecla(void);// M�todo para leer teclado decodificado
 operator unsigned char();// Operador para leer teclado decodificado
};
#endif







