// C�digo Ejemplo 16 2 // 
// Archivo *.h //
#ifndef _TIMER_H
#define _TIMER_H
#include "Pin.h"
#include <math.h>
class Timer{// Clase Timer
protected:
 TIM_TypeDef *t; // Estructura Timer
 unsigned char tim; // Numero de Timer
 unsigned long APB1(void); // C�lculo de fuente APB1
 unsigned long APB2(void); // C�lculo de fuente APB2
 unsigned long APB; // Valor de APB
public:
 void SetTimer(unsigned char tmr); // Asigna Timer
 void Dma(bool e);// Activador DMA
 void SetPeriodo(double Tt); // Asigna periodo
 void SetPeriodo(double Tt,unsigned int arr);
 void SetFrecuencia(double Ft); // Asigna frecuencia
 void SetFrecuencia(double Ft,unsigned int arr);
 double GetPeriodo(void); // Lee periodo
 double GetFrecuencia(void); // Lee frecuencia
 void Interrpcion(FunInt fun); // Asigna interrupci�n
 double operator = (double Tt); // Asigna periodo
 void operator = (FunInt fun); // Asigna interrupci�n
};
#endif



