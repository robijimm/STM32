// C�digo Ejemplo 9 4 // 
// Archivo *.h //
#ifndef _BUS_H
#define _BUS_H
#include "Bit.h"
class Bus{// Clase Bus
protected: 
 unsigned char Bits; 
 unsigned short Dato;	
 Bit **B;// Apuntador a bits
public:
 Bus();// Constructor
 ~Bus();// Destructor
 void SetBits(unsigned char n);// M�todo para fijar tama�o del bus    
 unsigned char GetBits(void);// M�todo para leer tama�o del bus  
 virtual void SetBus(unsigned short p);// M�todo para dar valor al bus
 virtual unsigned short GetBus(void);// M�todo para leer valor del bus
 virtual void PullUp(void);// M�todo para activar PullUps
 virtual bool GetBit(unsigned char n);// M�todo para leer un bit
 virtual void SetBit(unsigned char n,bool e);// M�todo para escribir un bit
 virtual void DigitalOut(void);// M�todo para definir bus de salida
 virtual void DigitalIn(void);// M�todo para definir bus de entrada
 unsigned short operator = (unsigned short e);// Operador para definir valor en el bus
 operator unsigned short();// Operador para leer el valor del bus
};
#endif


