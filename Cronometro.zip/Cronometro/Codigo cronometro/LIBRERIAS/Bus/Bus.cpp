// C�digo Ejemplo 9 5 // 
// Archivo *.cpp //
#include "Bus.h"

Bus::Bus(){Bits=0;B=0;}// Constructor

Bus::~Bus(){if(!Bits)return;delete B;}// Destructor

// M�todo para leer tama�o del bus
unsigned char Bus::GetBits(void){return Bits;}

// M�todo para definir tama�o del bus
void Bus::SetBits(unsigned char b){
 Bits=b;	
 B = new Bit * [Bits];
 for(unsigned char n=0;n<Bits;n++)B[n]=0;	
}
							
// M�todo para definir valor del bus
void Bus::SetBus(unsigned short p){
 Dato=p;
 for(unsigned char n=0;n<Bits;n++)
 B[n]->SetBit((bool)(Dato&(1<<n)));
}

// M�todo para leer valor del bus
unsigned short Bus::GetBus(void){
 Dato=0;	
 for(unsigned char n=0;n<Bits;n++)
 if(B[n]->GetBit())Dato|=(1<<n);
 return Dato;
}

// M�todo para leer de un bit
bool Bus::GetBit(unsigned char n){
 return B[n]->GetBit();
}

// M�todo para escribir un bit
void Bus::SetBit(unsigned char n,bool e){
 B[n]->SetBit(e);
}

// Operador para escribir el bus
unsigned short Bus::operator = (unsigned short e){
 SetBus(e);
 return e;	
}

// Operador para leer el bus
Bus::operator unsigned short(){
 return GetBus();	
}

void Bus::PullUp(void){}// M�todo para definir PullUps
void Bus::DigitalOut(void){}// M�todo para definir bus de salida
void Bus::DigitalIn(void){}// M�todo para definir bus de entrada





































	