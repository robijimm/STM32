#include "stm32f401xe.h"
#include "Port.h"
#include "Lcd.h"
#include "Delay.h"
#include "Pin.h"
#include "Systick.h"
Port P;// Objeto puerto
Lcd D;// Objeto Lcd
Pin Pi;
Systick Sys;
char Text1[50]="";
char Text[50]="";
int dato=0,f=0,d=0;
bool e=1,r=1;
void inter1(void){
e=0;
}
void inter2(void){
r=0;
	


}
void inter3(void){
e=1;
}
void inter4(void){
dato=0;
f=0;
d=0;
e=1;

}
void FunSysTick(void){ //Rutinas del SysTick
		if(e==0)dato++;

}


		


	
int main(void){
IniciarDelay();// Inicio rutinas delay
 // Inicio de puertos para LCD 	
  P.DigitalOut(PB0,PB1,PB2,PB3,PB4,PB5);	
 D.SetBusPort(&P);// Asignaci�n de puerto LCD 
 D.Iniciar();// Inicio LCD
 D.CursorOnOff(0);// Apagado del cursor
 D.CursorBlink(0);	
   Pi.DigitalIn(PB7);
	 Pi.Interrupcion(&inter1,0,1);
   Pi.DigitalIn(PB8);
	 Pi.Interrupcion(&inter2,0,1);
	   Pi.DigitalIn(PB9);
	 Pi.Interrupcion(&inter3,0,1);
	   Pi.DigitalIn(PB10);
	 Pi.Interrupcion(&inter4,0,1);
 Sys.SetFun(&FunSysTick); //Asigna Funcion del SysTick
 Sys.Iniciar(0.001); //Inicia SysTick a 0.1 Segundos

 while(1){
	if(dato>1000){
		f++; 
	dato=0;} 
	if(f>59){
	d++; 
	f=0;}
	if(d>59)d=0 ;
  sprintf(Text,"Tiempo:%02d:%02d:%04d\n\r",d,f,dato);
D.Print(0,Text);
if(r==0)	
{sprintf(Text1,"T1:%2d:%2d:%2d",d,f,dato);

}

 }
return 0;
}


