#include <stm32f4xx.h>
#define retc for(int i=0; i<3; i++)
#define ret2 for(int i=0; i<400000; i++)
#define ret for(int i=0; i<10000; i++)

char N[11]={'0', '1', '2', '3', '4', '5', '6', '7', '8', '9'};
char M[11]={'T', 'E', 'M', 'P', 'E', 'R', 'A', 'T', 'U', 'R', 'A'};
int ta=0, t=0, t2[0], b=0;

void datos();
void mostrar();

int main(void){
	RCC -> AHB1ENR = 0xF;  
	RCC -> APB1ENR |= (1UL<<17);  
	USART2->BRR=0x683;
	USART2 -> CR1=0x012C;
	USART2 -> CR1 |= 0x2000;
	
	RCC -> APB2ENR |= 0x100;
	GPIOA -> MODER |= 0xAF;
	GPIOA->AFR[0]|=0x7700;
	ADC1 -> CR1 = 0x0;  // Configura el ADC1 en modo de una sola conversi�n
	ADC1 -> CR2 = 0x1;  // Habilita el ADC1
	
	for(int i=0; i<11; i++){
		USART2 -> DR=M[i];
		ret;
	}
	
	
	while(1){
		datos();
	}
}

void datos(){
	ADC1 -> SQR3 = 0x0;
	ADC1 -> CR2 |= (1UL<<30);  // Comienza la conversi�n del ADC1 en el primer canal
	retc;
	t=(ADC1->DR)*8056/100000;
	if(b==0){
		USART2 -> DR=0;ret2;
		b++;
	}
	if((t!=ta)&&(b!=0)){
		mostrar();
	}
	ta=t;		
}

void mostrar(){
	//USART2 -> DR=13;
	t2[0]=t/100;
	t2[1]=(t-t2[0]*100)/10;
	t2[2]=(t-t2[0]*100-t2[1]*10);
	
	if(t<10){
			USART2 -> DR=N[t2[2]];ret;
			USART2 -> DR=248;ret;
			USART2 -> DR=67;
		}
		
		else if(t>=100){
			USART2 -> DR=N[t2[0]];ret;
			USART2 -> DR=N[t2[1]];ret;
			USART2 -> DR=N[t2[2]];ret;
			USART2 -> DR=248;ret;
			USART2 -> DR=67;
		}
		
		else if(t<=99 && t>=10){
			USART2 -> DR=N[t2[1]];ret;
			USART2 -> DR=N[t2[2]];ret;
			USART2 -> DR=248;ret;
			USART2 -> DR=67;
		}		
	ret2;
}