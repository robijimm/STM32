void ReadGY271 (void);
void IniciarGY271(void);
extern int  xx,yy,zz;