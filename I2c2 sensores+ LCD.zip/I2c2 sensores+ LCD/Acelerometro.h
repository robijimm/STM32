extern double ang;
void ReadAcelerometro (void);
void IniciarAcelerometro(void);