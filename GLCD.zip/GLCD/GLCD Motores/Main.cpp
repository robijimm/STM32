/* Se controlan tres motores y se muestra informaci�n en grados de estos en una pantalla GLCD. */

#include "STM32F4xx.h"
#include "math.h"
 void borrado(int a);
 char setX= 0xB8;
 char disp_on= 0x3F;   //Variables globales pa que funcione
 char disp_off= 0x3e;
 char starL=0xC0;
 char setY=0x40;	
 int vec[3]; 
 int csx,i, j;
 int u,des1,des2,grado=0,grado2=0,grado3=0;
 double gradomat,volmat,pasomat=0;
 double gradomat2,volmat2,pasomat2=0;
 double gradomat3,volmat3,pasomat3=0;
 double m,xd;
 int paso=0;
 float v=2;
 char m1[8]={'M','O','T','O','R',' ','1','='};
 char m2[8]={'M','O','T','O','R',' ','2','='};	
 char m3[8]={'M','O','T','O','R',' ','3','='};
 
 
  char LA[8] = {0x00,0xfc,0x12,0x11,0x11,0x12,0xfc,0x00};
  char LB[8] = {0x00,0xff,0x89,0x89,0x89,0x89,0x76,0x00};
  char LC[8] = {0X00,0X3C,0X42,0X81,0X81,0X81,0X81,0X00};
  char LD[8] = {0x00,0xff,0X81,0X81,0X81,0X42,0X3C,0x00};
  char LE[8] = {0X00,0XFF,0X89,0X89,0X89,0X00,0X00,0X00};
  char LF[8] = {0X00,0XFF,0X09,0X09,0X09,0X09,0X01,0X00};
  char LG[8] = {0x00,0X7E,0X89,0X89,0X89,0X89,0X70,0x00};
  char LH[8] = {0X00,0XFF,0X08,0X08,0X08,0X08,0XFF,0X00};
  char LI[8] = {0X00,0X00,0X81,0X81,0XFF,0X81,0X81,0X00};
  char LJ[8] = {0x00,0X81,0X81,0X81,0X7F,0X01,0X01,0x00};
  char LK[8] = {0x00,0xff,0x18,0x14,0x22,0x41,0x80,0x00};
  char LL[8] = {0x00,0xff,0x80,0x80,0x80,0x80,0x00,0x00};
  char LM[8] = {0x00,0xff,0x01,0x02,0x04,0x02,0x01,0xff};
  char LN[8] = {0x00,0xff,0x03,0x0c,0x30,0xc0,0xff,0x00}; 
  char LO[8] = {0x00,0xff,0x81,0x81,0x81,0x81,0xff,0x00};
  char LP[8] = {0x00,0xff,0x11,0x11,0x11,0x11,0x0e,0x00};
  char LQ[8] = {0x00,0x7e,0x81,0x81,0xa1,0x7e,0x80,0x00};
  char LR[8] = {0x00,0xff,0x09,0x19,0x29,0x49,0x89,0x00};
  char LS[8] = {0x00,0xc0,0x92,0x92,0x92,0x92,0x60,0x00};
  char LT[8] = {0x01,0x01,0x01,0xff,0x01,0x01,0x01,0x00};
  char LU[8] = {0x00,0x7f,0x80,0x80,0x80,0x7f,0x80,0x00};
  char LV[8] = {0x03,0x0c,0x30,0xc0,0xc0,0x30,0x0c,0x03};
  char LW[8] = {0x07,0x38,0xc0,0x30,0xc0,0x38,0x07,0x00};
  char LX[8] = {0x81,0x42,0x24,0x18,0x18,0x24,0x42,0x81};
  char NO[8] = {0x00,0xff,0x81,0x81,0x81,0x81,0xff,0x00};
  char N1[8] = {0x00,0x00,0x84,0x82,0xff,0x80,0x80,0x00};
  char N2[8] = {0x00,0x00,0x62,0x91,0x89,0x86,0x00,0x00};
  char N3[8] = {0x00,0x00,0x42,0x91,0x99,0x66,0x00,0x00};
  char N4[8] = {0x00,0x0c,0x0a,0x09,0xff,0x08,0x00,0x00};
  char N5[8] = {0x00,0x06,0x89,0x89,0x89,0x89,0x70,0x00};
  char N6[8] = {0x00,0x00,0x30,0x4c,0x8a,0x91,0x60,0x00};
  char N7[8] = {0x00,0x00,0x01,0x11,0x11,0xff,0x00,0x00};
  char N8[8] = {0x00,0x20,0x56,0x89,0x89,0x56,0x20,0x00};
  char N9[8] = {0x00,0x00,0x06,0x89,0x49,0x36,0x00,0x00};
	
	
char NUM[10][4] ={0x1f,0x11,0x1f,0x00, //0
									0x12,0x1f,0x10,0x00, //1
									0x19,0x15,0x13,0x00,  //2
									0x11,0x15,0x1f,0x00, //3
									0x07,0x04,0x1f,0x00, //4
									0x13,0x15,0x19,0x00, //5     //Vectores para los numeros de la variable de 4 bits 
									0x1f,0x15,0x1c,0x00, //6
									0x01,0x05,0x1f,0x00, //7
                  0x1f,0x15,0x1f,0x00, //8
									0x07,0x05,0x1f,0x00}; //9
	
void send_comando(int cs, char a){
 GPIOD->ODR = a; 
 if(cs==1){GPIOD ->ODR |=(1UL<<8);}  
 else if(cs==2){GPIOD ->ODR |=(1UL<<9);} 
 GPIOD->ODR |=(1UL<<11);              
 for(int Cont=0;Cont<200;Cont++);
 GPIOD->ODR &=~(1UL<<11);  
 GPIOD->ODR =0;   
 }
                                           //funciones para enviar datos y ordenes a la lcd 
 void send_dato(int cs, char b){            //Enable conectado al pin 11 Cr1 pin 8 Cr2 pin 9 RS pin 10
 GPIOD->ODR |=(1UL<<10); 
 if(cs==1){GPIOD ->ODR |=(1UL<<8);}  
 else if(cs==2){GPIOD ->ODR |=(1UL<<9);}  
 GPIOD ->ODR |= b;
 GPIOD->ODR |=(1UL<<11);  
 for(int Cont=0;Cont<200;Cont++);
 GPIOD->ODR &=~(1UL<<11);  
 GPIOD->ODR =0; 
 } 
 
 void borrado(int a){
    for(i = 0; i < 8; ++i){
       send_comando(1,setY);
       send_comando(2,setY);
       send_comando(1, i | setX);
       send_comando(2, i | setX);
       for(j = 0; j < 64; ++j)
       {  send_dato(1, 0x00*a); 
          send_dato(2, 0x00*a);  
       }
    }
 }
 
	
extern "C"
{
	void send(int grados){
		for(int i=0;i<8;i++){
			 for(int n=0;n<90000;n++){__NOP();}
		   USART2->DR =m1[i];                             while ((USART2->SR & 0x80)==0); 
			 for(int n=0;n<90000;n++){__NOP();}
	 }
		
	  for(int n=0;n<100000;n++){__NOP();}
    USART2->DR =(grados/100)+0x30;	                  while ((USART2->SR & 0x80)==0);
		int u=grados/100;
		USART2->DR =((grados-(u*100))/10)+0x30;	          while ((USART2->SR & 0x80)==0);
		USART2->DR =(grados%10)+0x30;	                    while ((USART2->SR & 0x80)==0);
		USART2->DR = 0x0d;                             		while ((USART2->SR & 0x80)==0);
	  for(int n=0;n<100000;n++){__NOP();}
	}
	
	void send2(int grados){
	for(int i=0;i<8;i++){
			 for(int n=0;n<90000;n++){__NOP();}
		   USART2->DR =m2[i];                             while ((USART2->SR & 0x80)==0); 
			 for(int n=0;n<90000;n++){__NOP();}
	 }
	  for(int n=0;n<100000;n++){__NOP();}
    USART2->DR =(grados/100)+0x30;	                  while ((USART2->SR & 0x80)==0);
		int u=grados/100;
		USART2->DR =((grados-(u*100))/10)+0x30;	          while ((USART2->SR & 0x80)==0);
		USART2->DR =(grados%10)+0x30;	                    while ((USART2->SR & 0x80)==0);
		USART2->DR = 0x0d;                             		while ((USART2->SR & 0x80)==0);
	  for(int n=0;n<100000;n++){__NOP();}
	}
	
		
	void send3(int grados){
    for(int i=0;i<8;i++){
             for(int n=0;n<90000;n++){__NOP();}
           USART2->DR =m3[i];                             while ((USART2->SR & 0x80)==0); 
             for(int n=0;n<90000;n++){__NOP();}
     }
      for(int n=0;n<100000;n++){__NOP();}
    USART2->DR =(grados/100)+0x30;                      while ((USART2->SR & 0x80)==0);
        int u=grados/100;
        USART2->DR =((grados-(u*100))/10)+0x30;              while ((USART2->SR & 0x80)==0);
        USART2->DR =(grados%10)+0x30;                        while ((USART2->SR & 0x80)==0);
        USART2->DR = 0x0d;                                     while ((USART2->SR & 0x80)==0);
      for(int n=0;n<100000;n++){__NOP();}
    }
	
	}

int main(void){
	
 RCC->AHB1ENR |=0x1F;
 RCC -> APB2ENR = 0x100;
 RCC -> APB1ENR |=(1UL<<17);
 GPIOB->MODER|=0x55555555;
 GPIOD->MODER|=0x55555555;	
 GPIOE->MODER|=0x55555555;	
	
	
	// ADC 
  GPIOA->MODER|=0XF;
  ADC1->CR1=0X0;
	ADC1->CR2=0X1;
	
	// USART
	
 USART2->BRR=0X683;
 USART2->CR1=0x012C;
 USART2->CR1|=0x2000;
 GPIOA->MODER|=0XA0;
 GPIOA->AFR[0]=0x700;
 NVIC_EnableIRQ(USART2_IRQn);
	
	// GLCD
 send_comando(1,starL);
 send_comando(2,starL);
 send_comando(1,setY);
 send_comando(2,setY);
 send_comando(1,setX);
 send_comando(2,setX);
 send_comando(1,disp_on);
 send_comando(2,disp_on);
 borrado(1);
 
 while(true){
	 /*MOTOR 1*/
    ADC1 -> SQR3 = 0;              // CANAL 0
		ADC1->CR2|=(1UL<<30);          //DETECCION DEL VALOR DE POTENCIOMETRO
	  while((ADC1->SR & 0x20)==1); 
	volmat=((ADC1->DR*300)/2457);  //CALCULO DE VOLTAJE
	 gradomat=60*(volmat/100);      //CONVERSION VOLTAJE A GRADOS
	 grado=gradomat;
	  send(grado);
		pasomat=((80000*(volmat/100)));
		paso=pasomat;
	 
	  GPIOE->ODR=1;
	  for(int i=0;i<1228;i++){__NOP();}  //1MS = 0� , 2MS 180�
	  GPIOE->ODR=0;
		
		GPIOE->ODR=1;
     for(int i=0;i<(volmat)+105.6;i++){__NOP();} 
     GPIOE->ODR=0;
    for(int i=0;i<100000;i++){__NOP();}
		
		/*MOTOR 2*/
    ADC1 -> SQR3 = 1;              //CANAL 1
		ADC1->CR2|=(1UL<<30); 
    while((ADC1->SR & 0x20)==1); 
	  volmat2=((ADC1->DR*300)/2457);  //CALCULO DE VOLTAJE  
	  gradomat2=60*(volmat2/100);      //CONVERSION VOLTAJE A GRADOS
	  grado2=gradomat2;
	  send2(grado2);
		send3(grado2);
		
		
		GPIOE->ODR= 2;
		for(int i=0;i<(volmat2)+105;i++){__NOP();}  //1MS = 0� , 2MS 180�
    GPIOE->ODR=0;
    for(int i=0;i<100000;i++){__NOP();}
		
		GPIOE->ODR=4;
		for(int i=0;i<(volmat2)+105;i++){__NOP();}  //1MS = 0� , 2MS 180�
    GPIOE->ODR=0;
    for(int i=0;i<100000;i++){__NOP();}

	int barrita=grado*0.356;   //180->64      180x=64   x=0.356
		int barrita1=grado2*0.356;
    int barrita2=grado2*0.356;
		
      send_comando(2,setY);
      send_comando(2, setX);
       for(j = 0; j < 8; ++j)
       {  send_dato(2,LM[j] );}
       for(j = 0; j < 8; ++j)
       {  send_dato(2,LO[j] );}
 			for(j = 0; j < 8; ++j)
       {  send_dato(2,LT[j] );}       //Label para enviar las letras de 8 bits iniciando en la parte superior izquierda 
 			for(j = 0; j < 8; ++j)
       {  send_dato(2,LO[j] );}
 			for(j = 0; j < 8; ++j)
       {  send_dato(2,LR[j] );} 
			for(j = 0; j < 8; ++j)
       {  send_dato(2,N1[j] );}
     
			  send_comando(1,setY);
			  send_comando(1, setX);
			 for(j = 0; j < 8; ++j)
       {  send_dato(1,LM[j] );}
       for(j = 0; j < 8; ++j)
       {  send_dato(1,LO[j] );}
 			for(j = 0; j < 8; ++j)
       {  send_dato(1,LT[j] );}
 			for(j = 0; j < 8; ++j)
       {  send_dato(1,LO[j] );}
 			for(j = 0; j < 8; ++j)
       {  send_dato(1,LR[j] );} 
			for(j = 0; j < 8; ++j)
       {  send_dato(1,N2[j] );}
			 
			 send_comando(2,setY);
       send_comando(2, 4 | setX);
       for(j = 0; j < 8; ++j)
       {  send_dato(2,LM[j] );}
       for(j = 0; j < 8; ++j)
       {  send_dato(2,LO[j] );}
 			for(j = 0; j < 8; ++j)         //Label para lo mismo pero desplazado hacia abajo 
       {  send_dato(2,LT[j] );}
 			for(j = 0; j < 8; ++j)
       {  send_dato(2,LO[j] );}
 			for(j = 0; j < 8; ++j)
       {  send_dato(2,LR[j] );} 
			for(j = 0; j < 8; ++j)
       {  send_dato(2,N3[j] );}
			 
		 		 int c1= grado/100;
			 int d1=(grado-(c1*100))/10;
			 int u1= grado%10;
			 
			  send_comando(2,setY+10);
    send_comando(2, 2 | setX);
			 for(j = 0; j < 4; ++j)
       {  send_dato(2,NUM[c1][j]);}
			 for(j = 0; j < 4; ++j)
       {  send_dato(2,NUM[d1][j]);}   // para mostrar los numeros de que necesite de 4 bits
			 for(j = 0; j < 4; ++j)          // a la variable le saca unidades decenas y centenas
       {  send_dato(2,NUM[u1][j]);}
			 for(j = 0; j < 50000; ++j)
       {__NOP();}
			 
			 send_comando(2,setY);
  send_comando(2, 3 | setX);
	for(int j=0;j<barrita;j++){  //La barrita dependiente de una variable barrita que tiene que ser maximo 64
	 send_dato(2,0x78);
	for(int x=0;x<10000;x++){__NOP(	);}
	}
	
		int c2= grado2/100;
			 int d2=(grado2-(c2*100))/10;
			 int u2= grado2%10;
			 
			  send_comando(1,setY);
    send_comando(1, 2 | setX);
			 for(j = 0; j < 4; ++j)
       {  send_dato(1,NUM[c2][j]);}
			 for(j = 0; j < 4; ++j)
       {  send_dato(1,NUM[d2][j]);}
			 for(j = 0; j < 4; ++j)
       {  send_dato(1,NUM[u2][j]);}
			 for(j = 0; j < 50000; ++j)
       {__NOP();}
			 
			 send_comando(1,setY);
  send_comando(1, 3| setX);
	for(int j=0;j<barrita1;j++){
	 send_dato(1,0x78);
	for(int x=0;x<10000;x++){__NOP();}
	}
			 
	 
		int c3= grado2/100;
			 int d3=(grado2-(c1*100))/10;
			 int u3= grado2%10;
			 
			  send_comando(2,setY+10);
    send_comando(2, 5 | setX);
			 for(j = 0; j < 4; ++j)
       {  send_dato(2,NUM[c3][j]);}
			 for(j = 0; j < 4; ++j)
       {  send_dato(2,NUM[d3][j]);}
			 for(j = 0; j < 4; ++j)
       {  send_dato(2,NUM[u3][j]);}
			 for(j = 0; j < 50000; ++j)
       {__NOP();}
			 
			 send_comando(2,setY);
  send_comando(2, 6 | setX);
	for(int j=0;j<barrita2;j++){
	 send_dato(2,0x78);
	for(int x=0;x<10000;x++){__NOP();}
	}
	
	}
}