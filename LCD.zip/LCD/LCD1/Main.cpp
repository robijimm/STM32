#include<stm32f4xx.h>
#define ret for(int i=0; i<4000; i++)
#define ret2 for(int i=0; i<500000; i++)

char A2[4]={'2', '0', '2', '3'};
char A3[6]={'M', 'I', 'C', 'R', 'O', 'S'};

void enviar(char a){
	GPIOC->ODR=a|(1UL<<9);
	ret;
	GPIOC->ODR &=~(1UL<<9);
}

void enviarDato(char b){
	GPIOC->ODR=b|(3<<8);
	ret;
	GPIOC->ODR &=~(1UL<<9);
}
	
int main(void){
	RCC->AHB1ENR=0xF;
	GPIOC->MODER=0x55555555;
	
	enviar(0x06); //Entry mode set direcci�n a la derecha
	enviar(0x38); //Funtion set 8 bits 2 lineas
	enviar(0xC); //Display on
	
		
	enviar(0x85); //Corrimiento 5 en la primera linea
	for(int ch=0; ch<6; ch++){
		enviarDato(A3[ch]);
	}
	
	enviar(0xC6); //Corrimiento 6 en la segunda linea
	for(int ch=0; ch<4; ch++){
		enviarDato(A2[ch]);
	}
	

	while(true)
	{
		for(int x=0; x<16; x++){
			enviar(0x01); //Clear display
			ret;
			enviar(0x85+x);
			for(int ch=0; ch<6; ch++){
		  enviarDato(A3[ch]);
			}
			enviar(0xC6-x);
			for(int ch=0; ch<4; ch++){
		  enviarDato(A2[ch]);
			}
			ret2;
		}
	}
}
