/*Animaici�n matriz de leds, reloj de arena din�mico*/

/////////////////////////reloj dinamico//////////////////////////////

#include "STM32F4xx.h"
int rel[5]={0x63,0x55,0x49,0x55,0x63};
int l[5]={0x0,0x57,0x4F,0x57,0x0};
int l2[5]={0x0,0x70,0x6D,0x70,0x0};
int l3[5]={0x0,0x75,0x70,0x75,0x0};

int main(void){	int i=0;
	
	RCC->AHB1ENR |=0xF;    
	GPIOD->MODER 	 = 0x55555555;     
	GPIOC->MODER 	 = 0x55555555;  
	while(true){
	
		for(int a=0;a<2000;a++){ 
		for(int col=0;col<5;col++){ 
		GPIOD->ODR= (1UL<<col);
		GPIOC->ODR  = ~((rel[col])|(l[col]));
		for(int i=0;i<1000;i++);
			}}
		for(int a=0;a<2000;a++){ 
		for(int col=0;col<5;col++){ 
		GPIOD->ODR= (1UL<<col);
		GPIOC->ODR  = ~((rel[col])|(l2[col]));
		for(int i=0;i<1000;i++);
			}}
		for(int a=0;a<2000;a++){ 
		for(int col=0;col<5;col++){ 
		GPIOD->ODR= (1UL<<col);
		GPIOC->ODR  = ~((rel[col])|(l3[col]));
		for(int i=0;i<1000;i++);
			}}

}}