/* Muestra de la letra A a la letra E en una matriz de leds, alternado entre estas cinco */

///////////////////////////letras 2//////////////////////////////

#include "STM32F4xx.h"
int letras[5][5]={
{0x7e,0x11,0x11,0x11,0x7e},
{0xff,0x49,0x49,0x49,0x36},
{0x3e,0x41,0x41,0x41,0x0},
{0xff,0x41,0x41,0x22,0x1c},
{0xff,0x49,0x49,0x49,0x00}
};
int main(void){	
	int i=0;
	RCC->AHB1ENR |=0xF;    
	GPIOD->MODER = 0x55555555;     
	GPIOC->MODER = 0x55555555;  
	while(true){
		for(int fil=0;fil<5;fil++){ 
			for(int a=0;a<1000;a++){ 
				for(int col=0;col<5;col++){ 
					GPIOD->ODR= (1UL<<col);
					GPIOC->ODR  = ~(letras[fil][col]);
					for(int i=0;i<1000;i++);
				}
			}
		}
	}
}
