/* Muestra las letras A y B en una matriz de leds, alternando entre las dos */

/////////////////////////letra//////////////////////////////

#include "STM32F4xx.h"
int letraA[5]={0x7e,0x11,0x11,0x11,0x7e};
int letraB[5]={0xff,0x49,0x49,0x49,0x36};
int main(void){	int i=0;
	
	RCC->AHB1ENR |=0xF;    
	GPIOD->MODER 	 = 0x55555555;    
	GPIOC->MODER 	 = 0x55555555;  
	while(true){
		for(int a=0;a<1000;a++){ 
			for(int col=0;col<5;col++){ 
				GPIOD->ODR= (1UL<<col);
				GPIOC->ODR  = ~((letraA[col]));
				for(int i=0;i<1000;i++);
			}
		}
		for(int a=0;a<1000;a++){ 	
			for(int col=0;col<5;col++){ 
				GPIOD->ODR= (1UL<<col);
				GPIOC->ODR  = ~((letraB[col]));
				for(int i=0;i<1000;i++);
			}
		}
	}
}