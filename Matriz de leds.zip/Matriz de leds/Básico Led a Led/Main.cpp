/* Animaci�n matriz de leds, se encienden uno por uno de izquierda a derecha fila por fila */

/////////////////////////basico led a led//////////////////////////////

#include "STM32F4xx.h"
int main(void){	int i=0;
	RCC->AHB1ENR |=0xF;    
	GPIOD->MODER 	 = 0x55555555;     
	GPIOC->MODER 	 = 0x55555555;  
	while(true){
		for(int fil=0;fil<7;fil++){ 
		for(int col=0;col<5;col++){ 
		GPIOD->ODR=1UL<<col;
		GPIOC->ODR  = ~(1UL<<fil);
		for(int i=0;i<500000;i++);
			}
}
}}
