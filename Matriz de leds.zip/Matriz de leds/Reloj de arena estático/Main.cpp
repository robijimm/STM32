/* Reloj de arena est�tico en matriz de leds */

///////////////////////////reloj arena//////////////////////////////

#include "STM32F4xx.h"
int rel[5]={0x63,0x55,0x49,0x55,0x63};
int main(void){	int i=0;
	
	RCC->AHB1ENR |=0xF;    
	GPIOD->MODER 	 = 0x55555555;     
	GPIOC->MODER 	 = 0x55555555;  
	while(true){
		for(int col=0;col<5;col++){ 
		GPIOD->ODR= (1UL<<col);
		GPIOC->ODR  = ~(rel[col]);
		for(int i=0;i<10000;i++);
			}
}}