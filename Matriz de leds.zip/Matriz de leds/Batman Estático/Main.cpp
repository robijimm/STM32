/* Patr�n est�tico de Batman en tres matrices de leds */

///////////////////////////BATMAN0//////////////////////////////

#include "STM32F4xx.h"
int letras[15]={
0x02,0x06,0x0c,0x0e,0x1e,0x1c,0x3f,0x7e,0x3f,0x1c,
0x1e,0x0e,0x0c,0x06,0x02};
int main(void){	
	int i=0;
	RCC->AHB1ENR |=0xF;    
	GPIOD->MODER = 0x55555555;     
	GPIOC->MODER = 0x55555555;  
	while(true){
		for(int a=0;a<2000;a++){ 
			for(int col=0;col<15;col++){ 
				GPIOD->ODR= (1UL<<col);
				GPIOC->ODR  = ~(letras[col]);
				for(int i=0;i<1000;i++);
			}
		}
	}
}