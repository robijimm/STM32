#include "GLCD.h"
int i1,j1,csx;
float dato=0,v=2;
/////////////////////////////////////////////
void GLCD::send_comando(int cs, char a){
GPIOD->ODR =a;//RS=0
if(cs==1){GPIOD ->ODR |=(1UL<<8);} // Enable CS1
else if(cs==2){GPIOD ->ODR |=(1UL<<9);}//Enable CS2
GPIOD->ODR |=(1UL<<11); // Enable 1
for(int Cont=0;Cont<50;Cont++);
GPIOD->ODR &=~(1UL<<11); // Enable 0
GPIOD->ODR =0; // cs 0
}
/////////////////////////////////////////////
void GLCD::send_dato(int cs, char b){
GPIOD->ODR |=(1UL<<10);//RS=1
if(cs==1){GPIOD ->ODR |=(1UL<<8);} // Enable CS1
else if(cs==2){GPIOD ->ODR |=(1UL<<9);}//Enable CS2
GPIOD ->ODR |= b;
GPIOD->ODR |=(1UL<<11); // Enable 1
for(int Cont=0;Cont<100;Cont++);
GPIOD->ODR &=~(1UL<<11); // Enable 0
GPIOD->ODR =0; // cs 0
} 
/////////////////////////////////////////////
void GLCD::lineV(int py,int px1, int px2){	
	float dato=0;i1=px1%8;
	if(px2>px1 && py<128){
	if(py>63){csx=2;py=py-64;}else {csx=1;}
for(int px=(px1); px<px2;px++){
	send_comando(csx, (px/8)+0x3f);
	send_comando(csx,0x40+py);
	dato=dato + pow(v,(px%8));
	send_dato(csx, dato); 
	i1++;if(i1==8){i1=0;dato=0;}}}}
///////////////////////////////////////////
void GLCD::borrado(int a){
 for(i1 = 0; i1 < 8; ++i1){
  send_comando(1,0x40);send_comando(2,0x40);
  send_comando(1,i1|0xB8);send_comando(2,i1|0xB8);
      for(j1 = 0; j1 < 64; ++j1)
      {  send_dato(1, 0xFF*a); 
         send_dato(2, 0xFF*a);  
      }}}
/////////////////////////////////////////
void GLCD::lineH(int px,int py1, int py2){	
if(py2>py1 )	 {
 if(py2>63 && py1<63)	 {
 send_comando(1, (px/8)+0x3f);send_comando(1,0x40+py1);
 for(j1=0;j1<(64-py1);j1++){	send_dato(1, pow(v,(px%8))); }
 send_comando(2, (px/8)+0x3f);send_comando(2,0x40);
	for(j1=0;j1<(py2-64);j1++){send_dato(2, pow(v,(px%8)));}
		}
else {if(py1>63){
csx=2;py1=py1-64;py2=py2-64;}else {csx=1;}
      send_comando(csx, (px/8)+0x3f);
 	    send_comando(csx,0x40+py1);
 for(j1=0;j1<=(py2-py1);j1++){
			send_dato(csx, pow(v,(px%8))); 
		}}}}
///////////////////////////////
void GLCD::cfgGLCD(){RCC->AHB1ENR |= 0x3f;
GPIOD->MODER =0x05555555;
send_comando(1,0xC0);    send_comando(2,0xC0);
send_comando(1,0x40);    send_comando(2,0x40);
send_comando(1,0x3f);    send_comando(2,0x3f);
send_comando(1,0x3F); send_comando(2,0x3F);
borrado(0);}

/////////////////////////////////
void GLCD::pixel(int x, int y)
	{    if(y>63){csx=2;y=y-64;}else {csx=1;}
      send_comando(csx,0x40+y);
      send_comando(csx, (x/8)+0xB8);
	    send_dato(csx, pow(v,(x%8))); 
	}