#include "STM32F4xx.h"
#include "math.h"


class GLCD{
public:
void pixel(int,int);
void send_comando(int,char);
void send_dato(int,char);
void borrado(int);
void lineH(int,int,int);
void lineV(int,int,int);
void cfgGLCD();
};