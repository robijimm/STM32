/* Se configura el PLL (Phase-Locked Loop) para cambiar la frecuencia del reloj del sistema de 16MHz a 64MHz */

#include "STM32F4xx.h"
/**
  *         El ajuste del PLL de 16MHz a 64MHz (1:4) requiere: 
  *            System Clock source            = PLL (HSI)
  *            AHB Prescaler                  = 1
  *            APB1 Prescaler                 = 2
  *            APB2 Prescaler                 = 0
  *            HSI Frequency(Hz)              = 16000000
  *            PLL_M                          = 16
  *            PLL_N                          = 256
  *            PLL_P                          = 4
  *            VDD(V)                         = 3.3
  *            Flash Latency(WS)              = 2
  */

#define PLL_M 	16
#define PLL_N 	256
#define PLL_P 	1 

long time=3200000;      //n ciclos de maquina

void PLL(void) {
 int a=0;
 RCC->CR |= 0x00001;                   //Activar el oscilador HSI                    
 while((RCC->CR & 0x2)==0);          //Esperar que el HSI este estabilizado     
 RCC->APB1ENR = 0x10000000;            //Power interface clock enable      
 RCC->CFGR = 0x1000;                   //APB2 ()    y APB1 (/2)
 RCC->PLLCFGR =(PLL_M<<0) | (PLL_N<< 6) | (PLL_P<<16) | (RCC_PLLCFGR_PLLSRC_HSI);    
              	//HSE reloj de entrada al PLL; PLLM=8; PLLN=336; PLLP=2      
 RCC->CR |= 0x01000000;                //Activar el PLL      
 while((RCC->CR & 0x02000000)==0);     //Esperar que el PLL este listo
 FLASH->ACR = 0x202;                   //Activar el ART Accelerator a 2 wait states   
 RCC->CFGR |= 2;                       //Seleccionar el PLL como la fuente de reloj     
 for (a=0;a<=500;a++);
}


int main(void){
  PLL();
	RCC->AHB1ENR |= (1UL << 0);    //PRENDER EL CLOCK DEL PTA
	GPIOA->MODER |= (1UL << 2*5);    //PTA5 -> OUTPUT
	//**********************************************************************
	while(1){        
				GPIOA->ODR ^= 32;                //conmuta LED
				for(int i=0;i<time;i++);        //Delay
	}
}