/* Barrido de 180 gardos tipo radar utilizando un servomotor, 
midiendo la distancia por medio de un sensor ultrasonido en cada
posici�n del barrido.*/

	
/////////////RADAR con PWM servomotor por grado y US HCSR04

#include "stm32f4xx.h"
#define PWM3 0x60                 //MODO PWM CANAL 3
#define OC3  8                             //canal 3
int FPWM=50;                       // Frecuencia PWM
int angulo=0;                       //angulo inicial
int a,u=0,d=0,dista=0,dist=0;

void TIM3_IRQHandler(void)	{
	TIM3->SR &= 0;
	if(a>1){	GPIOB -> ODR ^= 1; }//INTERMITENCIA LED 1
	}

void SysTick_Handler(void){
	
				}
void mediDist (void){
 GPIOC -> ODR = 1;TIM2 -> CNT =0;
 while (TIM2 -> CNT	<180){}
 GPIOC -> ODR = 0;	
 while((GPIOC-> IDR & 0X2)== 0);
 TIM2 -> CNT =0;
 while((GPIOC-> IDR & 0X2)== 2);
 dist=	(TIM2 -> CNT)*2.31/2000;
 if(dist<15){a=2;}
 else {a=0;GPIOB->ODR =0;}
}

int main(void){
RCC->AHB1ENR=0x1;                        //PUERTO a 
RCC ->APB1ENR= 0X1;                        //TIMER 2
GPIOA -> MODER |= 0X20;               // PA2 ALTERNO 
GPIOA -> AFR[0]=0X000100;    //PA2 FUNCION ALTERNA 1
	
TIM2 -> PSC = 15; //Tiempo incremen 16MHZ/PSC+1 useg
TIM2 -> ARR = 1000000/FPWM;           //Periodo 20ms
TIM2 -> CR1 |= (1UL<<0);         //Habilita contador
TIM2 -> CCMR2 |= PWM3;                 //PWM canal 3
TIM2 -> CCER |= (1UL<<OC3);             //OC3 salida
	
TIM3 -> CR1 = 0X1; //CONTADOR HABILITADO, DIVISION X1
TIM3 -> PSC = 1600; //PRE-ESCALIZADOR DE TIEMPO 1useg
TIM3 -> ARR = 500; //frec 1Khz
TIM3 -> DIER = 0X1;
NVIC_EnableIRQ(TIM3_IRQn);

	
	RCC -> AHB1ENR = 0X7f; //PUERTO B
	RCC -> APB1ENR = 0X3; //TIMER 2-3
	GPIOB -> MODER |= 0X10004001; //LEDS TARJETA
	GPIOC -> MODER = 0x1;
	
SystemCoreClockUpdate();
SysTick_Config(SystemCoreClock/500);

while(1){
	for (int angulo=0; angulo<180; angulo++ ){
	TIM2 -> CCR3 = 1000 + 5.55*angulo ;//angulo-tiempo 
	mediDist();
	}
  }
}










