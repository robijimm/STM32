///////////NUMEROS BASICO INCREMENTO///////////////////////////////////7
#include <STM32F4xx.h>
void delay (int);
#define WORKING   GPIOC->ODR  ^= 1
//char BCD [10] = {63,6,91,79,102,109,125,7,127,111};
char BCD [7] = {0x37,0x77,0x39,0x6,0x3f,0x37,0};
void delay (int l){WORKING; 
for(int i=0;i<l;i++){
		for(int ix=0;ix<50000;ix++);	
}}
int main(void){	
	RCC->AHB1ENR =0xF; //CONFIGURACION "CLOCK"    
	GPIOD->MODER 	 = 0x55555555;     
  GPIOC->MODER 	 = 1;
	GPIOC->ODR=0;
while(1){        //bucle infinito

for(int a=0;a<7;a++){ //FOR 
		GPIOD->ODR=BCD[a];
	delay(100);
   } //FIN FOR 
 }
}	
