////////////// dato 2 lineas fijo////////////////

#include "STM32F4xx.h"
#include "LibrLCD.h"
LibrLCD lib;
char dato[6]={'M','i','c','r','o','s'};
char dato2[6]={'2','0','2','3','-','2'};
char clear=0x01;
char LCD1L=0x80;								
char LCD2L=0xC0;		


int main(void){
lib.cfglcd();
while(true){
lib.send_comando(LCD1L+6);
for (int i=0;i<6;i++){
	lib.send_dato(dato[i]); }
 lib.send_comando(LCD2L+6);
for (int i=0;i<6;i++){
	lib.send_dato(dato2[i]);}
for (int i=0;i<600000;i++);
}
}

//////////////////////////