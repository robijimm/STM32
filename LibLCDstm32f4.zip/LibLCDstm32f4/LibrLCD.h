#include "STM32F4xx.h"
class LibrLCD{
public:
void cfglcd();
void send_comando(char);
void send_dato(char);
};