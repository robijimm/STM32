#include "LibrLCD.h"
void LibrLCD::send_comando(char b){
	GPIOD ->ODR &=0XFF00;
	GPIOD ->ODR |= b;
	GPIOD->ODR &=~(1UL<<8);//RS=0
	GPIOD->ODR |=(1UL<<9); // Enable 1
	for(int dl=0;dl<5000;dl++);
	GPIOD->ODR &=~(1UL<<9); // Enable 0
}
void LibrLCD:: send_dato(char b){	
	GPIOD ->ODR &=0XFF00;
	GPIOD ->ODR |= b;	
	GPIOD->ODR |=(1UL<<8);//RS=1
	GPIOD->ODR |=(1UL<<9); // Enable 1
	for(int dl=0;dl<5000;dl++);
	GPIOD->ODR &=~(1UL<<9); // Enable 0
}
void LibrLCD:: cfglcd(){
	RCC->AHB1ENR |= 8; 
	GPIOD->MODER =0x55555;	
	//send_comando(clear);
	send_comando(0x38);
	send_comando(0x0E);
	send_comando(0x06);
}