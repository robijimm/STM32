//////////////////////////// SysTick interrupcion 5 segundos///////////////////////////////////
#include <stm32f4xx.h>
#define LEDR1 GPIOA->ODR^=32;

extern "C"
{
	void SysTick_Handler(void){
   LEDR1
	}}

int main (void){
  RCC->AHB1ENR=1;
	GPIOA->MODER |= 0X555;  
	SysTick->LOAD=10000000;  // 5 seg
	SysTick->VAL=0;
	SysTick->CTRL=3;  // AHB/8  2MHz activa interrupcion
while(1){
    } 
}
 
