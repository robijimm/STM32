////////////////////////// SysTick registros/////////////////////////////////////////////////////
/////////////////////////100 useg//////////////////////////////////////

/* Se genera una interrupci�n cada 100 useg */

#include <stm32f4xx.h>
#define LEDR1 GPIOA->ODR^=32;

	void delay_uS(int time){
		SysTick->LOAD=200-1;  //100useg 
		SysTick->VAL=0;
		SysTick->CTRL=1;  // AHB/8  2MHz
		for(long i=0;i<time;i++){
		while(!(SysTick->CTRL & 0x10000)){}}
}
int main (void){
  RCC->AHB1ENR=1;
	GPIOA->MODER |= 0X555;  
while(1){
	delay_uS(100000); LEDR1
 } 
}
