//////////////////////////// SysTick registros/////////////////////////////////////////////////////
/////////////////////////////1 usegundos//////////////////////////////////////

/* Se genera un retardo de 1useg utilizando el temporizador SysTick */

#include <stm32f4xx.h>
#define LEDR1 GPIOA->ODR^=32;

	void delay_uS(long time){
		SysTick->LOAD=16-1;     // valor de carga para (15) 1useg
		SysTick->VAL=0;
		for(long i=0;i<time;i++){            //retardo time*1useg
		while(!(SysTick->CTRL & 0x10000)){}       //retardo 1useg
		}
}
int main (void){
  RCC->AHB1ENR=1;
	GPIOA->MODER |= 0X555;  //pin de salida
	SysTick->CTRL=5;       // base de tiempo 16MHz
while(1){
	delay_uS(100000); LEDR1
 } 
}