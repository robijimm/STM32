////Apagar un led durante 2 segundos cuando se pone en 1 el bot�n de usuaio
#include <stm32f4xx.h>

int main(void){
	RCC->AHB1ENR=0x6;
	RCC->APB1ENR=0x1;
	GPIOC->MODER=0;
	GPIOB->MODER|=1;
	TIM2->CR1=0x1;
	TIM2->PSC=20000; //T_TCK=1.25ms
	TIM2->ARR=9000;  //T_salida_m�ximo=11.25s
	GPIOB->ODR=1;
	
	while(true){
		if((GPIOC->IDR & 0x2000)==0x2000){
			TIM2->EGR=1;
			while(TIM2->CNT<1600){GPIOB->ODR=0;} //Apaga el led durante 2 segundos (1.25ms*1600=2s)
			GPIOB->ODR=1;
		}
	}
}
