///////////// CONTEO INTERNO

/* Se configura el teporizadot TIMER2 en modo de conteo interno para generar un contador, 
   cuando se detecta una pulsaci�n en el pulsador conectado al pin GPIOB0, el temporizador se reinicia (CNT se establece en 0). 
	 Mientras tanto, un contador c mantiene el valor del conteo en milisegundos, y este valor se convierte en decenas y unidades, 
	 luego se muestra en un LCD. */

#include "STM32F4xx.h"

char clear = 0x01;
char set = 0x38;
char disp_on = 0x0E;
char mode = 0x06;
char ddram1L = 0x80;
char ddram2L = 0xC0;
char Tiempo[8] = {'C','o','n','t','e','o',' ','='};
char segs[5]={'U','n','i','.'};
int c=0,d=0,u = 0;
//***FUNCIONES LCD
void send_comando(char a){
	GPIOD -> ODR &= 0XFF00;//datos que se muestran
	GPIOD -> ODR |= a;
	GPIOD -> ODR &=~(1UL<<8);//RS=0 ** es comando
	GPIOD -> ODR |= (1UL<<9);//Enable 1  **** leer, se activa LCD
	for(int d1=0;d1<50000;d1++);//peque�o tiempo
	GPIOD -> ODR &=~(1UL<<9); //Enable 0
}
void send_dato(char b){
	GPIOD -> ODR &= 0XFF00;
	GPIOD -> ODR |= b;
	GPIOD -> ODR |= (1UL<<8);//RS=1 ** escribe datos
	GPIOD -> ODR |= (1UL<<9);//Enable 1 **** leer dato
	for(int d1=0;d1<5000;d1++);//Peque�o tiempo
	GPIOD -> ODR &=~(1UL<<9);//Enable
}
int main(void) {

	RCC->AHB1ENR =0xFF; //Puertos A,B,C,D,E,F,G,H
	RCC -> APB1ENR |= 0x1;
	//	//**********************************************************
	GPIOD -> MODER = 0X55555; // configuracion lcd
	send_comando(clear); //recibe info borrar
	for(int d1=0;d1<5000;d1++);
	send_comando(set);
	send_comando(disp_on);
	send_comando(mode);
//	//*******************
	GPIOA->MODER |= 0x002;
	GPIOA->AFR[0] |= 0x001;
	GPIOB->MODER = 0x4010;

	TIM2->ARR=60000;
	TIM2->PSC=16000;
	TIM2->CR1=1;
	//TIM2->SMCR=0x4056;
//	TIM2->CCMR1=0x4056;

	//	//********************************************************** 
		send_comando(ddram1L+2);
		for(int i=0;i<8;i++){
			send_dato(Tiempo[i]);}
		send_comando(ddram2L+7);
			send_dato(' ');
			send_dato('0');
			send_dato('0');
			send_dato(' ');
			for(int i=0;i<4;i++){
			send_dato(segs[i]);}
			
			
//********************************************************************************************
	while(true)	{GPIOB -> ODR = 0;
		if(GPIOB->IDR &= 0x1){        //evalua si se oprimio el pulsador 
		GPIOB->ODR |=(1UL<<2);       //prender led
		TIM2->CNT=0; }
					c =TIM2->CNT/1000;
					
					d=(c /10); // DECENAS
					u=(c %10); // UNIDADES
					send_comando(ddram2L+8);
					send_dato(0x30+d); // 0x30 numero en ascii
	      	send_dato(0x30+u); // 0x30 numero en ascii

		}			
	}