/* El temporizador cuenta hasta el valor del ARR y luego se reinicia. 
	 Se lee el estado de GPIOC->IDR para determinar si el bit 13 est� activado, en caso de estarlo, 
	 se lee el valor del contador TIM2->CNT y se cambia el estado del pin GPIOB dependiendo del valor le�do. 
	 Si el contador es menor que 10, se establece el pin GPIOB en 1, 
	 si el contador est� entre 500 y 700, se establece el pin GPIOB en 2
	 de lo contrario, se establece en 0. */

#include "STM32F4xx.h"

int main(void) {
	int temp=0;
	RCC->AHB1ENR =0x6; 
	RCC->APB1ENR|=0x1;
	GPIOB->MODER = 5;
	TIM2->ARR=0X500;
	TIM2->PSC=20000;
	TIM2->CR1=1;
	GPIOB->ODR=0;
	
	while(true)	{ 
		if(GPIOC->IDR & 0x2000==0x2000){   
    temp=TIM2->CNT;
    if(temp<10){GPIOB->ODR=1;}
    else if(temp>500  && temp<700)
    {GPIOB->ODR=2;}		
    else GPIOB->ODR=0;	
		}			
	}
}
