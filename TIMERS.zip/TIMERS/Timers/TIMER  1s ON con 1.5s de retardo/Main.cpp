//TIMER 1 SEG ON con 1.5s

/* El temporizador TIM2 est� configurado para generar interrupciones cada 1 segundo, 
	 mientras que el temporizador TIM3 est� configurado para generar interrupciones 
	 cada 1.5 segundos. 
	 
	 */

#include <stm32f4xx.h>

extern "C"{
	void TIM2_IRQHandler(void){
		TIM2->SR &= ~(1<<0);
		GPIOB->ODR^=1;
	}
	
	void TIM3_IRQHandler(void){
		TIM3->SR &= ~(1<<0);
		GPIOC->ODR^=1;
	}
}

int main(void){
	int temp=0;
	RCC->AHB1ENR=0x6;
	GPIOB->MODER=0x55555555; 
	GPIOC->MODER=0x55555555; 
	GPIOB->ODR=1;
	GPIOC->ODR=1;
	
	//TIM2
	RCC->APB1ENR=0x1; //TIMER 2
	TIM2->CR1=0x1;   //Contador habilitado
	TIM2->DIER=0x1;  //Interrupci�n habilitada
	TIM2->PSC=20000; //T_TCK=1.25ms
	TIM2->ARR=800; //T_salida_m�ximo=1s
	NVIC_EnableIRQ(TIM2_IRQn);
	
	//TIM3
	RCC->APB1ENR|=0x2; //TIMER 3
	TIM3->CR1=0x1;   //Contador habilitado
	TIM3->DIER=0x1;  //Interrupci�n habilitada
	TIM3->PSC=20000; //T_TCK=1.25ms
	TIM3->ARR=1200; //T_salida_m�ximo=1.5s
	NVIC_EnableIRQ(TIM3_IRQn);
	
	while(1){
	}
}
