/* El temporizador cuenta hasta el valor del ARR y luego se reincia,
	 mientras el PC13 este activado, el temporizador se reestablece.*/

#include "STM32F4xx.h"

int main(void) {
	RCC->AHB1ENR =0x6; 
	RCC->APB1ENR|=0x1;
	GPIOB->MODER = 1;
	TIM2->ARR=9000;
	TIM2->PSC=20000;
	TIM2->CR1=1;
  GPIOB->ODR=1;
	while(true)	{ 
		if(GPIOC->IDR & 0x2000==0x2000){   
    TIM2->EGR=1;
    while(TIM2->CNT <1600){GPIOB->ODR=0;}			
    GPIOB->ODR=1;
		}			
	}
}