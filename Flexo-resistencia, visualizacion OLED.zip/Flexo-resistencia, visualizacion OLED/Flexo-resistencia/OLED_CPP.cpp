#include "OLED.h"
#include "stdio.h"
void ReadADC(void);
void InitOLED(void);
void UpdateOLED(void);
void InitADC(void);
void delay(int ms){ms=ms*2000;
for(int z=0;z<ms;z++){__asm("NOP");}
}
float angulo=0.0;
float Voltaje=0,dr=0;
float Deflexion=0, Deflexion2=0;
char cont[10];
void i2c_init(void){
RCC->AHB1ENR|=7;
RCC->APB1ENR|=RCC_APB1ENR_I2C1EN; 
GPIOB->MODER|=0xA0000; 
GPIOB->PUPDR|=0x50000; 
GPIOB->AFR[1]|=0x44;  
GPIOB->OTYPER|=GPIO_OTYPER_OT8|GPIO_OTYPER_OT9; 
I2C1->CR1=I2C_CR1_SWRST;
I2C1->CR1&=~I2C_CR1_SWRST;	
I2C1->CR2|=16;  // reloj a 16MHz
I2C1->CCR|=(0<<15)|(0<<14)|(80<<0);  // SM 100Kbps
I2C1->TRISE=17; //output max rise 
I2C1->CR1|=I2C_CR1_PE;
}


int main(void){
  i2c_init();
  oled_Init();
	InitADC();
	SSD1306_GotoXY (5, 5);
	SSD1306_Puts ("UMNG", &Font_11x18, 0);
  SSD1306_GotoXY (30, 35);
	SSD1306_Puts ("MICROS", &Font_11x18, 0);
	SSD1306_UpdateScreen();
	delay (3000);	delay (3000);
		SSD1306_Clear();InitOLED();
while(1){
		ReadADC();
		UpdateOLED();
		delay(100);
  }
 }

void InitADC(void){
	RCC->APB2ENR = 0X100; //HABILITAR EL ADC 1
	GPIOA->MODER |= 0X3;// PA(0) An�logo
  ADC1->CR1=0;
	ADC1->SMPR2|=7;//480 CICLOS
	ADC1->CR1 = 2<<24; // 8BITS DE RESOLUCI?N
	ADC1->SQR3 = 0; //CANAL 0 DEL ADC1
	ADC1->CR2 |= 1; // ENCENDIDO DEL ADC
}
void InitOLED(void){
		SSD1306_GotoXY (5,10);
		SSD1306_Puts ("FLEX:", &Font_11x18, 0);
		SSD1306_GotoXY (5, 40);
		SSD1306_Puts ("VOLT:", &Font_11x18, 0);
		SSD1306_UpdateScreen();
		delay(100);
}
void UpdateOLED(void){
	//Deflexion
	sprintf(cont,"%f",Deflexion);
	SSD1306_GotoXY (65, 10);
	SSD1306_Puts (cont, &Font_11x18, 1);
	SSD1306_GotoXY (109,10);
	SSD1306_Puts ("%", &Font_11x18, 1);

	//Voltaje
	sprintf(cont,"%f",Voltaje);
	SSD1306_GotoXY (65, 40);
	SSD1306_Puts (cont, &Font_11x18, 1);
	SSD1306_GotoXY (109,40);
	SSD1306_Puts("V",&Font_11x18,1);
	SSD1306_UpdateScreen();
}


void ReadADC(void){
	ADC1 -> CR2 |= (1UL<<30); //INICIA CONVERSION
	while(!ADC_SR_EOC){__asm("NOP");}
	Voltaje=((ADC1->DR*3.3)/255);
	//Condiciones L�mite
	if (Voltaje<1.0){Voltaje=1.0;}
	if (Voltaje>2.4){Voltaje=2.4;}
//	//Descomposici�n de N�mero Redondeo 2F
	int u=Voltaje;
	int c=(Voltaje*100-(u*100))/10;
	int x=((Voltaje-u)*100)-(c*10);
	Voltaje=u+(c/10.0)+(x/100.0);
	//Determinaci�n de Deflexion
	Deflexion=(Voltaje-2.4)*-71.42;
}
