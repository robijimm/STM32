/* Lectura de 3 sensores LM35 y visualizaci�n de temperatura en LCD */

#include "stm32f4xx.h"
#define t for(int i=0; i<4000; i++)
#define ta for(int i=0; i<5; i++)
#define tr for(int h=0;h<3;h++)
char dat[3]={'S','1','='};
char dat1[3]={'S','2','='};
char dat2[3]={'S','3','='};
char num[10]={'0','1','2','3','4','5','6','7','8','9'};
int temp=0;

void enviar(char a)
{
	GPIOA->ODR = a | 1UL<<9;
	t;
	GPIOA->ODR &=~(1UL<<9); 
}

void dato (char b)
{
	GPIOA -> ODR = b | (3 << 8);
	t;
	GPIOA -> ODR &=~(1UL<<9);
}

int main (void)
{
	RCC->APB2ENR|= (1UL<<8); //Habilita el ADC 1
	RCC->AHB1ENR=0xF;// HABILITA DEL PUERTO A -D 
	GPIOA->MODER=0x55555555; // LCD
	GPIOC ->MODER|=0X3F; //ANALOGO PARA EL PIN 0 Y 1 (3)
	//LCD
	enviar(0X01);
	enviar(0X06);
	enviar(0xE);
	enviar(0x38);
	enviar(0xC);
	
	// ADC
	ADC1-> CR1= 0X0; // 12 BITS 
	ADC1 -> CR2 |= 0x201;
	ADC1-> SMPR1= 0X0; // 3 ciclos testeo 
	
	
while (true)
{ 
	int y=0 ,u=0, d=0,x=0;
	ADC1 -> SQR3=10;
	ADC1 -> CR2|=1UL << 30;
  ta;
	y=(ADC1 -> DR)*8056/100000;
	//visualizaci�n
	enviar(0x80);
	tr
	dato(dat[h]);
	
	if(y>=100)
	{
	d=(y/100);
	u=(y-d*100)/10;
	x=(y-d*100-u*10);

	enviar(0x80+3);
	dato(num[d]);
	enviar(0x80+4);
	dato(num[u]);
	enviar(0x80+5);
	dato(num[x]);
	dato(0xdf);
	}
	else if ( y>=10 && y<100)
	{
	d=(y/10);
	u=(y-d*10)/1;
	enviar(0x80+3);
	dato(num[d]);
	enviar(0x80+4);
	dato(num[u]);	
	dato(0xdf);
	}
	else
	{ d=(y/100);
		enviar(0x80+3);
	  dato(num[d]);
		dato(0xdf);
	}
	
	// sensor 2
	ADC1 -> SQR3=11;
	ADC1 -> CR2|=1UL << 30;
  ta;
	y=(ADC1 -> DR)*8056/100000;

//visualizaci�n
	enviar(0x88);
	tr
	dato(dat1[h]);
	
	if(y>=100)
	{
	d=(y/100);
	u=(y-d*100)/10;
	x=(y-d*100-u*10);

	enviar(0x88+3);
	dato(num[d]);
	enviar(0x88+4);
	dato(num[u]);
	enviar(0x88+5);
	dato(num[x]);
		dato(0xdf);
	
	}
	else if ( y>=10 && y<100)
	{
	d=(y/10);
	u=(y-d*10)/1;
	enviar(0x88+3);
	dato(num[d]);
	enviar(0x88+4);
	dato(num[u]);	
	dato(0xdf);
	}
	else
	{ d=(y/100);
		enviar(0x88+3);
	  dato(num[d]);
		dato(0xdf);
	}
	
// sensor 3
	
	ADC1 -> SQR3=12;
	ADC1 -> CR2|=1UL << 30;
  ta;
	y=(ADC1 -> DR)*8056/100000;
	
//visualizaci�n

	enviar(0xC5);
	tr
	dato(dat2[h]);
	
	if(y>=100)
	{
	d=(y/100);
	u=(y-d*100)/10;
	x=(y-d*100-u*10);

	enviar(0xC5+3);
	dato(num[d]);
	enviar(0xC5+4);
	dato(num[u]);
	enviar(0xC5+5);
	dato(num[x]);
		dato(0xdf);
	
	}
	else if ( y>=10 && y<100)
	{
	d=(y/10);
	u=(y-d*10)/1;
	enviar(0xC5+3);
	dato(num[d]);
	enviar(0xC5+4);
	dato(num[u]);
  enviar(0xC5+5);
	dato(0);		
	dato(0xdf);
	}
	else
	{ d=(y/100);
		enviar(0xC5+3);
	  dato(num[d]);
		dato(0xdf);
	}
	
}
}


