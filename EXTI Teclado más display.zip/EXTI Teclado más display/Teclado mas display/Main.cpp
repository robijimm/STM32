/* Se utiliza un teclado matricial para seleccionar un d�gito y se muestra el valor 
en un display 7 segmentos, se utilizan interrupciones externas para detectar cuando 
se presiona una tecla en el teclado. */

//////////////////////////EXTI TECLADO  mas display/////////////////////////////////////////////////////

#include "stm32f4xx.h"
int cl,f,c; 
char BCD [4][4] = {0xF9,0XA4,0XB0,0X99,0X92,0X83,0XF8,0X80,0X98,0x88,0x83,0xc6,0xa1,0x86,0x8e,0XC0};
void teclado(void){
	for(f=0;f<4;f++){			
		  GPIOD->ODR=(1UL<<f);
		  cl=(GPIOD->IDR & 0xf000)>>12;
			for(c=0;c<4;c++){
      if(cl==(1UL<<c)){return;}
			}	}	}
extern "C"
{	void EXTI15_10_IRQHandler(void){
		teclado(); 
		GPIOD->ODR=0XF;EXTI->PR = 0XFFFF;
		while((GPIOD->IDR & 0xf000))
	  {GPIOE->ODR=BCD[f][c];}
		
	}
}
	
int main(void){
	RCC -> APB2ENR |=(1UL << 14);
	RCC->AHB1ENR=0x01F; 
	GPIOD -> MODER = 0X00000055; 
	GPIOD -> PUPDR = 0XAA000000;
	SYSCFG -> EXTICR[3]=0X3333;
	EXTI -> IMR|=0XF000;
	EXTI -> RTSR|=0XF000;
	NVIC_EnableIRQ(EXTI15_10_IRQn);
	GPIOE->MODER=0x55555555;  
	GPIOD->ODR=0XF;	

	while(1){
	}
}
