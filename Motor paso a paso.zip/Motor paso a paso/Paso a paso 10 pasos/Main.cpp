/* Se controla un motor paso a paso en modo de 10 pasos, utilizando
una secuencia de pasos definida para girar el motor en una direcci�n,
aplicando los pasos de manera secuencial hasta alcanzar 10 pasos. */

///////////////PasoPaso 10 pasos ////////////
#include "stm32f4xx.h"
int pasos[4]={1,2,4,8}; //SECUENCIA
int a=0,i=0;
int main(void){
	RCC -> AHB1ENR = 8;//ACTIVA PUERTO D
	GPIOD -> MODER = 0X55; // SALIDA MOTOR
	while(1){
    if(i<=10){
			if(a<4){
			GPIOD -> ODR = pasos[a];	
				for(int tiempo=0;tiempo<500000;tiempo++);
				a++;
				i++;
			 }
			else {a=0;}
		}
	}
}