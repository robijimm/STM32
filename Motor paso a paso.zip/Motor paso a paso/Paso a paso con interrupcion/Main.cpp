/* Se controla un motor paso a paso utilizando una interrupci�n
del temporizador SysTick, girando el motor de manera continua en una direcci�n
cada cierto tiempo. */

#include "stm32f4xx.h"
#define motorP GPIOD->ODR
int pasos[4]={1,2,4,8}; //SECUENCIA
int a =0;
extern "C"
{
	void SysTick_Handler(void){	
		motorP = pasos[a];
		if(a<4){a++;}
    else {a=0;}
	}
}

int main(void){
	RCC -> AHB1ENR = 8; //PUERTO D
	GPIOD -> MODER = 0x55; //SALIDA LED
	SystemCoreClockUpdate();
	SysTick_Config(SystemCoreClock/10);
	
	while(1){

	}
}
