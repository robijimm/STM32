/* Se controla un motor paso a paso utilizando una se�al de entrada en el PA0,
avanzando al siguiente paso cada que se detecta un 1 en la se�al de entrada. */

/////////////////PasoPaso con se�al de entrada ////////////
#include "stm32f4xx.h"
int pasos[4]={1,2,4,8}; //SECUENCIA
int main(void){
	RCC -> AHB1ENR = 9;//ACTIVA PUERTO A/D
	GPIOA -> PUPDR = 2;//PullDown
	GPIOD -> MODER = 0X55; // SALIDA MOTOR
while(1){
	for(int a=0;a<4;a++){
		while((GPIOA -> IDR & 1)==0);
		for(int tiempo=0;tiempo<50000;tiempo++);
    while((GPIOA -> IDR & 1)==1);
	  GPIOD -> ODR = pasos[a];	
	   }
  }
}


