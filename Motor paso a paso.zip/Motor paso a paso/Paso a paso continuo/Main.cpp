/* Se controla un motor paso a paso en modo de paso continuo, utilizando
una secuencia de pasos definida para girar el motor en una direcci�n continua,
aplicando los pasos de manera secuencial de manera infinita. */

///////////PasoPaso pasos  continuo////////
#include "stm32f4xx.h"
int pasos[4]={1,2,4,8}; //SECUENCIA
int a;
int main(void){
	RCC -> AHB1ENR = 8;//ACTIVA PUERTO D
	GPIOD -> MODER = 0X55; // SALIDA MOTOR
while(1){
	for( a=0;a<4;a++){
	GPIOD -> ODR = pasos[a];	
		for(int tiempo=0;tiempo<500000;tiempo++);
	}
  }
}