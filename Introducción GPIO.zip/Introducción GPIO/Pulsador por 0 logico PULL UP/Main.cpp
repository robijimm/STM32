///////////   PULSADOR por 0 logico  PULL UP/////////////

#include "STM32F4xx.h"
int main(void)  {

	RCC->AHB1ENR =6;           //Puertos  B,C 
	GPIOB->MODER |= 0x1;       //  bit B0 de salida
	GPIOC->PUPDR |= 1<<2*13;       //  bit c13 de pull up
//********************************************************************************************
	while(true)	{
	if((GPIOC -> IDR&0X2000)==0)  // entrada por PC13
		  GPIOB -> ODR =1;               //enciende led por b0
		else  GPIOB -> ODR =0;           //apaga led por b0
	}
}