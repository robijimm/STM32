
/* Se configura el pin A0 como salida y el pin A4 como entrada. 
	 Se lee el estado del pin A4, si est� en alto, enciende el LED 
	 conectado al pin A0, inmediatamente despu�s, apaga el LED.*/

#include <stm32f4xx.h>

int main (void){
	RCC->AHB1ENR=1;
	GPIOA->MODER |= 1; //A4 ENTRADA   A0 SALIDA   BIT 00ENTRADA 01 SALIDA
	while(1){
		if((GPIOA->IDR & 16)==16){
			GPIOA->ODR=1;
		} 
		GPIOA->ODR=0;
	}
}