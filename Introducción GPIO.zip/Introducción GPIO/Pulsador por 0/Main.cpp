//////////////   PULSADOR por 0 /////////////
/* Se configuran  los pines B0 y B1 como salidas.
	Se lee el estado del pin C13, si est� en bajo, inserta un peque�o retardo 
	y luego alterna (cambia de estado) los LEDs conectados a los pines B0 y B1.*/

#include "STM32F4xx.h"
int main(void)  {

	RCC->AHB1ENR =6; //Puertos  B,C 
	GPIOB->MODER |= 0x5;

	while(true)	{
	if((GPIOC -> IDR&0X2000)==0){ //PC13
			for(int i=0;i< 100000; i++);
		  GPIOB -> ODR ^=3; //conmuta leds
		}
	}
}
