/////////////   PULSADOR por 1 logico  PULLDOWN/////////////

/* Se configura el pin B0 como salida y el pin C13 con una resistencia de pull-down. 
   Se lee el estado del pin C13 y, si est� en alto, enciende un LED conectado al pin B0,
	 si est� en bajo, apaga el LED.*/

#include "STM32F4xx.h"
int main(void)  {

	RCC->AHB1ENR =6;           //Puertos  B,C 
	GPIOB->MODER |= 0x1;       //  bit B0 de salida
	GPIOC->PUPDR |= 2<<2*13;       //  bit c13 de pull down
//********************************************************************************************
	while(true)	{
	if((GPIOC -> IDR&0X2000)==0X2000)  // entrada por PC13
		  GPIOB -> ODR =1;               //enciende led por b0
		else  GPIOB -> ODR =0;           //apaga led por b0
	}
}